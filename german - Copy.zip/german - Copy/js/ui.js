// UI Controller — German A2 Vocabulary App
'use strict';

window.UI = {
  engine: null,
  _currentView: null,
  _mcDirection: 'de-en',
  _matchState: null,

  init(engine) {
    this.engine = engine;
    this._bindKeyboard();
    this.showHome();
  },

  // ── Routing ────────────────────────────────────────────────────────────────
  setView(html) {
    const app = document.getElementById('app');
    app.classList.add('fade-out');
    setTimeout(() => {
      app.innerHTML = html;
      app.classList.remove('fade-out');
      app.classList.add('fade-in');
      setTimeout(() => app.classList.remove('fade-in'), 300);
    }, 150);
  },

  // ── HOME / DASHBOARD ───────────────────────────────────────────────────────
  showHome() {
    this._currentView = 'home';
    const stats    = this.engine.getStats();
    const sections = this.engine.getSections();
    const pct = stats.total ? Math.round((stats.learned / stats.total) * 100) : 0;

    const sectionCards = sections.map(s => {
      const secStats = stats.bySection.find(b => b.id === s.id);
      const lc = secStats ? secStats.learnedCount : 0;
      const pctSec = s.count ? Math.round((lc / s.count) * 100) : 0;
      return `
        <button class="section-card" onclick="UI.startSection('${s.id}')">
          <span class="sec-emoji">${s.emoji}</span>
          <span class="sec-title">${s.title}</span>
          <span class="sec-chip">${s.count} words</span>
          <div class="sec-bar"><div class="sec-bar-fill" style="width:${pctSec}%"></div></div>
        </button>`;
    }).join('');

    this.setView(`
      <div class="home-view">
        <header class="home-header">
          <div class="logo">🇩🇪 Deutsch A2</div>
          <button class="icon-btn" onclick="UI.showSettings()" title="Settings">⚙️</button>
        </header>

        <div class="stats-row">
          <div class="stat-pill">
            <span class="stat-num">${stats.dueToday}</span>
            <span class="stat-label">Due today</span>
          </div>
          <div class="stat-pill accent">
            <span class="stat-num">${stats.streak}</span>
            <span class="stat-label">🔥 Streak</span>
          </div>
          <div class="stat-pill">
            <span class="stat-num">${pct}%</span>
            <span class="stat-label">Learned</span>
          </div>
        </div>

        <div class="master-progress">
          <div class="mp-label"><span>${stats.learned} / ${stats.total} words learned</span></div>
          <div class="progress-bar"><div class="progress-fill" style="width:${pct}%"></div></div>
        </div>

        <div class="quick-btns">
          <button class="btn btn-primary" onclick="UI.startAll()">▶ Start Session</button>
          <button class="btn btn-outline" onclick="UI.startFavourites()">⭐ Favourites</button>
          <button class="btn btn-outline" onclick="UI.startA2()">🏅 A2 Only</button>
        </div>

        <div class="search-wrap">
          <input id="search-input" class="search-input" placeholder="🔍 Search words…" oninput="UI.onSearch(this.value)">
          <div id="search-results" class="search-results hidden"></div>
        </div>

        <h2 class="section-heading">Sections</h2>
        <div class="section-grid">${sectionCards}</div>

        <div class="home-footer">
          <button class="btn btn-ghost" onclick="UI.showFavourites()">View Favourites</button>
          <button class="btn btn-ghost" onclick="UI.showAllWords()">Browse All Words</button>
        </div>
      </div>
    `);
  },

  onSearch(val) {
    const box = document.getElementById('search-results');
    if (!val.trim()) { box.classList.add('hidden'); return; }
    const results = this.engine.searchCards(val).slice(0, 10);
    if (!results.length) { box.innerHTML = '<p class="sr-empty">No results</p>'; box.classList.remove('hidden'); return; }
    box.innerHTML = results.map(c => `
      <div class="sr-item">
        <span class="sr-de ${this._getArticleClass(c.article)}">${c.german}</span>
        <span class="sr-en">${c.english}</span>
        <span class="sr-sec">${c.sectionTitle}</span>
      </div>`).join('');
    box.classList.remove('hidden');
  },

  // ── SESSION STARTERS ───────────────────────────────────────────────────────
  startAll()          { this._startSession({}); },
  startFavourites()   { this._startSession({ onlyFavourites: true }); },
  startA2()           { this._startSession({ level: 'A2' }); },
  startSection(id)    { this._startSession({ section: id }); },
  startWrongReview()  { this.engine.buildWrongQueue(); this._runSession(); },

  _startSession(opts) {
    const q = this.engine.buildQueue(opts);
    if (q.length === 0) {
      this._toast('No cards match those filters!');
      return;
    }
    this._runSession();
  },

  _runSession() {
    const mode = this.engine.state.mode;
    if (mode === 'matching') {
      this.showMatching();
    } else {
      const card = this.engine.nextCard();
      if (!card) { this.showSessionComplete(); return; }
      if (mode === 'flashcard')      this.showFlashcard(card);
      else if (mode === 'multipleChoice') this.showMultipleChoice(card);
      else if (mode === 'typeIn')    this.showTypeIn(card);
    }
  },

  // ── FLASHCARD ──────────────────────────────────────────────────────────────
  showFlashcard(card) {
    this._currentView = 'flashcard';
    const dir = this.engine.state.direction === 'both'
      ? (Math.random() < 0.5 ? 'de-en' : 'en-de')
      : this.engine.state.direction;
    this._fcDir = dir;

    const remaining = this.engine.state.queue.length + 1;
    const isFav = this.engine.isFavourite(card.id);
    const isLearned = this.engine.isLearned(card.id);
    const front = dir === 'de-en' ? this._renderGerman(card) : `<span class="card-english">${card.english}</span>`;

    this.setView(`
      <div class="session-view">
        ${this._renderSessionHeader(remaining)}
        <div class="fc-wrapper">
          <div class="card" id="fc-card">
            <div class="card-inner" id="fc-inner">
              <div class="card-face card-front">
                <button class="fav-btn ${isFav ? 'active' : ''}" onclick="UI.toggleFav('${card.id}', event)" title="Favourite">⭐</button>
                ${this._renderLevelBadge(card)}
                <div class="card-prompt-label">${dir === 'de-en' ? '🇩🇪 German' : '🇬🇧 English'}</div>
                <div class="card-front-content">${front}</div>
                <div class="card-hint">Tap to reveal</div>
              </div>
              <div class="card-face card-back">
                ${this._renderCardBack(card, dir)}
              </div>
            </div>
          </div>
        </div>

        <div class="fc-controls" id="fc-controls" style="display:none">
          <button class="btn btn-wrong" id="btn-wrong" onclick="UI.recordAndNext('${card.id}', false)">❌ Didn't know</button>
          <button class="btn btn-correct" id="btn-correct" onclick="UI.recordAndNext('${card.id}', true)">✅ Knew it</button>
        </div>
        <div class="flip-hint" id="flip-hint">
          <button class="btn btn-outline" onclick="UI.flipCard()">Flip card</button>
        </div>
        <div class="key-hint">Space = flip &nbsp;|&nbsp; → Knew it &nbsp;|&nbsp; ← Didn't know &nbsp;|&nbsp; F = Favourite</div>
      </div>
    `);

    document.getElementById('fc-card').addEventListener('click', () => UI.flipCard());
  },

  flipCard() {
    const inner = document.getElementById('fc-inner');
    if (!inner) return;
    inner.classList.toggle('flipped');
    const controls = document.getElementById('fc-controls');
    const hint     = document.getElementById('flip-hint');
    if (inner.classList.contains('flipped')) {
      if (controls) controls.style.display = 'flex';
      if (hint) hint.style.display = 'none';
    }
  },

  recordAndNext(cardId, correct) {
    const result = this.engine.recordResult(cardId, correct);
    if (result.suggestLearned && correct) {
      this._showLearnedSuggestion(cardId);
      return;
    }
    this._advance();
  },

  _showLearnedSuggestion(cardId) {
    const banner = document.createElement('div');
    banner.className = 'learned-banner';
    banner.innerHTML = `
      <span>🎉 You've mastered this word!</span>
      <button onclick="UI.engine.markLearned('${cardId}'); this.closest('.learned-banner').remove(); UI._advance()">Mark as learned</button>
      <button onclick="this.closest('.learned-banner').remove(); UI._advance()">Skip</button>
    `;
    document.querySelector('.session-view')?.prepend(banner);
  },

  _advance() {
    const mode = this.engine.state.mode;
    const card = this.engine.nextCard();
    if (!card) { this.showSessionComplete(); return; }
    if (mode === 'flashcard')      this.showFlashcard(card);
    else if (mode === 'multipleChoice') this.showMultipleChoice(card);
    else if (mode === 'typeIn')    this.showTypeIn(card);
  },

  toggleFav(cardId, event) {
    if (event) event.stopPropagation();
    this.engine.toggleFavourite(cardId);
    const btn = document.querySelector('.fav-btn');
    if (btn) btn.classList.toggle('active', this.engine.isFavourite(cardId));
  },

  // ── MULTIPLE CHOICE ────────────────────────────────────────────────────────
  showMultipleChoice(card) {
    this._currentView = 'multipleChoice';
    const remaining = this.engine.state.queue.length + 1;
    const { choices, direction, promptText } = this.engine.generateChoices(card, 4);
    const isFav = this.engine.isFavourite(card.id);

    const choiceHTML = choices.map((ch, i) => `
      <button class="choice-btn" data-correct="${ch.correct}" onclick="UI.selectChoice(this, '${card.id}', ${ch.correct})">
        ${ch.text}
      </button>`).join('');

    this.setView(`
      <div class="session-view">
        ${this._renderSessionHeader(remaining)}
        <div class="mc-container">
          <div class="mc-meta">
            ${this._renderLevelBadge(card)}
            <span class="direction-label">${direction === 'de-en' ? '🇩🇪 → 🇬🇧' : '🇬🇧 → 🇩🇪'}</span>
            <button class="fav-btn ${isFav ? 'active' : ''}" onclick="UI.toggleFav('${card.id}')" title="Favourite">⭐</button>
          </div>
          <div class="mc-prompt">${direction === 'de-en' ? this._renderGerman(card) : `<span class="card-english">${promptText}</span>`}</div>
          <div class="mc-choices" id="mc-choices">${choiceHTML}</div>
        </div>
      </div>
    `);
  },

  selectChoice(btn, cardId, correct) {
    const container = document.getElementById('mc-choices');
    if (!container || container.classList.contains('answered')) return;
    container.classList.add('answered');

    // Disable all
    container.querySelectorAll('.choice-btn').forEach(b => {
      b.disabled = true;
      if (b.dataset.correct === 'true') b.classList.add('correct');
      else if (b === btn) b.classList.add('wrong');
    });

    this.engine.recordResult(cardId, correct);
    this._updateStreakDisplay();

    setTimeout(() => this._advance(), 1500);
  },

  _updateStreakDisplay() {
    const el = document.querySelector('.streak-display');
    if (el) el.textContent = `🔥 ${this.engine.state.streak}`;
  },

  // ── TYPE-IN ────────────────────────────────────────────────────────────────
  showTypeIn(card) {
    this._currentView = 'typeIn';
    const remaining = this.engine.state.queue.length + 1;
    const dir = this.engine.state.direction === 'both'
      ? (Math.random() < 0.5 ? 'de-en' : 'en-de')
      : this.engine.state.direction;
    this._typeInDirection = dir;
    const prompt = dir === 'de-en' ? this._renderGerman(card) : `<span class="card-english">${card.english}</span>`;
    const isFav = this.engine.isFavourite(card.id);

    this.setView(`
      <div class="session-view">
        ${this._renderSessionHeader(remaining)}
        <div class="ti-container">
          <div class="ti-meta">
            ${this._renderLevelBadge(card)}
            <span class="direction-label">${dir === 'de-en' ? '🇩🇪 → 🇬🇧' : '🇬🇧 → 🇩🇪'}</span>
            <button class="fav-btn ${isFav ? 'active' : ''}" onclick="UI.toggleFav('${card.id}', event)" title="Favourite">⭐</button>
          </div>
          <div class="ti-prompt">${prompt}</div>
          <input id="ti-input" class="ti-input" placeholder="Type translation…" autocomplete="off" autocorrect="off" spellcheck="false"
            onkeydown="if(event.key==='Enter') UI.submitTypeIn('${card.id}')">
          <button class="btn btn-primary" onclick="UI.submitTypeIn('${card.id}')">Check ↵</button>
          <div id="ti-feedback" class="ti-feedback hidden"></div>
        </div>
      </div>
    `);

    setTimeout(() => document.getElementById('ti-input')?.focus(), 200);
  },

  submitTypeIn(cardId) {
    const input = document.getElementById('ti-input');
    const feedback = document.getElementById('ti-feedback');
    if (!input || !feedback) return;
    if (input.disabled) { this._advance(); return; }

    const card = this.engine.getCard(cardId);
    const { ok, correct } = this.engine.checkTypeIn(input.value, card, this._typeInDirection);

    this.engine.recordResult(cardId, ok);
    input.disabled = true;

    feedback.classList.remove('hidden');
    if (ok) {
      feedback.className = 'ti-feedback success';
      feedback.innerHTML = `✅ Correct! <strong>${correct}</strong>`;
    } else {
      feedback.className = 'ti-feedback error';
      feedback.innerHTML = `❌ Wrong. Correct answer: <strong>${correct}</strong>`;
    }

    setTimeout(() => this._advance(), 2000);
  },

  // ── MATCHING ───────────────────────────────────────────────────────────────
  showMatching(sectionId) {
    this._currentView = 'matching';
    const sid = sectionId || this.engine.state.filterSection || null;
    const { lefts, rights } = this.engine.generateMatchingPairs(sid, 6);
    this._matchState = { lefts, rights, selectedLeft: null, matched: new Set(), wrong: new Set() };

    const leftHTML  = lefts.map(l =>
      `<button class="match-btn left" data-id="${l.id}" onclick="UI.selectMatchLeft(this, '${l.id}')">${l.text}</button>`
    ).join('');
    const rightHTML = rights.map(r =>
      `<button class="match-btn right" data-id="${r.id}" onclick="UI.selectMatchRight(this, '${r.id}')">${r.text}</button>`
    ).join('');

    this.setView(`
      <div class="session-view">
        <div class="session-header">
          <button class="icon-btn" onclick="UI.showHome()">🏠</button>
          <span class="session-title">Matching</span>
          <span id="match-score" class="session-score">0 / ${lefts.length}</span>
        </div>
        <p class="match-hint">Click a German word, then its English translation.</p>
        <div class="match-grid">
          <div class="match-col" id="match-left">${leftHTML}</div>
          <div class="match-col" id="match-right">${rightHTML}</div>
        </div>
      </div>
    `);
  },

  selectMatchLeft(btn, id) {
    if (this._matchState.matched.has(id)) return;
    document.querySelectorAll('.match-btn.left').forEach(b => b.classList.remove('selected'));
    btn.classList.add('selected');
    this._matchState.selectedLeft = id;
  },

  selectMatchRight(btn, id) {
    const ms = this._matchState;
    if (!ms.selectedLeft) return;
    if (ms.matched.has(id)) return;

    const leftBtn = document.querySelector(`.match-btn.left[data-id="${ms.selectedLeft}"]`);
    if (ms.selectedLeft === id) {
      // Match!
      ms.matched.add(id);
      btn.classList.add('matched');
      if (leftBtn) leftBtn.classList.add('matched');
      ms.selectedLeft = null;

      const scoreEl = document.getElementById('match-score');
      if (scoreEl) scoreEl.textContent = `${ms.matched.size} / ${ms.lefts.length}`;

      if (ms.matched.size === ms.lefts.length) {
        setTimeout(() => {
          this._toast('🎉 All matched! Well done!');
          setTimeout(() => this.showSessionComplete(), 1200);
        }, 400);
      }
    } else {
      // Wrong
      btn.classList.add('wrong-shake');
      if (leftBtn) leftBtn.classList.add('wrong-shake');
      setTimeout(() => {
        btn.classList.remove('wrong-shake');
        if (leftBtn) { leftBtn.classList.remove('wrong-shake', 'selected'); }
        ms.selectedLeft = null;
      }, 600);
    }
  },

  // ── SESSION COMPLETE ───────────────────────────────────────────────────────
  showSessionComplete() {
    this._currentView = 'complete';
    const { sessionCorrect, sessionWrong, streak, wrongCards } = this.engine.state;
    const total = sessionCorrect + sessionWrong;
    const pct = total ? Math.round((sessionCorrect / total) * 100) : 0;
    const xp  = sessionCorrect * 10;

    const wrongSection = wrongCards.length > 0 ? `
      <button class="btn btn-outline" onclick="UI.startWrongReview()">🔁 Review ${wrongCards.length} wrong answers</button>` : '';

    this.setView(`
      <div class="complete-view">
        <div class="complete-card">
          <div class="complete-emoji">${pct >= 80 ? '🏆' : pct >= 50 ? '👍' : '💪'}</div>
          <h2>Session Complete!</h2>
          <div class="complete-stats">
            <div class="cs-row"><span>✅ Correct</span><strong>${sessionCorrect}</strong></div>
            <div class="cs-row"><span>❌ Wrong</span><strong>${sessionWrong}</strong></div>
            <div class="cs-row"><span>Score</span><strong>${pct}%</strong></div>
            <div class="cs-row"><span>🔥 Streak</span><strong>${streak}</strong></div>
            <div class="cs-row"><span>⚡ XP earned</span><strong>+${xp}</strong></div>
          </div>
          <div class="pct-ring" style="--pct:${pct}">
            <span>${pct}%</span>
          </div>
        </div>
        <div class="complete-actions">
          ${wrongSection}
          <button class="btn btn-primary" onclick="UI.startAll()">▶ Next Session</button>
          <button class="btn btn-ghost" onclick="UI.showHome()">🏠 Back to Menu</button>
        </div>
      </div>
    `);
  },

  // ── FAVOURITES ─────────────────────────────────────────────────────────────
  showFavourites() {
    this._currentView = 'favourites';
    const favIds = [...this.engine.state.favourites];
    const cards  = favIds.map(id => this.engine.getCard(id)).filter(Boolean);

    const listHTML = cards.length === 0
      ? '<p class="empty-msg">No favourites yet. Tap ⭐ on any card to add it.</p>'
      : cards.map(c => `
          <div class="fav-item">
            <div class="fav-de ${this._getArticleClass(c.article)}">${c.german}</div>
            <div class="fav-en">${c.english}</div>
            <button class="icon-btn" onclick="UI.engine.toggleFavourite('${c.id}'); UI.showFavourites();" title="Remove">⭐</button>
          </div>`).join('');

    this.setView(`
      <div class="list-view">
        <div class="list-header">
          <button class="icon-btn" onclick="UI.showHome()">←</button>
          <h2>⭐ Favourites (${cards.length})</h2>
        </div>
        ${listHTML}
        ${cards.length > 0 ? `<div class="list-actions">
          <button class="btn btn-primary" onclick="UI.startFavourites()">▶ Study Favourites</button>
        </div>` : ''}
      </div>
    `);
  },

  // ── ALL WORDS ──────────────────────────────────────────────────────────────
  showAllWords() {
    this._currentView = 'allWords';
    const sections = this.engine.getSections();

    const html = sections.map(s => {
      const cards = this.engine.getCardsBySection(s.id);
      const rows = cards.map(c => `
        <div class="word-row">
          <span class="wr-de ${this._getArticleClass(c.article)}">${c.german}</span>
          <span class="wr-en">${c.english}</span>
          <span class="wr-badges">
            ${c.level === 'A1' ? '<span class="badge a1">A1</span>' : '<span class="badge a2">A2</span>'}
            ${this.engine.isLearned(c.id) ? '<span class="badge learned">✓</span>' : ''}
            ${this.engine.isFavourite(c.id) ? '<span class="badge fav">⭐</span>' : ''}
          </span>
        </div>`).join('');

      return `
        <div class="sec-group">
          <h3 class="sec-group-title">${s.emoji} ${s.title} <span class="sec-chip">${s.count}</span></h3>
          <div class="sec-words">${rows}</div>
        </div>`;
    }).join('');

    this.setView(`
      <div class="list-view">
        <div class="list-header">
          <button class="icon-btn" onclick="UI.showHome()">←</button>
          <h2>📖 All Words</h2>
        </div>
        ${html}
      </div>
    `);
  },

  // ── SETTINGS ───────────────────────────────────────────────────────────────
  showSettings() {
    this._currentView = 'settings';
    const s = this.engine.state;

    this.setView(`
      <div class="settings-view">
        <div class="settings-header">
          <button class="icon-btn" onclick="UI.showHome()">←</button>
          <h2>⚙️ Settings</h2>
        </div>

        <section class="settings-section">
          <h3>Direction</h3>
          <div class="toggle-group">
            <button class="toggle-btn ${s.direction === 'de-en' ? 'active' : ''}" onclick="UI.setDirection('de-en')">🇩🇪 → 🇬🇧</button>
            <button class="toggle-btn ${s.direction === 'en-de' ? 'active' : ''}" onclick="UI.setDirection('en-de')">🇬🇧 → 🇩🇪</button>
            <button class="toggle-btn ${s.direction === 'both'  ? 'active' : ''}" onclick="UI.setDirection('both')">Both</button>
          </div>
        </section>

        <section class="settings-section">
          <h3>Mode</h3>
          <div class="toggle-group">
            <button class="toggle-btn ${s.mode === 'flashcard'      ? 'active' : ''}" onclick="UI.setMode('flashcard')">🃏 Flashcard</button>
            <button class="toggle-btn ${s.mode === 'multipleChoice' ? 'active' : ''}" onclick="UI.setMode('multipleChoice')">🔤 Quiz</button>
            <button class="toggle-btn ${s.mode === 'typeIn'         ? 'active' : ''}" onclick="UI.setMode('typeIn')">⌨️ Type-In</button>
            <button class="toggle-btn ${s.mode === 'matching'       ? 'active' : ''}" onclick="UI.setMode('matching')">🔗 Matching</button>
          </div>
        </section>

        <section class="settings-section">
          <h3>Level Filter</h3>
          <div class="toggle-group">
            <button class="toggle-btn ${!s.filterLevel       ? 'active' : ''}" onclick="UI.setLevel(null)">All</button>
            <button class="toggle-btn ${s.filterLevel==='A1' ? 'active' : ''}" onclick="UI.setLevel('A1')">A1</button>
            <button class="toggle-btn ${s.filterLevel==='A2' ? 'active' : ''}" onclick="UI.setLevel('A2')">A2</button>
          </div>
        </section>

        <section class="settings-section danger-zone">
          <h3>⚠️ Danger Zone</h3>
          <button class="btn btn-danger" onclick="UI.confirmReset()">Reset All Progress</button>
        </section>
      </div>
    `);
  },

  setDirection(dir) {
    this.engine.state.direction = dir;
    this.engine.saveState();
    this.showSettings();
  },

  setMode(mode) {
    this.engine.state.mode = mode;
    this.engine.saveState();
    this.showSettings();
  },

  setLevel(level) {
    this.engine.state.filterLevel = level;
    this.showSettings();
  },

  confirmReset() {
    if (confirm('Are you sure? This will delete all your progress.')) {
      localStorage.clear();
      this.engine.state.learned    = new Set();
      this.engine.state.favourites = new Set();
      this.engine.state.scores     = {};
      this.engine.state.streak     = 0;
      this._toast('Progress reset.');
      this.showHome();
    }
  },

  _getArticleClass(art) {
    if (!art) return '';
    if (art.includes('Pl')) return 'art-pl';
    if (art.includes('das')) return 'art-das';
    if (art.includes('die')) return 'art-die';
    if (art.includes('der')) return 'art-der';
    return '';
  },

  // ── HELPERS ────────────────────────────────────────────────────────────────
  _renderGerman(card) {
    if (card.type === 'noun' && card.article) {
      const artClass = this._getArticleClass(card.article);
      const pluralStr = card.plural ? `<span class="card-plural">${card.plural}</span>` : '';
      return `<span class="card-german ${artClass}">${card.german}</span>${pluralStr}`;
    }
    return `<span class="card-german">${card.german}</span>`;
  },

  _renderCardBack(card, dir) {
    const translation = dir === 'de-en' ? card.english : card.german;
    let extra = '';

    if (card.type === 'verb' && card.verbForms) {
      const vf = card.verbForms;
      extra = `
        <div class="verb-forms">
          <span class="vf-pill">du: ${vf.du}</span>
          <span class="vf-pill">er/sie: ${vf.er}</span>
          <span class="vf-pill">Perfekt: ${vf.perfekt}</span>
        </div>`;
    }
    if (card.type === 'noun' && card.article) {
      const artClass = this._getArticleClass(card.article);
      extra = `<div class="noun-info">
        <span class="art-badge ${artClass}">${card.article}</span>
        ${card.plural ? `<span class="plural-badge">${card.plural}</span>` : ''}
      </div>`;
    }

    const example = card.exampleDE ? `
      <div class="card-example">
        <div class="ex-de">🇩🇪 ${card.exampleDE}</div>
        <div class="ex-en">🇬🇧 ${card.exampleEN}</div>
      </div>` : '';

    return `
      <div class="card-back-content">
        <div class="card-translation">${translation}</div>
        ${extra}
        ${example}
      </div>`;
  },

  _renderLevelBadge(card) {
    return card.level === 'A1'
      ? `<span class="badge a1">A1</span>`
      : `<span class="badge a2">A2</span>`;
  },

  _renderSessionHeader(remaining) {
    const total = remaining + this.engine.state.sessionCorrect + this.engine.state.sessionWrong;
    const done  = total - remaining;
    const pct   = total ? Math.round((done / total) * 100) : 0;

    return `
      <div class="session-header">
        <button class="icon-btn" onclick="UI.showHome()">🏠</button>
        <div class="session-progress-bar">
          <div class="session-progress-fill" style="width:${pct}%"></div>
        </div>
        <span class="streak-display">🔥 ${this.engine.state.streak}</span>
        <span class="session-remaining">${remaining} left</span>
      </div>`;
  },

  _toast(msg) {
    const t = document.createElement('div');
    t.className = 'toast';
    t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(() => t.classList.add('visible'), 10);
    setTimeout(() => { t.classList.remove('visible'); setTimeout(() => t.remove(), 300); }, 2500);
  },

  // ── KEYBOARD ───────────────────────────────────────────────────────────────
  _bindKeyboard() {
    document.addEventListener('keydown', e => {
      if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
      if (this._currentView === 'flashcard') {
        if (e.code === 'Space') { e.preventDefault(); this.flipCard(); }
        if (e.code === 'ArrowRight') {
          const btn = document.getElementById('btn-correct');
          if (btn && btn.style.display !== 'none') btn.click();
        }
        if (e.code === 'ArrowLeft') {
          const btn = document.getElementById('btn-wrong');
          if (btn && btn.style.display !== 'none') btn.click();
        }
        if (e.key === 'f' || e.key === 'F') {
          const card = this.engine.state.currentCard;
          if (card) this.toggleFav(card.id);
        }
      }
    });
  }
};

// Quiz Engine — German A2 Vocabulary App
// SM-2 simplified spaced repetition
'use strict';

window.QuizEngine = {
  state: {
    allCards: [],
    queue: [],
    learned: new Set(),
    favourites: new Set(),
    scores: {},
    streak: 0,
    sessionCorrect: 0,
    sessionWrong: 0,
    currentCard: null,
    wrongCards: [],         // ids answered wrong this session
    mode: 'flashcard',
    direction: 'de-en',
    filterSection: null,
    filterLevel: null,
  },

  // ── Persistence ────────────────────────────────────────────────────────────
  saveState() {
    try {
      const { learned, favourites, scores, streak, state } = this;
      localStorage.setItem('de_a2_learned',    JSON.stringify([...this.state.learned]));
      localStorage.setItem('de_a2_favourites', JSON.stringify([...this.state.favourites]));
      localStorage.setItem('de_a2_scores',     JSON.stringify(this.state.scores));
      localStorage.setItem('de_a2_streak',     JSON.stringify(this.state.streak));
      localStorage.setItem('de_a2_mode',       this.state.mode);
      localStorage.setItem('de_a2_direction',  this.state.direction);
    } catch(e) {
      console.warn('QuizEngine.saveState failed:', e);
    }
  },

  loadState() {
    try {
      const learned    = JSON.parse(localStorage.getItem('de_a2_learned')    || '[]');
      const favourites = JSON.parse(localStorage.getItem('de_a2_favourites') || '[]');
      const scores     = JSON.parse(localStorage.getItem('de_a2_scores')     || '{}');
      const streak     = JSON.parse(localStorage.getItem('de_a2_streak')     || '0');
      const mode       = localStorage.getItem('de_a2_mode')      || 'flashcard';
      const direction  = localStorage.getItem('de_a2_direction') || 'de-en';

      this.state.learned    = new Set(learned);
      this.state.favourites = new Set(favourites);
      this.state.scores     = scores;
      this.state.streak     = streak;
      this.state.mode       = mode;
      this.state.direction  = direction;
    } catch(e) {
      console.warn('QuizEngine.loadState failed:', e);
    }
  },

  // ── Setup ──────────────────────────────────────────────────────────────────
  init(vocabData) {
    // Flatten all sections into allCards
    this.state.allCards = [];
    for (const section of vocabData.sections) {
      for (const entry of section.entries) {
        this.state.allCards.push({ ...entry, sectionId: section.id, sectionTitle: section.title });
      }
    }
    // Store raw sections for later reference
    this._sections = vocabData.sections;
    this.loadState();
  },

  buildQueue(options = {}) {
    const { section, level, includeLearned = false, onlyFavourites = false } = options;
    const now = Date.now();

    let cards = this.state.allCards.filter(card => {
      if (!includeLearned && this.state.learned.has(card.id)) return false;
      if (onlyFavourites && !this.state.favourites.has(card.id)) return false;
      if (section && card.sectionId !== section) return false;
      if (level && card.level !== level) return false;
      return true;
    });

    // Split into due and new
    const due = [];
    const newCards = [];
    for (const card of cards) {
      const score = this.state.scores[card.id];
      if (score && score.dueDate) {
        if (score.dueDate <= now) due.push(card);
        else newCards.push(card);
      } else {
        newCards.push(card);
      }
    }

    // Sort due by dueDate ascending
    due.sort((a, b) => {
      const da = this.state.scores[a.id]?.dueDate || 0;
      const db = this.state.scores[b.id]?.dueDate || 0;
      return da - db;
    });

    // Shuffle new cards
    this._shuffle(newCards);

    // Queue = due first, then new (cap session at 50)
    const combined = [...due, ...newCards].slice(0, 50);
    this.state.queue = combined.map(c => c.id);
    this.state.sessionCorrect = 0;
    this.state.sessionWrong = 0;
    this.state.wrongCards = [];
    return this.state.queue;
  },

  // ── Card Selection ─────────────────────────────────────────────────────────
  nextCard() {
    if (this.state.queue.length === 0) {
      this.state.currentCard = null;
      return null;
    }
    const id = this.state.queue.shift();
    const card = this.getCard(id);
    this.state.currentCard = card;
    return card;
  },

  getCard(id) {
    return this.state.allCards.find(c => c.id === id) || null;
  },

  // ── Multiple Choice ────────────────────────────────────────────────────────
  generateChoices(card, count = 4) {
    const direction = this.state.direction === 'both'
      ? (Math.random() < 0.5 ? 'de-en' : 'en-de')
      : this.state.direction;

    // Gather wrong answer pool from same section first, then global
    const sameSection = this.state.allCards.filter(c => c.id !== card.id && c.sectionId === card.sectionId);
    const others      = this.state.allCards.filter(c => c.id !== card.id && c.sectionId !== card.sectionId);
    this._shuffle(sameSection);
    this._shuffle(others);
    const pool = [...sameSection, ...others];

    const getAnswer = c => direction === 'de-en' ? c.english : c.german;

    const correctText = getAnswer(card);
    const choices = [{ text: correctText, correct: true }];

    for (const c of pool) {
      if (choices.length >= count) break;
      const text = getAnswer(c);
      if (text && !choices.some(ch => ch.text === text)) {
        choices.push({ text, correct: false });
      }
    }

    this._shuffle(choices);
    return { choices, direction, promptText: direction === 'de-en' ? card.german : card.english };
  },

  // ── Matching ───────────────────────────────────────────────────────────────
  generateMatchingPairs(sectionId, count = 6) {
    let pool = sectionId
      ? this.state.allCards.filter(c => c.sectionId === sectionId)
      : this.state.allCards;
    this._shuffle(pool);
    const selected = pool.slice(0, Math.min(count, pool.length));

    const lefts  = selected.map(c => ({ id: c.id, text: c.german }));
    const rights = selected.map(c => ({ id: c.id, text: c.english }));
    this._shuffle(rights);
    return { lefts, rights };
  },

  // ── Scoring & SM-2 ─────────────────────────────────────────────────────────
  recordResult(cardId, correct) {
    const now = Date.now();
    const ONE_DAY = 86400000;

    if (!this.state.scores[cardId]) {
      this.state.scores[cardId] = { correct: 0, wrong: 0, lastSeen: now, dueDate: now, interval: 1 };
    }
    const score = this.state.scores[cardId];
    score.lastSeen = now;

    if (correct) {
      score.correct++;
      score.interval = Math.min(score.interval * 2, 30);
      if (score.interval < 1) score.interval = 1;
      score.dueDate = now + score.interval * ONE_DAY;
      this.state.streak++;
      this.state.sessionCorrect++;
    } else {
      score.wrong++;
      score.interval = 1;
      score.dueDate = now + ONE_DAY;
      this.state.streak = 0;
      this.state.sessionWrong++;
      if (!this.state.wrongCards.includes(cardId)) {
        this.state.wrongCards.push(cardId);
      }
    }

    this.saveState();

    // Suggest learned if correct ≥ 3 and interval ≥ 7 (but don't auto-mark)
    if (correct && score.correct >= 3 && score.interval >= 7) {
      return { suggestLearned: true };
    }
    return { suggestLearned: false };
  },

  // ── Favourites & Learned ───────────────────────────────────────────────────
  toggleFavourite(cardId) {
    if (this.state.favourites.has(cardId)) {
      this.state.favourites.delete(cardId);
    } else {
      this.state.favourites.add(cardId);
    }
    this.saveState();
  },

  markLearned(cardId) {
    this.state.learned.add(cardId);
    this.saveState();
  },

  unmarkLearned(cardId) {
    this.state.learned.delete(cardId);
    this.saveState();
  },

  isLearned(id)    { return this.state.learned.has(id); },
  isFavourite(id)  { return this.state.favourites.has(id); },

  // ── Stats ──────────────────────────────────────────────────────────────────
  getStats() {
    const now = Date.now();
    const total     = this.state.allCards.length;
    const learned   = this.state.learned.size;
    const favCount  = this.state.favourites.size;
    const dueToday  = this.state.allCards.filter(c => {
      const s = this.state.scores[c.id];
      return s && s.dueDate <= now && !this.state.learned.has(c.id);
    }).length;

    // Also count never-seen cards as due
    const neverSeen = this.state.allCards.filter(c =>
      !this.state.scores[c.id] && !this.state.learned.has(c.id)
    ).length;

    const bySection = this._sections.map(sec => ({
      id: sec.id,
      title: sec.title,
      emoji: sec.emoji,
      total: sec.entries.length,
      learnedCount: sec.entries.filter(e => this.state.learned.has(e.id)).length
    }));

    return {
      total,
      learned,
      favourites: favCount,
      streak: this.state.streak,
      sessionCorrect: this.state.sessionCorrect,
      sessionWrong:   this.state.sessionWrong,
      dueToday: dueToday + neverSeen,
      bySection
    };
  },

  // ── Utility ────────────────────────────────────────────────────────────────
  getSections() {
    return this._sections.map(s => ({
      id: s.id, title: s.title, emoji: s.emoji, count: s.entries.length
    }));
  },

  getCardsBySection(sectionId) {
    return this.state.allCards.filter(c => c.sectionId === sectionId);
  },

  searchCards(query) {
    if (!query) return [];
    const q = query.toLowerCase().trim();
    return this.state.allCards.filter(c =>
      c.german.toLowerCase().includes(q) ||
      c.english.toLowerCase().includes(q)
    );
  },

  // Queue only the wrong cards for review
  buildWrongQueue() {
    this.state.queue = [...this.state.wrongCards];
    this.state.sessionCorrect = 0;
    this.state.sessionWrong = 0;
    this.state.wrongCards = [];
    return this.state.queue;
  },

  // ── Internal ───────────────────────────────────────────────────────────────
  _shuffle(arr) {
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr;
  },

  // Levenshtein distance for type-in fuzzy matching
  levenshtein(a, b) {
    a = a.toLowerCase().trim();
    b = b.toLowerCase().trim();
    const m = a.length, n = b.length;
    const dp = Array.from({ length: m + 1 }, (_, i) => [i, ...Array(n).fill(0)]);
    for (let j = 0; j <= n; j++) dp[0][j] = j;
    for (let i = 1; i <= m; i++) {
      for (let j = 1; j <= n; j++) {
        dp[i][j] = a[i-1] === b[j-1]
          ? dp[i-1][j-1]
          : 1 + Math.min(dp[i-1][j], dp[i][j-1], dp[i-1][j-1]);
      }
    }
    return dp[m][n];
  },

  checkTypeIn(input, card, forcedDirection) {
    const direction = forcedDirection || (this.state.direction === 'both'
      ? (Math.random() < 0.5 ? 'de-en' : 'en-de')
      : this.state.direction);
    const correct = direction === 'de-en' ? card.english : card.german;
    // Accept any pipe, comma or slash separated answer
    const answers = correct.split(/[|,\/]/).map(s => s.trim());
    for (const ans of answers) {
      const dist = this.levenshtein(input, ans);
      const threshold = ans.length > 5 ? 2 : 0;
      if (dist <= threshold) return { ok: true, correct };
    }
    return { ok: false, correct };
  }
};

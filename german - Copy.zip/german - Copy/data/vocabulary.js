// Deutsch A2 — Complete Official Vocabulary (1,396 entries)
// Source: Deutsch A2 Wortschatz mit Beispielsätzen (Goethe-Zertifikat A2 / telc Deutsch A2 / ÖSD A2)
// Auto-generated data layer for German Vocabulary Trainer

window.VOCAB_DATA = {
  meta: {
    title: "Deutsch A2 Wortschatz mit Beispielsätzen",
    totalEntries: 1396,
    generatedAt: "2026-11-18T22:10:49.789Z"
  },
  sections: [
  {
    "id": "verben",
    "title": "Verben",
    "emoji": "🏃",
    "entries": [
      {
        "id": "v0001",
        "german": "abfahren",
        "english": "to leave, depart",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "fährst ab",
          "er": "fährt ab",
          "perfekt": "ist abgefahren"
        },
        "exampleDE": "Der Bus fährt um 8 Uhr ab .",
        "exampleEN": "The bus leaves at 8 o'clock."
      },
      {
        "id": "v0002",
        "german": "abgeben",
        "english": "to hand in",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "gibst ab",
          "er": "gibt ab",
          "perfekt": "hat abgegeben"
        },
        "exampleDE": "Bitte geben Sie den Test hier ab .",
        "exampleEN": "Please hand in the test here."
      },
      {
        "id": "v0003",
        "german": "abheben",
        "english": "to withdraw (money)",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "hebst ab",
          "er": "hebt ab",
          "perfekt": "hat abgehoben"
        },
        "exampleDE": "Ich hebe am Automaten 50 Euro ab .",
        "exampleEN": "I'm withdrawing 50 euros at the cash machine."
      },
      {
        "id": "v0004",
        "german": "abholen",
        "english": "to pick up",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "holst ab",
          "er": "holt ab",
          "perfekt": "hat abgeholt"
        },
        "exampleDE": "Ich hole dich am Bahnhof ab .",
        "exampleEN": "I'll pick you up at the station."
      },
      {
        "id": "v0005",
        "german": "abnehmen",
        "english": "to lose weight",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "nimmst ab",
          "er": "nimmt ab",
          "perfekt": "hat abgenommen"
        },
        "exampleDE": "Er hat fünf Kilo abgenommen .",
        "exampleEN": "He has lost five kilos."
      },
      {
        "id": "v0006",
        "german": "absagen",
        "english": "to cancel",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "sagst ab",
          "er": "sagt ab",
          "perfekt": "hat abgesagt"
        },
        "exampleDE": "Ich muss den Termin leider absagen .",
        "exampleEN": "Unfortunately I have to cancel the appointment."
      },
      {
        "id": "v0007",
        "german": "abschließen",
        "english": "to lock",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "schließt ab",
          "er": "schließt ab",
          "perfekt": "hat abgeschlossen"
        },
        "exampleDE": "Hast du die Tür abgeschlossen ?",
        "exampleEN": "Did you lock the door?"
      },
      {
        "id": "v0008",
        "german": "anbieten",
        "english": "to offer",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "bietest an",
          "er": "bietet an",
          "perfekt": "hat angeboten"
        },
        "exampleDE": "Darf ich Ihnen einen Tee anbieten ?",
        "exampleEN": "May I offer you a tea?"
      },
      {
        "id": "v0009",
        "german": "ändern",
        "english": "to change",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "änderst",
          "er": "ändert",
          "perfekt": "hat geändert"
        },
        "exampleDE": "Wir müssen unseren Plan ändern .",
        "exampleEN": "We have to change our plan."
      },
      {
        "id": "v0010",
        "german": "anfangen",
        "english": "to start, begin",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "fängst an",
          "er": "fängt an",
          "perfekt": "hat angefangen"
        },
        "exampleDE": "Der Deutschkurs fängt um 9 Uhr an .",
        "exampleEN": "The German course starts at 9 o'clock."
      },
      {
        "id": "v0011",
        "german": "anklicken",
        "english": "to click on",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "klickst an",
          "er": "klickt an",
          "perfekt": "hat angeklickt"
        },
        "exampleDE": "Klicken Sie das Bild an .",
        "exampleEN": "Click on the picture."
      },
      {
        "id": "v0012",
        "german": "ankommen",
        "english": "to arrive",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "kommst an",
          "er": "kommt an",
          "perfekt": "ist angekommen"
        },
        "exampleDE": "Wann kommt der Zug in Berlin an ?",
        "exampleEN": "When does the train arrive in Berlin?"
      },
      {
        "id": "v0013",
        "german": "ankreuzen",
        "english": "to tick, mark with a cross",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "kreuzt an",
          "er": "kreuzt an",
          "perfekt": "hat angekreuzt"
        },
        "exampleDE": "Kreuzen Sie die richtige Antwort an .",
        "exampleEN": "Tick the correct answer."
      },
      {
        "id": "v0014",
        "german": "anmachen",
        "english": "to switch on",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "machst an",
          "er": "macht an",
          "perfekt": "hat angemacht"
        },
        "exampleDE": "Kannst du bitte das Licht anmachen ?",
        "exampleEN": "Can you switch the light on, please?"
      },
      {
        "id": "v0015",
        "german": "sich anmelden",
        "english": "to register, sign up",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "meldest dich an",
          "er": "meldet sich an",
          "perfekt": "hat sich angemeldet"
        },
        "exampleDE": "Ich melde mich für den Kurs an .",
        "exampleEN": "I'm signing up for the course."
      },
      {
        "id": "v0016",
        "german": "anprobieren",
        "english": "to try on",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "probierst an",
          "er": "probiert an",
          "perfekt": "hat anprobiert"
        },
        "exampleDE": "Kann ich die Hose anprobieren ?",
        "exampleEN": "Can I try on the trousers?"
      },
      {
        "id": "v0017",
        "german": "anrufen",
        "english": "to call (phone)",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "rufst an",
          "er": "ruft an",
          "perfekt": "hat angerufen"
        },
        "exampleDE": "Ich rufe dich morgen an .",
        "exampleEN": "I'll call you tomorrow."
      },
      {
        "id": "v0018",
        "german": "sich ansehen",
        "english": "to look at, watch",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "siehst dir an",
          "er": "sieht sich an",
          "perfekt": "hat sich angesehen"
        },
        "exampleDE": "Am Abend sehen wir uns einen Film an .",
        "exampleEN": "In the evening we're watching a film."
      },
      {
        "id": "v0019",
        "german": "antworten",
        "english": "to answer",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "antwortest",
          "er": "antwortet",
          "perfekt": "hat geantwortet"
        },
        "exampleDE": "Bitte antworten Sie schnell.",
        "exampleEN": "Please answer quickly."
      },
      {
        "id": "v0020",
        "german": "sich anziehen",
        "english": "to get dressed",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "ziehst dich an",
          "er": "zieht sich an",
          "perfekt": "hat sich angezogen"
        },
        "exampleDE": "Ich ziehe mich schnell an .",
        "exampleEN": "I get dressed quickly."
      },
      {
        "id": "v0021",
        "german": "arbeiten",
        "english": "to work",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "arbeitest",
          "er": "arbeitet",
          "perfekt": "hat gearbeitet"
        },
        "exampleDE": "Ich arbeite in einem Büro.",
        "exampleEN": "I work in an office."
      },
      {
        "id": "v0022",
        "german": "aufhören",
        "english": "to stop",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "hörst auf",
          "er": "hört auf",
          "perfekt": "hat aufgehört"
        },
        "exampleDE": "Der Kurs hört um 12 Uhr auf .",
        "exampleEN": "The course stops at 12 o'clock."
      },
      {
        "id": "v0023",
        "german": "aufmachen",
        "english": "to open",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "machst auf",
          "er": "macht auf",
          "perfekt": "hat aufgemacht"
        },
        "exampleDE": "Mach bitte das Fenster auf .",
        "exampleEN": "Please open the window."
      },
      {
        "id": "v0024",
        "german": "aufpassen",
        "english": "to be careful; to look after",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "passt auf",
          "er": "passt auf",
          "perfekt": "hat aufgepasst"
        },
        "exampleDE": "Pass auf , die Straße ist glatt!",
        "exampleEN": "Be careful, the road is slippery!"
      },
      {
        "id": "v0025",
        "german": "aufräumen",
        "english": "to tidy up",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "räumst auf",
          "er": "räumt auf",
          "perfekt": "hat aufgeräumt"
        },
        "exampleDE": "Am Samstag räume ich mein Zimmer auf .",
        "exampleEN": "On Saturday I tidy my room."
      },
      {
        "id": "v0026",
        "german": "aufschreiben",
        "english": "to write down",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "schreibst auf",
          "er": "schreibt auf",
          "perfekt": "hat aufgeschrieben"
        },
        "exampleDE": "Ich schreibe mir die Adresse auf .",
        "exampleEN": "I'm writing down the address."
      },
      {
        "id": "v0027",
        "german": "aufstehen",
        "english": "to get up",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "stehst auf",
          "er": "steht auf",
          "perfekt": "ist aufgestanden"
        },
        "exampleDE": "Ich stehe jeden Tag um 7 Uhr auf .",
        "exampleEN": "I get up at 7 o'clock every day."
      },
      {
        "id": "v0028",
        "german": "aufwachen",
        "english": "to wake up",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "wachst auf",
          "er": "wacht auf",
          "perfekt": "ist aufgewacht"
        },
        "exampleDE": "Heute bin ich sehr früh aufgewacht .",
        "exampleEN": "Today I woke up very early."
      },
      {
        "id": "v0029",
        "german": "ausdrucken",
        "english": "to print out",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "druckst aus",
          "er": "druckt aus",
          "perfekt": "hat ausgedruckt"
        },
        "exampleDE": "Kannst du das Ticket ausdrucken ?",
        "exampleEN": "Can you print out the ticket?"
      },
      {
        "id": "v0030",
        "german": "ausfallen",
        "english": "to be cancelled",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "",
          "er": "fällt aus",
          "perfekt": "ist ausgefallen"
        },
        "exampleDE": "Der Zug fällt heute aus .",
        "exampleEN": "The train is cancelled today."
      },
      {
        "id": "v0031",
        "german": "ausfüllen",
        "english": "to fill in (a form)",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "füllst aus",
          "er": "füllt aus",
          "perfekt": "hat ausgefüllt"
        },
        "exampleDE": "Bitte füllen Sie das Formular aus .",
        "exampleEN": "Please fill in the form."
      },
      {
        "id": "v0032",
        "german": "ausgeben",
        "english": "to spend (money)",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "gibst aus",
          "er": "gibt aus",
          "perfekt": "hat ausgegeben"
        },
        "exampleDE": "Wie viel Geld gibst du für Essen aus ?",
        "exampleEN": "How much money do you spend on food?"
      },
      {
        "id": "v0033",
        "german": "ausgehen",
        "english": "to go out",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "gehst aus",
          "er": "geht aus",
          "perfekt": "ist ausgegangen"
        },
        "exampleDE": "Am Samstag gehen wir zusammen aus .",
        "exampleEN": "On Saturday we're going out together."
      },
      {
        "id": "v0034",
        "german": "ausmachen",
        "english": "to switch off",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "machst aus",
          "er": "macht aus",
          "perfekt": "hat ausgemacht"
        },
        "exampleDE": "Mach bitte den Fernseher aus .",
        "exampleEN": "Please switch off the TV."
      },
      {
        "id": "v0035",
        "german": "auspacken",
        "english": "to unpack",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "packst aus",
          "er": "packt aus",
          "perfekt": "hat ausgepackt"
        },
        "exampleDE": "Ich packe den Koffer aus .",
        "exampleEN": "I'm unpacking the suitcase."
      },
      {
        "id": "v0036",
        "german": "sich ausruhen",
        "english": "to rest",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "ruhst dich aus",
          "er": "ruht sich aus",
          "perfekt": "hat sich ausgeruht"
        },
        "exampleDE": "Nach der Arbeit ruhe ich mich aus .",
        "exampleEN": "After work I have a rest."
      },
      {
        "id": "v0037",
        "german": "ausschalten",
        "english": "to switch off",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "schaltest aus",
          "er": "schaltet aus",
          "perfekt": "hat ausgeschaltet"
        },
        "exampleDE": "Bitte schalten Sie das Handy aus .",
        "exampleEN": "Please switch off your mobile."
      },
      {
        "id": "v0038",
        "german": "aussehen",
        "english": "to look (appear)",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "siehst aus",
          "er": "sieht aus",
          "perfekt": "hat ausgesehen"
        },
        "exampleDE": "Du siehst heute sehr gut aus !",
        "exampleEN": "You look very good today!"
      },
      {
        "id": "v0039",
        "german": "aussprechen",
        "english": "to pronounce",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "sprichst aus",
          "er": "spricht aus",
          "perfekt": "hat ausgesprochen"
        },
        "exampleDE": "Wie spricht man das Wort aus ?",
        "exampleEN": "How do you pronounce the word?"
      },
      {
        "id": "v0040",
        "german": "aussteigen",
        "english": "to get off / out",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "steigst aus",
          "er": "steigt aus",
          "perfekt": "ist ausgestiegen"
        },
        "exampleDE": "Wir steigen am Marktplatz aus .",
        "exampleEN": "We get off at the market square."
      },
      {
        "id": "v0041",
        "german": "ausziehen",
        "english": "to move out",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "ziehst aus",
          "er": "zieht aus",
          "perfekt": "ist ausgezogen"
        },
        "exampleDE": "Wir ziehen im Mai aus der Wohnung aus .",
        "exampleEN": "We're moving out of the flat in May."
      },
      {
        "id": "v0042",
        "german": "backen",
        "english": "to bake",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "backst",
          "er": "backt",
          "perfekt": "hat gebacken"
        },
        "exampleDE": "Meine Mutter backt einen Kuchen.",
        "exampleEN": "My mother is baking a cake."
      },
      {
        "id": "v0043",
        "german": "baden",
        "english": "to have a bath; to swim",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "badest",
          "er": "badet",
          "perfekt": "hat gebadet"
        },
        "exampleDE": "Das Baby badet jeden Abend.",
        "exampleEN": "The baby has a bath every evening."
      },
      {
        "id": "v0044",
        "german": "bauen",
        "english": "to build",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "baust",
          "er": "baut",
          "perfekt": "hat gebaut"
        },
        "exampleDE": "Meine Eltern bauen ein Haus.",
        "exampleEN": "My parents are building a house."
      },
      {
        "id": "v0045",
        "german": "beantragen",
        "english": "to apply for (officially)",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "beantragst",
          "er": "beantragt",
          "perfekt": "hat beantragt"
        },
        "exampleDE": "Ich muss ein Visum beantragen .",
        "exampleEN": "I have to apply for a visa."
      },
      {
        "id": "v0046",
        "german": "beantworten",
        "english": "to answer (sth)",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "beantwortest",
          "er": "beantwortet",
          "perfekt": "hat beantwortet"
        },
        "exampleDE": "Bitte beantworten Sie die Fragen.",
        "exampleEN": "Please answer the questions."
      },
      {
        "id": "v0047",
        "german": "bedeuten",
        "english": "to mean",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "",
          "er": "bedeutet",
          "perfekt": "hat bedeutet"
        },
        "exampleDE": "Was bedeutet das Wort?",
        "exampleEN": "What does the word mean?"
      },
      {
        "id": "v0048",
        "german": "sich beeilen",
        "english": "to hurry",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "beeilst dich",
          "er": "beeilt sich",
          "perfekt": "hat sich beeilt"
        },
        "exampleDE": "Beeil dich, der Bus kommt!",
        "exampleEN": "Hurry up, the bus is coming!"
      },
      {
        "id": "v0049",
        "german": "beginnen",
        "english": "to begin",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "beginnst",
          "er": "beginnt",
          "perfekt": "hat begonnen"
        },
        "exampleDE": "Der Film beginnt um 20 Uhr.",
        "exampleEN": "The film begins at 8 p.m."
      },
      {
        "id": "v0050",
        "german": "begründen",
        "english": "to give reasons for",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "begründest",
          "er": "begründet",
          "perfekt": "hat begründet"
        },
        "exampleDE": "Begründen Sie Ihre Meinung.",
        "exampleEN": "Give reasons for your opinion."
      },
      {
        "id": "v0051",
        "german": "bekommen",
        "english": "to get, receive",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "bekommst",
          "er": "bekommt",
          "perfekt": "hat bekommen"
        },
        "exampleDE": "Ich bekomme viele E-Mails.",
        "exampleEN": "I get a lot of emails."
      },
      {
        "id": "v0052",
        "german": "benutzen",
        "english": "to use",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "benutzt",
          "er": "benutzt",
          "perfekt": "hat benutzt"
        },
        "exampleDE": "Darf ich dein Handy benutzen ?",
        "exampleEN": "May I use your phone?"
      },
      {
        "id": "v0053",
        "german": "beraten",
        "english": "to advise",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "berätst",
          "er": "berät",
          "perfekt": "hat beraten"
        },
        "exampleDE": "Die Verkäuferin berät mich gut.",
        "exampleEN": "The shop assistant gives me good advice."
      },
      {
        "id": "v0054",
        "german": "berichten",
        "english": "to report",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "berichtest",
          "er": "berichtet",
          "perfekt": "hat berichtet"
        },
        "exampleDE": "Er berichtet von seiner Reise.",
        "exampleEN": "He reports on his trip."
      },
      {
        "id": "v0055",
        "german": "beschreiben",
        "english": "to describe",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "beschreibst",
          "er": "beschreibt",
          "perfekt": "hat beschrieben"
        },
        "exampleDE": "Können Sie den Weg beschreiben ?",
        "exampleEN": "Can you describe the way?"
      },
      {
        "id": "v0056",
        "german": "besichtigen",
        "english": "to visit, see (sights)",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "besichtigst",
          "er": "besichtigt",
          "perfekt": "hat besichtigt"
        },
        "exampleDE": "Heute besichtigen wir die Stadt.",
        "exampleEN": "Today we're seeing the sights of the town."
      },
      {
        "id": "v0057",
        "german": "besprechen",
        "english": "to discuss",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "besprichst",
          "er": "bespricht",
          "perfekt": "hat besprochen"
        },
        "exampleDE": "Das besprechen wir morgen im Team.",
        "exampleEN": "We'll discuss that in the team tomorrow."
      },
      {
        "id": "v0058",
        "german": "bestätigen",
        "english": "to confirm",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "bestätigst",
          "er": "bestätigt",
          "perfekt": "hat bestätigt"
        },
        "exampleDE": "Bitte bestätigen Sie den Termin.",
        "exampleEN": "Please confirm the appointment."
      },
      {
        "id": "v0059",
        "german": "bestehen",
        "english": "to pass (an exam)",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "bestehst",
          "er": "besteht",
          "perfekt": "hat bestanden"
        },
        "exampleDE": "Ich habe die Prüfung bestanden !",
        "exampleEN": "I passed the exam!"
      },
      {
        "id": "v0060",
        "german": "bestellen",
        "english": "to order",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "bestellst",
          "er": "bestellt",
          "perfekt": "hat bestellt"
        },
        "exampleDE": "Ich bestelle eine Pizza.",
        "exampleEN": "I'm ordering a pizza."
      },
      {
        "id": "v0061",
        "german": "besuchen",
        "english": "to visit",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "besuchst",
          "er": "besucht",
          "perfekt": "hat besucht"
        },
        "exampleDE": "Am Sonntag besuche ich meine Oma.",
        "exampleEN": "On Sunday I'm visiting my grandma."
      },
      {
        "id": "v0062",
        "german": "bezahlen",
        "english": "to pay",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "bezahlst",
          "er": "bezahlt",
          "perfekt": "hat bezahlt"
        },
        "exampleDE": "Kann ich mit Karte bezahlen ?",
        "exampleEN": "Can I pay by card?"
      },
      {
        "id": "v0063",
        "german": "bitten",
        "english": "to ask (for a favour)",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "bittest",
          "er": "bittet",
          "perfekt": "hat gebeten"
        },
        "exampleDE": "Darf ich Sie um Hilfe bitten ?",
        "exampleEN": "May I ask you for help?"
      },
      {
        "id": "v0064",
        "german": "bleiben",
        "english": "to stay",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "bleibst",
          "er": "bleibt",
          "perfekt": "ist geblieben"
        },
        "exampleDE": "Heute bleibe ich zu Hause.",
        "exampleEN": "Today I'm staying at home."
      },
      {
        "id": "v0065",
        "german": "braten",
        "english": "to fry",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "brätst",
          "er": "brät",
          "perfekt": "hat gebraten"
        },
        "exampleDE": "Ich brate die Eier in der Pfanne.",
        "exampleEN": "I'm frying the eggs in the pan."
      },
      {
        "id": "v0066",
        "german": "brauchen",
        "english": "to need",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "brauchst",
          "er": "braucht",
          "perfekt": "hat gebraucht"
        },
        "exampleDE": "Ich brauche einen Stift.",
        "exampleEN": "I need a pen."
      },
      {
        "id": "v0067",
        "german": "bringen",
        "english": "to bring",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "bringst",
          "er": "bringt",
          "perfekt": "hat gebracht"
        },
        "exampleDE": "Der Kellner bringt das Essen.",
        "exampleEN": "The waiter brings the food."
      },
      {
        "id": "v0068",
        "german": "buchen",
        "english": "to book",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "buchst",
          "er": "bucht",
          "perfekt": "hat gebucht"
        },
        "exampleDE": "Ich möchte ein Zimmer buchen .",
        "exampleEN": "I'd like to book a room."
      },
      {
        "id": "v0069",
        "german": "buchstabieren",
        "english": "to spell",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "buchstabierst",
          "er": "buchstabiert",
          "perfekt": "hat buchstabiert"
        },
        "exampleDE": "Können Sie Ihren Namen bitte buchstabieren ?",
        "exampleEN": "Can you spell your name, please?"
      },
      {
        "id": "v0070",
        "german": "chatten",
        "english": "to chat (online)",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "chattest",
          "er": "chattet",
          "perfekt": "hat gechattet"
        },
        "exampleDE": "Abends chatte ich mit meiner Familie.",
        "exampleEN": "In the evening I chat with my family online."
      },
      {
        "id": "v0071",
        "german": "danken",
        "english": "to thank",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "dankst",
          "er": "dankt",
          "perfekt": "hat gedankt"
        },
        "exampleDE": "Ich danke Ihnen für die Hilfe.",
        "exampleEN": "Thank you for your help."
      },
      {
        "id": "v0072",
        "german": "dauern",
        "english": "to last, take (time)",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "",
          "er": "dauert",
          "perfekt": "hat gedauert"
        },
        "exampleDE": "Der Kurs dauert drei Monate.",
        "exampleEN": "The course lasts three months."
      },
      {
        "id": "v0073",
        "german": "denken",
        "english": "to think",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "denkst",
          "er": "denkt",
          "perfekt": "hat gedacht"
        },
        "exampleDE": "Ich denke oft an dich.",
        "exampleEN": "I often think of you."
      },
      {
        "id": "v0074",
        "german": "diskutieren",
        "english": "to discuss",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "diskutierst",
          "er": "diskutiert",
          "perfekt": "hat diskutiert"
        },
        "exampleDE": "Wir diskutieren über das Thema.",
        "exampleEN": "We're discussing the topic."
      },
      {
        "id": "v0075",
        "german": "drucken",
        "english": "to print",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "druckst",
          "er": "druckt",
          "perfekt": "hat gedruckt"
        },
        "exampleDE": "Der Drucker druckt nicht.",
        "exampleEN": "The printer isn't printing."
      },
      {
        "id": "v0076",
        "german": "dürfen",
        "english": "may, to be allowed to",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "darfst",
          "er": "darf",
          "perfekt": "hat gedurft"
        },
        "exampleDE": "Hier darf man nicht parken.",
        "exampleEN": "You're not allowed to park here."
      },
      {
        "id": "v0077",
        "german": "duschen",
        "english": "to have a shower",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "duschst",
          "er": "duscht",
          "perfekt": "hat geduscht"
        },
        "exampleDE": "Ich dusche jeden Morgen.",
        "exampleEN": "I have a shower every morning."
      },
      {
        "id": "v0078",
        "german": "einkaufen",
        "english": "to go shopping",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "kaufst ein",
          "er": "kauft ein",
          "perfekt": "hat eingekauft"
        },
        "exampleDE": "Ich kaufe im Supermarkt ein .",
        "exampleEN": "I do my shopping at the supermarket."
      },
      {
        "id": "v0079",
        "german": "einladen",
        "english": "to invite",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "lädst ein",
          "er": "lädt ein",
          "perfekt": "hat eingeladen"
        },
        "exampleDE": "Ich lade dich zu meinem Geburtstag ein .",
        "exampleEN": "I'm inviting you to my birthday."
      },
      {
        "id": "v0080",
        "german": "einpacken",
        "english": "to pack; to wrap",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "packst ein",
          "er": "packt ein",
          "perfekt": "hat eingepackt"
        },
        "exampleDE": "Hast du die Geschenke schon eingepackt ?",
        "exampleEN": "Have you wrapped the presents yet?"
      },
      {
        "id": "v0081",
        "german": "einrichten",
        "english": "to furnish",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "richtest ein",
          "er": "richtet ein",
          "perfekt": "hat eingerichtet"
        },
        "exampleDE": "Wir richten die neue Wohnung ein .",
        "exampleEN": "We're furnishing the new flat."
      },
      {
        "id": "v0082",
        "german": "einschalten",
        "english": "to switch on",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "schaltest ein",
          "er": "schaltet ein",
          "perfekt": "hat eingeschaltet"
        },
        "exampleDE": "Kannst du die Heizung einschalten ?",
        "exampleEN": "Can you switch on the heating?"
      },
      {
        "id": "v0083",
        "german": "einschlafen",
        "english": "to fall asleep",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "schläfst ein",
          "er": "schläft ein",
          "perfekt": "ist eingeschlafen"
        },
        "exampleDE": "Gestern bin ich vor dem Fernseher eingeschlafen .",
        "exampleEN": "Yesterday I fell asleep in front of the TV."
      },
      {
        "id": "v0084",
        "german": "einsteigen",
        "english": "to get on / in",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "steigst ein",
          "er": "steigt ein",
          "perfekt": "ist eingestiegen"
        },
        "exampleDE": "Bitte steigen Sie schnell ein .",
        "exampleEN": "Please get on quickly."
      },
      {
        "id": "v0085",
        "german": "eintragen",
        "english": "to enter, fill in",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "trägst ein",
          "er": "trägt ein",
          "perfekt": "hat eingetragen"
        },
        "exampleDE": "Tragen Sie Ihren Namen hier ein .",
        "exampleEN": "Enter your name here."
      },
      {
        "id": "v0086",
        "german": "einziehen",
        "english": "to move in",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "ziehst ein",
          "er": "zieht ein",
          "perfekt": "ist eingezogen"
        },
        "exampleDE": "Nächste Woche ziehen wir ein .",
        "exampleEN": "We're moving in next week."
      },
      {
        "id": "v0087",
        "german": "empfehlen",
        "english": "to recommend",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "empfiehlst",
          "er": "empfiehlt",
          "perfekt": "hat empfohlen"
        },
        "exampleDE": "Was empfehlen Sie heute?",
        "exampleEN": "What do you recommend today?"
      },
      {
        "id": "v0088",
        "german": "enden",
        "english": "to end",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "",
          "er": "endet",
          "perfekt": "hat geendet"
        },
        "exampleDE": "Der Kurs endet im Juli.",
        "exampleEN": "The course ends in July."
      },
      {
        "id": "v0089",
        "german": "sich entscheiden",
        "english": "to decide",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "entscheidest dich",
          "er": "entscheidet sich",
          "perfekt": "hat sich entschieden"
        },
        "exampleDE": "Ich kann mich nicht entscheiden .",
        "exampleEN": "I can't decide."
      },
      {
        "id": "v0090",
        "german": "ergänzen",
        "english": "to complete, fill in",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "ergänzt",
          "er": "ergänzt",
          "perfekt": "hat ergänzt"
        },
        "exampleDE": "Ergänzen Sie die Sätze.",
        "exampleEN": "Complete the sentences."
      },
      {
        "id": "v0091",
        "german": "sich erholen",
        "english": "to recover, relax",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "erholst dich",
          "er": "erholt sich",
          "perfekt": "hat sich erholt"
        },
        "exampleDE": "Im Urlaub erhole ich mich gut.",
        "exampleEN": "On holiday I relax well."
      },
      {
        "id": "v0092",
        "german": "sich erkälten",
        "english": "to catch a cold",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "erkältest dich",
          "er": "erkältet sich",
          "perfekt": "hat sich erkältet"
        },
        "exampleDE": "Ich habe mich erkältet .",
        "exampleEN": "I've caught a cold."
      },
      {
        "id": "v0093",
        "german": "erklären",
        "english": "to explain",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "erklärst",
          "er": "erklärt",
          "perfekt": "hat erklärt"
        },
        "exampleDE": "Die Lehrerin erklärt die Grammatik.",
        "exampleEN": "The teacher explains the grammar."
      },
      {
        "id": "v0094",
        "german": "erlauben",
        "english": "to allow",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "erlaubst",
          "er": "erlaubt",
          "perfekt": "hat erlaubt"
        },
        "exampleDE": "Rauchen ist hier nicht erlaubt .",
        "exampleEN": "Smoking is not allowed here."
      },
      {
        "id": "v0095",
        "german": "erleben",
        "english": "to experience",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "erlebst",
          "er": "erlebt",
          "perfekt": "hat erlebt"
        },
        "exampleDE": "Im Urlaub haben wir viel erlebt .",
        "exampleEN": "We experienced a lot on holiday."
      },
      {
        "id": "v0096",
        "german": "erreichen",
        "english": "to reach",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "erreichst",
          "er": "erreicht",
          "perfekt": "hat erreicht"
        },
        "exampleDE": "Ich kann ihn nicht erreichen .",
        "exampleEN": "I can't reach him."
      },
      {
        "id": "v0097",
        "german": "erzählen",
        "english": "to tell",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "erzählst",
          "er": "erzählt",
          "perfekt": "hat erzählt"
        },
        "exampleDE": "Erzähl mal, wie war dein Tag?",
        "exampleEN": "Tell me, how was your day?"
      },
      {
        "id": "v0098",
        "german": "essen",
        "english": "to eat",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "isst",
          "er": "isst",
          "perfekt": "hat gegessen"
        },
        "exampleDE": "Wir essen um 13 Uhr zu Mittag.",
        "exampleEN": "We have lunch at 1 p.m."
      },
      {
        "id": "v0099",
        "german": "fahren",
        "english": "to go, drive (by vehicle)",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "fährst",
          "er": "fährt",
          "perfekt": "ist gefahren"
        },
        "exampleDE": "Ich fahre mit dem Bus zur Arbeit.",
        "exampleEN": "I go to work by bus."
      },
      {
        "id": "v0100",
        "german": "fallen",
        "english": "to fall",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "fällst",
          "er": "fällt",
          "perfekt": "ist gefallen"
        },
        "exampleDE": "Das Kind ist vom Fahrrad gefallen .",
        "exampleEN": "The child fell off the bike."
      },
      {
        "id": "v0101",
        "german": "fehlen",
        "english": "to be missing; to be absent",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "fehlst",
          "er": "fehlt",
          "perfekt": "hat gefehlt"
        },
        "exampleDE": "Wer fehlt heute?",
        "exampleEN": "Who is absent today?"
      },
      {
        "id": "v0102",
        "german": "feiern",
        "english": "to celebrate",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "feierst",
          "er": "feiert",
          "perfekt": "hat gefeiert"
        },
        "exampleDE": "Am Samstag feiern wir eine Party.",
        "exampleEN": "On Saturday we're having a party."
      },
      {
        "id": "v0103",
        "german": "fernsehen",
        "english": "to watch TV",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "siehst fern",
          "er": "sieht fern",
          "perfekt": "hat ferngesehen"
        },
        "exampleDE": "Am Abend sehe ich gern fern .",
        "exampleEN": "In the evening I like watching TV."
      },
      {
        "id": "v0104",
        "german": "finden",
        "english": "to find; to think",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "findest",
          "er": "findet",
          "perfekt": "hat gefunden"
        },
        "exampleDE": "Ich finde meinen Schlüssel nicht.",
        "exampleEN": "I can't find my key."
      },
      {
        "id": "v0105",
        "german": "fliegen",
        "english": "to fly",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "fliegst",
          "er": "fliegt",
          "perfekt": "ist geflogen"
        },
        "exampleDE": "Im Sommer fliegen wir nach Spanien.",
        "exampleEN": "In the summer we're flying to Spain."
      },
      {
        "id": "v0106",
        "german": "fotografieren",
        "english": "to take photos",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "fotografierst",
          "er": "fotografiert",
          "perfekt": "hat fotografiert"
        },
        "exampleDE": "Ich fotografiere gern Blumen.",
        "exampleEN": "I like taking photos of flowers."
      },
      {
        "id": "v0107",
        "german": "fragen",
        "english": "to ask",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "fragst",
          "er": "fragt",
          "perfekt": "hat gefragt"
        },
        "exampleDE": "Darf ich etwas fragen ?",
        "exampleEN": "May I ask something?"
      },
      {
        "id": "v0108",
        "german": "frühstücken",
        "english": "to have breakfast",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "frühstückst",
          "er": "frühstückt",
          "perfekt": "hat gefrühstückt"
        },
        "exampleDE": "Wir frühstücken um halb acht.",
        "exampleEN": "We have breakfast at half past seven."
      },
      {
        "id": "v0109",
        "german": "sich fühlen",
        "english": "to feel",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "fühlst dich",
          "er": "fühlt sich",
          "perfekt": "hat sich gefühlt"
        },
        "exampleDE": "Ich fühle mich heute nicht gut.",
        "exampleEN": "I don't feel well today."
      },
      {
        "id": "v0110",
        "german": "funktionieren",
        "english": "to work, function",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "",
          "er": "funktioniert",
          "perfekt": "hat funktioniert"
        },
        "exampleDE": "Der Computer funktioniert nicht.",
        "exampleEN": "The computer isn't working."
      },
      {
        "id": "v0111",
        "german": "geben",
        "english": "to give",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "gibst",
          "er": "gibt",
          "perfekt": "hat gegeben"
        },
        "exampleDE": "Gibst du mir bitte das Salz?",
        "exampleEN": "Can you pass me the salt, please?"
      },
      {
        "id": "v0112",
        "german": "gefallen",
        "english": "to please (= to like)",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "gefällst",
          "er": "gefällt",
          "perfekt": "hat gefallen"
        },
        "exampleDE": "Die Wohnung gefällt mir sehr gut.",
        "exampleEN": "I like the flat very much."
      },
      {
        "id": "v0113",
        "german": "gehen",
        "english": "to go, walk",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "gehst",
          "er": "geht",
          "perfekt": "ist gegangen"
        },
        "exampleDE": "Ich gehe zu Fuß zur Schule.",
        "exampleEN": "I walk to school."
      },
      {
        "id": "v0114",
        "german": "gehören",
        "english": "to belong to",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "gehörst",
          "er": "gehört",
          "perfekt": "hat gehört"
        },
        "exampleDE": "Gehört die Tasche Ihnen?",
        "exampleEN": "Does the bag belong to you?"
      },
      {
        "id": "v0115",
        "german": "gewinnen",
        "english": "to win",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "gewinnst",
          "er": "gewinnt",
          "perfekt": "hat gewonnen"
        },
        "exampleDE": "Unsere Mannschaft hat gewonnen .",
        "exampleEN": "Our team won."
      },
      {
        "id": "v0116",
        "german": "gießen",
        "english": "to water (plants)",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "gießt",
          "er": "gießt",
          "perfekt": "hat gegossen"
        },
        "exampleDE": "Kannst du die Blumen gießen ?",
        "exampleEN": "Can you water the flowers?"
      },
      {
        "id": "v0117",
        "german": "glauben",
        "english": "to believe, think",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "glaubst",
          "er": "glaubt",
          "perfekt": "hat geglaubt"
        },
        "exampleDE": "Ich glaube , der Bus kommt gleich.",
        "exampleEN": "I think the bus is coming soon."
      },
      {
        "id": "v0118",
        "german": "grillen",
        "english": "to barbecue",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "grillst",
          "er": "grillt",
          "perfekt": "hat gegrillt"
        },
        "exampleDE": "Am Sonntag grillen wir im Park.",
        "exampleEN": "On Sunday we're having a barbecue in the park."
      },
      {
        "id": "v0119",
        "german": "haben",
        "english": "to have",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "hast",
          "er": "er",
          "perfekt": "hat hat gehabt"
        },
        "exampleDE": "Ich habe zwei Kinder.",
        "exampleEN": "I have two children."
      },
      {
        "id": "v0120",
        "german": "halten",
        "english": "to stop; to hold",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "hältst",
          "er": "hält",
          "perfekt": "hat gehalten"
        },
        "exampleDE": "Der Bus hält direkt vor dem Haus.",
        "exampleEN": "The bus stops right outside the house."
      },
      {
        "id": "v0121",
        "german": "hängen",
        "english": "to hang (sth up)",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "hängst",
          "er": "hängt",
          "perfekt": "hat gehängt"
        },
        "exampleDE": "Ich hänge das Bild an die Wand.",
        "exampleEN": "I'm hanging the picture on the wall."
      },
      {
        "id": "v0122",
        "german": "heiraten",
        "english": "to marry",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "heiratest",
          "er": "heiratet",
          "perfekt": "hat geheiratet"
        },
        "exampleDE": "Wir haben 2024 geheiratet .",
        "exampleEN": "We got married in 2024."
      },
      {
        "id": "v0123",
        "german": "heißen",
        "english": "to be called",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "heißt",
          "er": "heißt",
          "perfekt": "hat geheißen"
        },
        "exampleDE": "Wie heißen Sie?",
        "exampleEN": "What's your name?"
      },
      {
        "id": "v0124",
        "german": "helfen",
        "english": "to help",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "hilfst",
          "er": "hilft",
          "perfekt": "hat geholfen"
        },
        "exampleDE": "Kannst du mir bitte helfen ?",
        "exampleEN": "Can you help me, please?"
      },
      {
        "id": "v0125",
        "german": "herunterladen",
        "english": "to download",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "lädst herunter",
          "er": "lädt herunter",
          "perfekt": "hat heruntergeladen"
        },
        "exampleDE": "Ich lade die App herunter .",
        "exampleEN": "I'm downloading the app."
      },
      {
        "id": "v0126",
        "german": "hoffen",
        "english": "to hope",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "hoffst",
          "er": "hofft",
          "perfekt": "hat gehofft"
        },
        "exampleDE": "Ich hoffe , das Wetter wird gut.",
        "exampleEN": "I hope the weather will be good."
      },
      {
        "id": "v0127",
        "german": "holen",
        "english": "to fetch, get",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "holst",
          "er": "holt",
          "perfekt": "hat geholt"
        },
        "exampleDE": "Ich hole schnell Brot.",
        "exampleEN": "I'll quickly get some bread."
      },
      {
        "id": "v0128",
        "german": "hören",
        "english": "to hear, listen to",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "hörst",
          "er": "hört",
          "perfekt": "hat gehört"
        },
        "exampleDE": "Ich höre gern Musik.",
        "exampleEN": "I like listening to music."
      },
      {
        "id": "v0129",
        "german": "husten",
        "english": "to cough",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "hustest",
          "er": "hustet",
          "perfekt": "hat gehustet"
        },
        "exampleDE": "Er hustet seit drei Tagen.",
        "exampleEN": "He has been coughing for three days."
      },
      {
        "id": "v0130",
        "german": "sich informieren",
        "english": "to find out, get information",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "informierst dich",
          "er": "informiert sich",
          "perfekt": "hat sich informiert"
        },
        "exampleDE": "Ich informiere mich im Internet.",
        "exampleEN": "I'm finding out online."
      },
      {
        "id": "v0131",
        "german": "joggen",
        "english": "to jog",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "joggst",
          "er": "joggt",
          "perfekt": "ist gejoggt"
        },
        "exampleDE": "Am Morgen jogge ich im Park.",
        "exampleEN": "In the morning I go jogging in the park."
      },
      {
        "id": "v0132",
        "german": "kaufen",
        "english": "to buy",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "kaufst",
          "er": "kauft",
          "perfekt": "hat gekauft"
        },
        "exampleDE": "Ich kaufe ein Kilo Äpfel.",
        "exampleEN": "I'm buying a kilo of apples."
      },
      {
        "id": "v0133",
        "german": "kennen",
        "english": "to know (a person, place)",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "kennst",
          "er": "kennt",
          "perfekt": "hat gekannt"
        },
        "exampleDE": "Kennst du meinen Bruder?",
        "exampleEN": "Do you know my brother?"
      },
      {
        "id": "v0134",
        "german": "kennenlernen",
        "english": "to get to know, meet",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "lernst kennen",
          "er": "lernt kennen",
          "perfekt": "hat kennengelernt"
        },
        "exampleDE": "Ich möchte neue Leute kennenlernen .",
        "exampleEN": "I'd like to meet new people."
      },
      {
        "id": "v0135",
        "german": "klappen",
        "english": "to work out",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "",
          "er": "klappt",
          "perfekt": "hat geklappt"
        },
        "exampleDE": "Hat alles geklappt ?",
        "exampleEN": "Did everything work out?"
      },
      {
        "id": "v0136",
        "german": "klingeln",
        "english": "to ring",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "",
          "er": "klingelt",
          "perfekt": "hat geklingelt"
        },
        "exampleDE": "Es klingelt . Wer ist das?",
        "exampleEN": "The doorbell is ringing. Who is that?"
      },
      {
        "id": "v0137",
        "german": "kochen",
        "english": "to cook",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "kochst",
          "er": "kocht",
          "perfekt": "hat gekocht"
        },
        "exampleDE": "Mein Mann kocht sehr gut.",
        "exampleEN": "My husband cooks very well."
      },
      {
        "id": "v0138",
        "german": "kommen",
        "english": "to come",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "kommst",
          "er": "kommt",
          "perfekt": "ist gekommen"
        },
        "exampleDE": "Woher kommen Sie?",
        "exampleEN": "Where are you from?"
      },
      {
        "id": "v0139",
        "german": "können",
        "english": "can, to be able to",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "kannst",
          "er": "kann",
          "perfekt": "hat gekonnt"
        },
        "exampleDE": "Ich kann gut schwimmen.",
        "exampleEN": "I can swim well."
      },
      {
        "id": "v0140",
        "german": "kontrollieren",
        "english": "to check",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "kontrollierst",
          "er": "kontrolliert",
          "perfekt": "hat kontrolliert"
        },
        "exampleDE": "Im Zug kontrolliert man die Tickets.",
        "exampleEN": "On the train they check the tickets."
      },
      {
        "id": "v0141",
        "german": "kosten",
        "english": "to cost",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "",
          "er": "kostet",
          "perfekt": "hat gekostet"
        },
        "exampleDE": "Was kostet das Brot?",
        "exampleEN": "How much is the bread?"
      },
      {
        "id": "v0142",
        "german": "kriegen",
        "english": "to get (informal)",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "kriegst",
          "er": "kriegt",
          "perfekt": "hat gekriegt"
        },
        "exampleDE": "Ich habe eine E-Mail gekriegt .",
        "exampleEN": "I got an email."
      },
      {
        "id": "v0143",
        "german": "sich kümmern",
        "english": "to take care of",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "kümmerst dich",
          "er": "kümmert sich",
          "perfekt": "hat sich gekümmert"
        },
        "exampleDE": "Ich kümmere mich um die Kinder.",
        "exampleEN": "I take care of the children."
      },
      {
        "id": "v0144",
        "german": "kündigen",
        "english": "to quit; to cancel (a contract)",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "kündigst",
          "er": "kündigt",
          "perfekt": "hat gekündigt"
        },
        "exampleDE": "Ich habe meinen Handyvertrag gekündigt .",
        "exampleEN": "I've cancelled my mobile contract."
      },
      {
        "id": "v0145",
        "german": "lachen",
        "english": "to laugh",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "lachst",
          "er": "lacht",
          "perfekt": "hat gelacht"
        },
        "exampleDE": "Die Kinder lachen viel.",
        "exampleEN": "The children laugh a lot."
      },
      {
        "id": "v0146",
        "german": "landen",
        "english": "to land",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "landest",
          "er": "landet",
          "perfekt": "ist gelandet"
        },
        "exampleDE": "Das Flugzeug ist pünktlich gelandet .",
        "exampleEN": "The plane landed on time."
      },
      {
        "id": "v0147",
        "german": "sich langweilen",
        "english": "to be bored",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "langweilst dich",
          "er": "langweilt sich",
          "perfekt": "hat sich gelangweilt"
        },
        "exampleDE": "Die Kinder langweilen sich.",
        "exampleEN": "The children are bored."
      },
      {
        "id": "v0148",
        "german": "lassen",
        "english": "to leave; to let",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "lässt",
          "er": "lässt",
          "perfekt": "hat gelassen"
        },
        "exampleDE": "Lass das Handy zu Hause.",
        "exampleEN": "Leave your phone at home."
      },
      {
        "id": "v0149",
        "german": "laufen",
        "english": "to run; to walk",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "läufst",
          "er": "läuft",
          "perfekt": "ist gelaufen"
        },
        "exampleDE": "Er läuft jeden Morgen im Park.",
        "exampleEN": "He runs in the park every morning."
      },
      {
        "id": "v0150",
        "german": "leben",
        "english": "to live",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "lebst",
          "er": "lebt",
          "perfekt": "hat gelebt"
        },
        "exampleDE": "Meine Eltern leben in Italien.",
        "exampleEN": "My parents live in Italy."
      },
      {
        "id": "v0151",
        "german": "legen",
        "english": "to put, lay (flat)",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "legst",
          "er": "legt",
          "perfekt": "hat gelegt"
        },
        "exampleDE": "Leg das Buch auf den Tisch.",
        "exampleEN": "Put the book on the table."
      },
      {
        "id": "v0152",
        "german": "leidtun",
        "english": "to be sorry",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "",
          "er": "tut mir leid",
          "perfekt": "hat leidgetan"
        },
        "exampleDE": "Es tut mir leid , ich bin zu spät.",
        "exampleEN": "I'm sorry, I'm late."
      },
      {
        "id": "v0153",
        "german": "leihen",
        "english": "to lend; to borrow",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "leihst",
          "er": "leiht",
          "perfekt": "hat geliehen"
        },
        "exampleDE": "Kannst du mir dein Fahrrad leihen ?",
        "exampleEN": "Can you lend me your bike?"
      },
      {
        "id": "v0154",
        "german": "lernen",
        "english": "to learn, study",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "lernst",
          "er": "lernt",
          "perfekt": "hat gelernt"
        },
        "exampleDE": "Ich lerne seit drei Monaten Deutsch.",
        "exampleEN": "I've been learning German for three months."
      },
      {
        "id": "v0155",
        "german": "lesen",
        "english": "to read",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "liest",
          "er": "liest",
          "perfekt": "hat gelesen"
        },
        "exampleDE": "Ich lese gern Bücher.",
        "exampleEN": "I like reading books."
      },
      {
        "id": "v0156",
        "german": "lieben",
        "english": "to love",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "liebst",
          "er": "liebt",
          "perfekt": "hat geliebt"
        },
        "exampleDE": "Ich liebe meine Familie.",
        "exampleEN": "I love my family."
      },
      {
        "id": "v0157",
        "german": "liefern",
        "english": "to deliver",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "lieferst",
          "er": "liefert",
          "perfekt": "hat geliefert"
        },
        "exampleDE": "Der Shop liefert das Paket morgen.",
        "exampleEN": "The shop is delivering the parcel tomorrow."
      },
      {
        "id": "v0158",
        "german": "liegen",
        "english": "to lie; to be (located)",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "liegst",
          "er": "liegt",
          "perfekt": "hat gelegen"
        },
        "exampleDE": "Das Buch liegt auf dem Tisch.",
        "exampleEN": "The book is on the table."
      },
      {
        "id": "v0159",
        "german": "lügen",
        "english": "to lie (not tell the truth)",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "lügst",
          "er": "lügt",
          "perfekt": "hat gelogen"
        },
        "exampleDE": "Er hat nicht gelogen .",
        "exampleEN": "He didn't lie."
      },
      {
        "id": "v0160",
        "german": "machen",
        "english": "to do, make",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "machst",
          "er": "macht",
          "perfekt": "hat gemacht"
        },
        "exampleDE": "Was machst du am Wochenende?",
        "exampleEN": "What are you doing at the weekend?"
      },
      {
        "id": "v0161",
        "german": "malen",
        "english": "to paint, draw",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "malst",
          "er": "malt",
          "perfekt": "hat gemalt"
        },
        "exampleDE": "Meine Tochter malt gern.",
        "exampleEN": "My daughter likes painting."
      },
      {
        "id": "v0162",
        "german": "meinen",
        "english": "to mean; to think",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "meinst",
          "er": "meint",
          "perfekt": "hat gemeint"
        },
        "exampleDE": "Was meinst du?",
        "exampleEN": "What do you think?"
      },
      {
        "id": "v0163",
        "german": "merken (sich)",
        "english": "to remember, note",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "merkst dir",
          "er": "merkt sich",
          "perfekt": "hat sich gemerkt"
        },
        "exampleDE": "Ich kann mir die Nummer nicht merken .",
        "exampleEN": "I can't remember the number."
      },
      {
        "id": "v0164",
        "german": "mieten",
        "english": "to rent",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "mietest",
          "er": "mietet",
          "perfekt": "hat gemietet"
        },
        "exampleDE": "Wir mieten eine Wohnung in Köln.",
        "exampleEN": "We're renting a flat in Cologne."
      },
      {
        "id": "v0165",
        "german": "mitbringen",
        "english": "to bring along",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "bringst mit",
          "er": "bringt mit",
          "perfekt": "hat mitgebracht"
        },
        "exampleDE": "Ich bringe einen Kuchen mit .",
        "exampleEN": "I'll bring a cake."
      },
      {
        "id": "v0166",
        "german": "mitkommen",
        "english": "to come along",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "kommst mit",
          "er": "kommt mit",
          "perfekt": "ist mitgekommen"
        },
        "exampleDE": "Kommst du mit ins Kino?",
        "exampleEN": "Are you coming to the cinema with us?"
      },
      {
        "id": "v0167",
        "german": "mitmachen",
        "english": "to join in",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "machst mit",
          "er": "macht mit",
          "perfekt": "hat mitgemacht"
        },
        "exampleDE": "Willst du beim Kurs mitmachen ?",
        "exampleEN": "Do you want to join the course?"
      },
      {
        "id": "v0168",
        "german": "mitnehmen",
        "english": "to take along",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "nimmst mit",
          "er": "nimmt mit",
          "perfekt": "hat mitgenommen"
        },
        "exampleDE": "Nimm bitte einen Regenschirm mit .",
        "exampleEN": "Please take an umbrella with you."
      },
      {
        "id": "v0169",
        "german": "möchten",
        "english": "would like",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "möchtest",
          "er": "möchte",
          "perfekt": "(kein Perfekt)"
        },
        "exampleDE": "Ich möchte einen Kaffee, bitte.",
        "exampleEN": "I'd like a coffee, please."
      },
      {
        "id": "v0170",
        "german": "mögen",
        "english": "to like",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "magst",
          "er": "mag",
          "perfekt": "hat gemocht"
        },
        "exampleDE": "Ich mag keinen Fisch.",
        "exampleEN": "I don't like fish."
      },
      {
        "id": "v0171",
        "german": "müssen",
        "english": "must, to have to",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "musst",
          "er": "muss",
          "perfekt": "hat gemusst"
        },
        "exampleDE": "Ich muss heute lange arbeiten.",
        "exampleEN": "I have to work late today."
      },
      {
        "id": "v0172",
        "german": "nehmen",
        "english": "to take",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "nimmst",
          "er": "nimmt",
          "perfekt": "hat genommen"
        },
        "exampleDE": "Ich nehme die Suppe.",
        "exampleEN": "I'll have the soup."
      },
      {
        "id": "v0173",
        "german": "nennen",
        "english": "to name, call",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "nennst",
          "er": "nennt",
          "perfekt": "hat genannt"
        },
        "exampleDE": "Wir nennen ihn Ali.",
        "exampleEN": "We call him Ali."
      },
      {
        "id": "v0174",
        "german": "notieren",
        "english": "to note down",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "notierst",
          "er": "notiert",
          "perfekt": "hat notiert"
        },
        "exampleDE": "Ich notiere mir den Termin.",
        "exampleEN": "I'm noting down the appointment."
      },
      {
        "id": "v0175",
        "german": "öffnen",
        "english": "to open",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "öffnest",
          "er": "öffnet",
          "perfekt": "hat geöffnet"
        },
        "exampleDE": "Die Bank öffnet um 9 Uhr.",
        "exampleEN": "The bank opens at 9 o'clock."
      },
      {
        "id": "v0176",
        "german": "organisieren",
        "english": "to organise",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "organisierst",
          "er": "organisiert",
          "perfekt": "hat organisiert"
        },
        "exampleDE": "Wer organisiert die Party?",
        "exampleEN": "Who's organising the party?"
      },
      {
        "id": "v0177",
        "german": "packen",
        "english": "to pack",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "packst",
          "er": "packt",
          "perfekt": "hat gepackt"
        },
        "exampleDE": "Ich muss noch meinen Koffer packen .",
        "exampleEN": "I still have to pack my suitcase."
      },
      {
        "id": "v0178",
        "german": "parken",
        "english": "to park",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "parkst",
          "er": "parkt",
          "perfekt": "hat geparkt"
        },
        "exampleDE": "Wo kann ich hier parken ?",
        "exampleEN": "Where can I park here?"
      },
      {
        "id": "v0179",
        "german": "passen",
        "english": "to fit; to suit",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "",
          "er": "passt",
          "perfekt": "hat gepasst"
        },
        "exampleDE": "Die Jacke passt mir nicht.",
        "exampleEN": "The jacket doesn't fit me."
      },
      {
        "id": "v0180",
        "german": "passieren",
        "english": "to happen",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "",
          "er": "passiert",
          "perfekt": "ist passiert"
        },
        "exampleDE": "Was ist passiert ?",
        "exampleEN": "What happened?"
      },
      {
        "id": "v0181",
        "german": "planen",
        "english": "to plan",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "planst",
          "er": "plant",
          "perfekt": "hat geplant"
        },
        "exampleDE": "Wir planen eine Party.",
        "exampleEN": "We're planning a party."
      },
      {
        "id": "v0182",
        "german": "probieren",
        "english": "to try, taste",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "probierst",
          "er": "probiert",
          "perfekt": "hat probiert"
        },
        "exampleDE": "Probier mal den Kuchen!",
        "exampleEN": "Try the cake!"
      },
      {
        "id": "v0183",
        "german": "prüfen",
        "english": "to check, test",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "prüfst",
          "er": "prüft",
          "perfekt": "hat geprüft"
        },
        "exampleDE": "Bitte prüfen Sie Ihre Daten.",
        "exampleEN": "Please check your details."
      },
      {
        "id": "v0184",
        "german": "putzen",
        "english": "to clean",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "putzt",
          "er": "putzt",
          "perfekt": "hat geputzt"
        },
        "exampleDE": "Ich putze die Küche.",
        "exampleEN": "I'm cleaning the kitchen."
      },
      {
        "id": "v0185",
        "german": "Rad fahren",
        "english": "to cycle",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "fährst Rad",
          "er": "fährt Rad",
          "perfekt": "ist Rad gefahren"
        },
        "exampleDE": "Im Sommer fahre ich oft Rad .",
        "exampleEN": "In the summer I often cycle."
      },
      {
        "id": "v0186",
        "german": "rauchen",
        "english": "to smoke",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "rauchst",
          "er": "raucht",
          "perfekt": "hat geraucht"
        },
        "exampleDE": "Hier darf man nicht rauchen .",
        "exampleEN": "You're not allowed to smoke here."
      },
      {
        "id": "v0187",
        "german": "rechnen",
        "english": "to calculate",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "rechnest",
          "er": "rechnet",
          "perfekt": "hat gerechnet"
        },
        "exampleDE": "Kannst du gut rechnen ?",
        "exampleEN": "Are you good at maths?"
      },
      {
        "id": "v0188",
        "german": "regnen",
        "english": "to rain",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "",
          "er": "regnet",
          "perfekt": "hat geregnet"
        },
        "exampleDE": "Heute regnet es.",
        "exampleEN": "It's raining today."
      },
      {
        "id": "v0189",
        "german": "reisen",
        "english": "to travel",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "reist",
          "er": "re",
          "perfekt": "ist ist gereist"
        },
        "exampleDE": "Ich reise gern.",
        "exampleEN": "I like travelling."
      },
      {
        "id": "v0190",
        "german": "renovieren",
        "english": "to renovate",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "renovierst",
          "er": "renoviert",
          "perfekt": "hat renoviert"
        },
        "exampleDE": "Wir renovieren das Bad.",
        "exampleEN": "We're renovating the bathroom."
      },
      {
        "id": "v0191",
        "german": "reparieren",
        "english": "to repair",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "reparierst",
          "er": "repariert",
          "perfekt": "hat repariert"
        },
        "exampleDE": "Kannst du mein Fahrrad reparieren ?",
        "exampleEN": "Can you repair my bike?"
      },
      {
        "id": "v0192",
        "german": "reservieren",
        "english": "to reserve",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "reservierst",
          "er": "reserviert",
          "perfekt": "hat reserviert"
        },
        "exampleDE": "Ich möchte einen Tisch reservieren .",
        "exampleEN": "I'd like to reserve a table."
      },
      {
        "id": "v0193",
        "german": "riechen",
        "english": "to smell",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "riechst",
          "er": "riecht",
          "perfekt": "hat gerochen"
        },
        "exampleDE": "Hier riecht es gut!",
        "exampleEN": "It smells good in here!"
      },
      {
        "id": "v0194",
        "german": "rufen",
        "english": "to call, shout",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "rufst",
          "er": "ruft",
          "perfekt": "hat gerufen"
        },
        "exampleDE": "Bitte rufen Sie einen Arzt!",
        "exampleEN": "Please call a doctor!"
      },
      {
        "id": "v0195",
        "german": "sagen",
        "english": "to say",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "sagst",
          "er": "sagt",
          "perfekt": "hat gesagt"
        },
        "exampleDE": "Was sagst du?",
        "exampleEN": "What are you saying?"
      },
      {
        "id": "v0196",
        "german": "sammeln",
        "english": "to collect",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "sammelst",
          "er": "sammelt",
          "perfekt": "hat gesammelt"
        },
        "exampleDE": "Mein Sohn sammelt Briefmarken.",
        "exampleEN": "My son collects stamps."
      },
      {
        "id": "v0197",
        "german": "schaffen",
        "english": "to manage",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "schaffst",
          "er": "schafft",
          "perfekt": "hat geschafft"
        },
        "exampleDE": "Ich habe es geschafft !",
        "exampleEN": "I managed it!"
      },
      {
        "id": "v0198",
        "german": "schauen",
        "english": "to look",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "schaust",
          "er": "schaut",
          "perfekt": "hat geschaut"
        },
        "exampleDE": "Schau mal, da ist Lena!",
        "exampleEN": "Look, there's Lena!"
      },
      {
        "id": "v0199",
        "german": "scheinen",
        "english": "to shine",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "",
          "er": "die Sonne scheint",
          "perfekt": "hat geschienen"
        },
        "exampleDE": "Heute scheint die Sonne.",
        "exampleEN": "The sun is shining today."
      },
      {
        "id": "v0200",
        "german": "schenken",
        "english": "to give (as a present)",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "schenkst",
          "er": "schenkt",
          "perfekt": "hat geschenkt"
        },
        "exampleDE": "Ich schenke meiner Mutter Blumen.",
        "exampleEN": "I'm giving my mother flowers."
      },
      {
        "id": "v0201",
        "german": "schicken",
        "english": "to send",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "schickst",
          "er": "schickt",
          "perfekt": "hat geschickt"
        },
        "exampleDE": "Ich schicke dir eine SMS.",
        "exampleEN": "I'll send you a text."
      },
      {
        "id": "v0202",
        "german": "schlafen",
        "english": "to sleep",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "schläfst",
          "er": "schläft",
          "perfekt": "hat geschlafen"
        },
        "exampleDE": "Das Baby schläft .",
        "exampleEN": "The baby is sleeping."
      },
      {
        "id": "v0203",
        "german": "schließen",
        "english": "to close",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "schließt",
          "er": "schließt",
          "perfekt": "hat geschlossen"
        },
        "exampleDE": "Der Supermarkt schließt um 22 Uhr.",
        "exampleEN": "The supermarket closes at 10 p.m."
      },
      {
        "id": "v0204",
        "german": "schmecken",
        "english": "to taste",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "",
          "er": "schmeckt",
          "perfekt": "hat geschmeckt"
        },
        "exampleDE": "Das Essen schmeckt sehr gut.",
        "exampleEN": "The food tastes very good."
      },
      {
        "id": "v0205",
        "german": "schneiden",
        "english": "to cut",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "schneidest",
          "er": "schneidet",
          "perfekt": "hat geschnitten"
        },
        "exampleDE": "Schneiden Sie die Zwiebeln klein.",
        "exampleEN": "Cut the onions into small pieces."
      },
      {
        "id": "v0206",
        "german": "schneien",
        "english": "to snow",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "",
          "er": "schneit",
          "perfekt": "hat geschneit"
        },
        "exampleDE": "Im Winter schneit es oft.",
        "exampleEN": "It often snows in winter."
      },
      {
        "id": "v0207",
        "german": "schreiben",
        "english": "to write",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "schreibst",
          "er": "schreibt",
          "perfekt": "hat geschrieben"
        },
        "exampleDE": "Ich schreibe eine E-Mail.",
        "exampleEN": "I'm writing an email."
      },
      {
        "id": "v0208",
        "german": "schreien",
        "english": "to shout, scream",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "schreist",
          "er": "schreit",
          "perfekt": "hat geschrien"
        },
        "exampleDE": "Die Kinder schreien im Garten.",
        "exampleEN": "The children are shouting in the garden."
      },
      {
        "id": "v0209",
        "german": "schwimmen",
        "english": "to swim",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "schwimmst",
          "er": "schwimmt",
          "perfekt": "ist geschwommen"
        },
        "exampleDE": "Im Sommer schwimme ich im See.",
        "exampleEN": "In the summer I swim in the lake."
      },
      {
        "id": "v0210",
        "german": "sehen",
        "english": "to see",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "siehst",
          "er": "sieht",
          "perfekt": "hat gesehen"
        },
        "exampleDE": "Siehst du das Haus dort?",
        "exampleEN": "Do you see the house over there?"
      },
      {
        "id": "v0211",
        "german": "sein",
        "english": "to be",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "bist",
          "er": "er",
          "perfekt": "ist ist gewesen"
        },
        "exampleDE": "Ich bin Lehrerin.",
        "exampleEN": "I'm a teacher."
      },
      {
        "id": "v0212",
        "german": "sich setzen",
        "english": "to sit down",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "setzt dich",
          "er": "setzt sich",
          "perfekt": "hat sich gesetzt"
        },
        "exampleDE": "Bitte setzen Sie sich.",
        "exampleEN": "Please sit down."
      },
      {
        "id": "v0213",
        "german": "singen",
        "english": "to sing",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "singst",
          "er": "singt",
          "perfekt": "hat gesungen"
        },
        "exampleDE": "Sie singt sehr schön.",
        "exampleEN": "She sings very beautifully."
      },
      {
        "id": "v0214",
        "german": "sitzen",
        "english": "to sit",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "sitzt",
          "er": "sitzt",
          "perfekt": "hat gesessen"
        },
        "exampleDE": "Wir sitzen im Garten.",
        "exampleEN": "We're sitting in the garden."
      },
      {
        "id": "v0215",
        "german": "Ski fahren",
        "english": "to ski",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "fährst Ski",
          "er": "fährt Ski",
          "perfekt": "ist Ski gefahren"
        },
        "exampleDE": "Im Winter fahren wir Ski .",
        "exampleEN": "In winter we go skiing."
      },
      {
        "id": "v0216",
        "german": "sollen",
        "english": "should, to be supposed to",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "sollst",
          "er": "soll",
          "perfekt": "hat gesollt"
        },
        "exampleDE": "Der Arzt sagt, ich soll viel trinken.",
        "exampleEN": "The doctor says I should drink a lot."
      },
      {
        "id": "v0217",
        "german": "sparen",
        "english": "to save (money)",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "sparst",
          "er": "spart",
          "perfekt": "hat gespart"
        },
        "exampleDE": "Wir sparen für eine Reise.",
        "exampleEN": "We're saving for a trip."
      },
      {
        "id": "v0218",
        "german": "spazieren gehen",
        "english": "to go for a walk",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "gehst spazieren",
          "er": "geht spazieren",
          "perfekt": "ist spazieren gegangen"
        },
        "exampleDE": "Am Sonntag gehen wir spazieren .",
        "exampleEN": "On Sunday we go for a walk."
      },
      {
        "id": "v0219",
        "german": "speichern",
        "english": "to save (a file)",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "speicherst",
          "er": "speichert",
          "perfekt": "hat gespeichert"
        },
        "exampleDE": "Hast du die Datei gespeichert ?",
        "exampleEN": "Did you save the file?"
      },
      {
        "id": "v0220",
        "german": "spielen",
        "english": "to play",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "spielst",
          "er": "spielt",
          "perfekt": "hat gespielt"
        },
        "exampleDE": "Die Kinder spielen Fußball.",
        "exampleEN": "The children are playing football."
      },
      {
        "id": "v0221",
        "german": "sprechen",
        "english": "to speak",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "sprichst",
          "er": "spricht",
          "perfekt": "hat gesprochen"
        },
        "exampleDE": "Sprechen Sie Englisch?",
        "exampleEN": "Do you speak English?"
      },
      {
        "id": "v0222",
        "german": "spülen",
        "english": "to wash up",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "spülst",
          "er": "spült",
          "perfekt": "hat gespült"
        },
        "exampleDE": "Nach dem Essen spüle ich.",
        "exampleEN": "After the meal I do the washing-up."
      },
      {
        "id": "v0223",
        "german": "stattfinden",
        "english": "to take place",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "",
          "er": "findet statt",
          "perfekt": "hat stattgefunden"
        },
        "exampleDE": "Das Fest findet im Park statt .",
        "exampleEN": "The party takes place in the park."
      },
      {
        "id": "v0224",
        "german": "stecken",
        "english": "to put (into)",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "steckst",
          "er": "steckt",
          "perfekt": "hat gesteckt"
        },
        "exampleDE": "Er steckt das Handy in die Tasche.",
        "exampleEN": "He puts the phone in his pocket."
      },
      {
        "id": "v0225",
        "german": "stehen",
        "english": "to stand; to be written",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "stehst",
          "er": "steht",
          "perfekt": "hat gestanden"
        },
        "exampleDE": "Was steht auf dem Schild?",
        "exampleEN": "What does the sign say?"
      },
      {
        "id": "v0226",
        "german": "stellen",
        "english": "to put (upright)",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "stellst",
          "er": "stellt",
          "perfekt": "hat gestellt"
        },
        "exampleDE": "Stell die Flasche in den Kühlschrank.",
        "exampleEN": "Put the bottle in the fridge."
      },
      {
        "id": "v0227",
        "german": "sterben",
        "english": "to die",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "stirbst",
          "er": "stirbt",
          "perfekt": "ist gestorben"
        },
        "exampleDE": "Mein Opa ist letztes Jahr gestorben .",
        "exampleEN": "My grandpa died last year."
      },
      {
        "id": "v0228",
        "german": "stimmen",
        "english": "to be right, correct",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "",
          "er": "stimmt",
          "perfekt": "hat gestimmt"
        },
        "exampleDE": "Das stimmt nicht.",
        "exampleEN": "That's not right."
      },
      {
        "id": "v0229",
        "german": "stören",
        "english": "to disturb",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "störst",
          "er": "stört",
          "perfekt": "hat gestört"
        },
        "exampleDE": "Entschuldigung, störe ich?",
        "exampleEN": "Sorry, am I disturbing you?"
      },
      {
        "id": "v0230",
        "german": "streiten",
        "english": "to argue",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "streitest",
          "er": "streitet",
          "perfekt": "hat gestritten"
        },
        "exampleDE": "Die Kinder streiten oft.",
        "exampleEN": "The children often argue."
      },
      {
        "id": "v0231",
        "german": "studieren",
        "english": "to study (at university)",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "studierst",
          "er": "studiert",
          "perfekt": "hat studiert"
        },
        "exampleDE": "Mein Bruder studiert Medizin.",
        "exampleEN": "My brother is studying medicine."
      },
      {
        "id": "v0232",
        "german": "suchen",
        "english": "to look for",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "suchst",
          "er": "sucht",
          "perfekt": "hat gesucht"
        },
        "exampleDE": "Ich suche eine Wohnung.",
        "exampleEN": "I'm looking for a flat."
      },
      {
        "id": "v0233",
        "german": "tanzen",
        "english": "to dance",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "tanzt",
          "er": "tanzt",
          "perfekt": "hat getanzt"
        },
        "exampleDE": "Tanzt du gern?",
        "exampleEN": "Do you like dancing?"
      },
      {
        "id": "v0234",
        "german": "teilen",
        "english": "to share",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "teilst",
          "er": "teilt",
          "perfekt": "hat geteilt"
        },
        "exampleDE": "Wir teilen uns eine Pizza.",
        "exampleEN": "We're sharing a pizza."
      },
      {
        "id": "v0235",
        "german": "telefonieren",
        "english": "to talk on the phone",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "telefonierst",
          "er": "telefoniert",
          "perfekt": "hat telefoniert"
        },
        "exampleDE": "Ich telefoniere mit meiner Schwester.",
        "exampleEN": "I'm on the phone with my sister."
      },
      {
        "id": "v0236",
        "german": "tragen",
        "english": "to carry; to wear",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "trägst",
          "er": "trägt",
          "perfekt": "hat getragen"
        },
        "exampleDE": "Sie trägt heute ein rotes Kleid.",
        "exampleEN": "She's wearing a red dress today."
      },
      {
        "id": "v0237",
        "german": "trainieren",
        "english": "to train, work out",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "trainierst",
          "er": "trainiert",
          "perfekt": "hat trainiert"
        },
        "exampleDE": "Ich trainiere zweimal pro Woche.",
        "exampleEN": "I work out twice a week."
      },
      {
        "id": "v0238",
        "german": "treffen",
        "english": "to meet",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "triffst",
          "er": "trifft",
          "perfekt": "hat getroffen"
        },
        "exampleDE": "Ich treffe meine Freunde im Café.",
        "exampleEN": "I'm meeting my friends at the café."
      },
      {
        "id": "v0239",
        "german": "trennen",
        "english": "to separate (rubbish)",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "trennst",
          "er": "trennt",
          "perfekt": "hat getrennt"
        },
        "exampleDE": "In Deutschland trennt man den Müll.",
        "exampleEN": "In Germany people separate their rubbish."
      },
      {
        "id": "v0240",
        "german": "trinken",
        "english": "to drink",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "trinkst",
          "er": "trinkt",
          "perfekt": "hat getrunken"
        },
        "exampleDE": "Was möchten Sie trinken ?",
        "exampleEN": "What would you like to drink?"
      },
      {
        "id": "v0241",
        "german": "tun",
        "english": "to do",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "tust",
          "er": "tut",
          "perfekt": "hat getan"
        },
        "exampleDE": "Was kann ich für Sie tun ?",
        "exampleEN": "What can I do for you?"
      },
      {
        "id": "v0242",
        "german": "üben",
        "english": "to practise",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "übst",
          "er": "übt",
          "perfekt": "hat geübt"
        },
        "exampleDE": "Ich übe jeden Tag Deutsch.",
        "exampleEN": "I practise German every day."
      },
      {
        "id": "v0243",
        "german": "überlegen",
        "english": "to think about, consider",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "überlegst",
          "er": "überlegt",
          "perfekt": "hat überlegt"
        },
        "exampleDE": "Ich muss noch überlegen .",
        "exampleEN": "I still have to think about it."
      },
      {
        "id": "v0244",
        "german": "übernachten",
        "english": "to stay overnight",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "übernachtest",
          "er": "übernachtet",
          "perfekt": "hat übernachtet"
        },
        "exampleDE": "Wir übernachten in einem Hotel.",
        "exampleEN": "We're staying in a hotel."
      },
      {
        "id": "v0245",
        "german": "übersetzen",
        "english": "to translate",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "übersetzt",
          "er": "übersetzt",
          "perfekt": "hat übersetzt"
        },
        "exampleDE": "Kannst du mir den Brief übersetzen ?",
        "exampleEN": "Can you translate the letter for me?"
      },
      {
        "id": "v0246",
        "german": "überweisen",
        "english": "to transfer (money)",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "überweist",
          "er": "überwe",
          "perfekt": "ist hat überwiesen"
        },
        "exampleDE": "Ich überweise die Miete jeden Monat.",
        "exampleEN": "I transfer the rent every month."
      },
      {
        "id": "v0247",
        "german": "sich ummelden",
        "english": "to register a new address",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "meldest dich um",
          "er": "meldet sich um",
          "perfekt": "hat sich umgemeldet"
        },
        "exampleDE": "Nach dem Umzug muss ich mich ummelden .",
        "exampleEN": "After the move I have to register my new address."
      },
      {
        "id": "v0248",
        "german": "umsteigen",
        "english": "to change (trains, buses)",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "steigst um",
          "er": "steigt um",
          "perfekt": "ist umgestiegen"
        },
        "exampleDE": "In Hannover müssen Sie umsteigen .",
        "exampleEN": "You have to change in Hanover."
      },
      {
        "id": "v0249",
        "german": "umtauschen",
        "english": "to exchange (goods)",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "tauschst um",
          "er": "tauscht um",
          "perfekt": "hat umgetauscht"
        },
        "exampleDE": "Kann ich die Schuhe umtauschen ?",
        "exampleEN": "Can I exchange the shoes?"
      },
      {
        "id": "v0250",
        "german": "umziehen",
        "english": "to move (house)",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "ziehst um",
          "er": "zieht um",
          "perfekt": "ist umgezogen"
        },
        "exampleDE": "Wir ziehen nächste Woche um .",
        "exampleEN": "We're moving next week."
      },
      {
        "id": "v0251",
        "german": "sich unterhalten",
        "english": "to chat, talk",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "unterhältst dich",
          "er": "unterhält sich",
          "perfekt": "hat sich unterhalten"
        },
        "exampleDE": "Wir haben uns lange unterhalten .",
        "exampleEN": "We talked for a long time."
      },
      {
        "id": "v0252",
        "german": "unterschreiben",
        "english": "to sign",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "unterschreibst",
          "er": "unterschreibt",
          "perfekt": "hat unterschrieben"
        },
        "exampleDE": "Bitte unterschreiben Sie hier.",
        "exampleEN": "Please sign here."
      },
      {
        "id": "v0253",
        "german": "untersuchen",
        "english": "to examine",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "untersuchst",
          "er": "untersucht",
          "perfekt": "hat untersucht"
        },
        "exampleDE": "Der Arzt untersucht mich.",
        "exampleEN": "The doctor is examining me."
      },
      {
        "id": "v0254",
        "german": "verbieten",
        "english": "to forbid",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "verbietest",
          "er": "verbietet",
          "perfekt": "hat verboten"
        },
        "exampleDE": "Der Arzt verbietet mir das Rauchen.",
        "exampleEN": "The doctor forbids me to smoke."
      },
      {
        "id": "v0255",
        "german": "verbinden",
        "english": "to connect, put through",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "verbindest",
          "er": "verbindet",
          "perfekt": "hat verbunden"
        },
        "exampleDE": "Einen Moment, ich verbinde Sie.",
        "exampleEN": "One moment, I'll put you through."
      },
      {
        "id": "v0256",
        "german": "verdienen",
        "english": "to earn",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "verdienst",
          "er": "verdient",
          "perfekt": "hat verdient"
        },
        "exampleDE": "Er verdient nicht viel Geld.",
        "exampleEN": "He doesn't earn much money."
      },
      {
        "id": "v0257",
        "german": "vereinbaren",
        "english": "to arrange (appointment)",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "vereinbarst",
          "er": "vereinbart",
          "perfekt": "hat vereinbart"
        },
        "exampleDE": "Ich möchte einen Termin vereinbaren .",
        "exampleEN": "I'd like to arrange an appointment."
      },
      {
        "id": "v0258",
        "german": "vergessen",
        "english": "to forget",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "vergisst",
          "er": "vergisst",
          "perfekt": "hat vergessen"
        },
        "exampleDE": "Ich habe meine Brille vergessen .",
        "exampleEN": "I've forgotten my glasses."
      },
      {
        "id": "v0259",
        "german": "vergleichen",
        "english": "to compare",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "vergleichst",
          "er": "vergleicht",
          "perfekt": "hat verglichen"
        },
        "exampleDE": "Ich vergleiche die Preise.",
        "exampleEN": "I'm comparing the prices."
      },
      {
        "id": "v0260",
        "german": "verkaufen",
        "english": "to sell",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "verkaufst",
          "er": "verkauft",
          "perfekt": "hat verkauft"
        },
        "exampleDE": "Wir verkaufen unser Auto.",
        "exampleEN": "We're selling our car."
      },
      {
        "id": "v0261",
        "german": "verlängern",
        "english": "to extend",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "verlängerst",
          "er": "verlängert",
          "perfekt": "hat verlängert"
        },
        "exampleDE": "Ich muss meinen Pass verlängern .",
        "exampleEN": "I have to renew my passport."
      },
      {
        "id": "v0262",
        "german": "sich verletzen",
        "english": "to hurt oneself",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "verletzt dich",
          "er": "verletzt sich",
          "perfekt": "hat sich verletzt"
        },
        "exampleDE": "Er hat sich beim Sport verletzt .",
        "exampleEN": "He hurt himself doing sport."
      },
      {
        "id": "v0263",
        "german": "verlieren",
        "english": "to lose",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "verlierst",
          "er": "verliert",
          "perfekt": "hat verloren"
        },
        "exampleDE": "Ich habe meinen Schlüssel verloren .",
        "exampleEN": "I've lost my key."
      },
      {
        "id": "v0264",
        "german": "vermieten",
        "english": "to rent out",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "vermietest",
          "er": "vermietet",
          "perfekt": "hat vermietet"
        },
        "exampleDE": "Herr Weber vermietet eine Wohnung.",
        "exampleEN": "Mr Weber is renting out a flat."
      },
      {
        "id": "v0265",
        "german": "verpassen",
        "english": "to miss",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "verpasst",
          "er": "verpasst",
          "perfekt": "hat verpasst"
        },
        "exampleDE": "Ich habe den Bus verpasst .",
        "exampleEN": "I missed the bus."
      },
      {
        "id": "v0266",
        "german": "verschieben",
        "english": "to postpone",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "verschiebst",
          "er": "verschiebt",
          "perfekt": "hat verschoben"
        },
        "exampleDE": "Können wir das Treffen verschieben ?",
        "exampleEN": "Can we postpone the meeting?"
      },
      {
        "id": "v0267",
        "german": "verschreiben",
        "english": "to prescribe",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "verschreibst",
          "er": "verschreibt",
          "perfekt": "hat verschrieben"
        },
        "exampleDE": "Die Ärztin verschreibt mir Tabletten.",
        "exampleEN": "The doctor prescribes me tablets."
      },
      {
        "id": "v0268",
        "german": "sich verspäten",
        "english": "to be late",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "verspätest dich",
          "er": "verspätet sich",
          "perfekt": "hat sich verspätet"
        },
        "exampleDE": "Der Zug hat sich verspätet .",
        "exampleEN": "The train was late."
      },
      {
        "id": "v0269",
        "german": "versprechen",
        "english": "to promise",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "versprichst",
          "er": "verspricht",
          "perfekt": "hat versprochen"
        },
        "exampleDE": "Ich verspreche dir, ich komme.",
        "exampleEN": "I promise you, I'll come."
      },
      {
        "id": "v0270",
        "german": "verstehen",
        "english": "to understand",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "verstehst",
          "er": "versteht",
          "perfekt": "hat verstanden"
        },
        "exampleDE": "Ich verstehe das nicht.",
        "exampleEN": "I don't understand that."
      },
      {
        "id": "v0271",
        "german": "versuchen",
        "english": "to try",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "versuchst",
          "er": "versucht",
          "perfekt": "hat versucht"
        },
        "exampleDE": "Ich versuche es noch einmal.",
        "exampleEN": "I'll try again."
      },
      {
        "id": "v0272",
        "german": "vorschlagen",
        "english": "to suggest",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "schlägst vor",
          "er": "schlägt vor",
          "perfekt": "hat vorgeschlagen"
        },
        "exampleDE": "Ich schlage Freitag vor .",
        "exampleEN": "I suggest Friday."
      },
      {
        "id": "v0273",
        "german": "sich vorstellen",
        "english": "to introduce oneself",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "stellst dich vor",
          "er": "stellt sich vor",
          "perfekt": "hat sich vorgestellt"
        },
        "exampleDE": "Darf ich mich vorstellen ?",
        "exampleEN": "May I introduce myself?"
      },
      {
        "id": "v0274",
        "german": "wählen",
        "english": "to choose; to dial; to vote",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "wählst",
          "er": "wählt",
          "perfekt": "hat gewählt"
        },
        "exampleDE": "Wählen Sie bitte die 1.",
        "exampleEN": "Please press 1."
      },
      {
        "id": "v0275",
        "german": "wandern",
        "english": "to hike",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "wanderst",
          "er": "wandert",
          "perfekt": "ist gewandert"
        },
        "exampleDE": "Am Wochenende wandern wir in den Bergen.",
        "exampleEN": "At the weekend we go hiking in the mountains."
      },
      {
        "id": "v0276",
        "german": "warten",
        "english": "to wait",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "wartest",
          "er": "wartet",
          "perfekt": "hat gewartet"
        },
        "exampleDE": "Ich warte auf den Bus.",
        "exampleEN": "I'm waiting for the bus."
      },
      {
        "id": "v0277",
        "german": "waschen",
        "english": "to wash",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "wäschst",
          "er": "wäscht",
          "perfekt": "hat gewaschen"
        },
        "exampleDE": "Ich wasche meine Hände.",
        "exampleEN": "I'm washing my hands."
      },
      {
        "id": "v0278",
        "german": "wechseln",
        "english": "to change",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "wechselst",
          "er": "wechselt",
          "perfekt": "hat gewechselt"
        },
        "exampleDE": "Ich möchte die Stelle wechseln .",
        "exampleEN": "I'd like to change jobs."
      },
      {
        "id": "v0279",
        "german": "wecken",
        "english": "to wake (sb) up",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "weckst",
          "er": "weckt",
          "perfekt": "hat geweckt"
        },
        "exampleDE": "Kannst du mich um 6 Uhr wecken ?",
        "exampleEN": "Can you wake me up at 6?"
      },
      {
        "id": "v0280",
        "german": "weggehen",
        "english": "to go away, leave",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "gehst weg",
          "er": "geht weg",
          "perfekt": "ist weggegangen"
        },
        "exampleDE": "Wann gehst du heute weg ?",
        "exampleEN": "When are you leaving today?"
      },
      {
        "id": "v0281",
        "german": "wehtun",
        "english": "to hurt",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "",
          "er": "tut weh",
          "perfekt": "hat wehgetan"
        },
        "exampleDE": "Mein Kopf tut weh .",
        "exampleEN": "My head hurts."
      },
      {
        "id": "v0282",
        "german": "weinen",
        "english": "to cry",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "weinst",
          "er": "weint",
          "perfekt": "hat geweint"
        },
        "exampleDE": "Das Baby weint .",
        "exampleEN": "The baby is crying."
      },
      {
        "id": "v0283",
        "german": "werden",
        "english": "to become",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "wirst",
          "er": "wird",
          "perfekt": "ist geworden"
        },
        "exampleDE": "Ich werde im Mai 30 Jahre alt.",
        "exampleEN": "I'll be 30 in May."
      },
      {
        "id": "v0284",
        "german": "werfen",
        "english": "to throw",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "wirfst",
          "er": "wirft",
          "perfekt": "hat geworfen"
        },
        "exampleDE": "Wirf das Papier in den Müll.",
        "exampleEN": "Throw the paper in the bin."
      },
      {
        "id": "v0285",
        "german": "wiederholen",
        "english": "to repeat",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "wiederholst",
          "er": "wiederholt",
          "perfekt": "hat wiederholt"
        },
        "exampleDE": "Können Sie das bitte wiederholen ?",
        "exampleEN": "Could you repeat that, please?"
      },
      {
        "id": "v0286",
        "german": "wiegen",
        "english": "to weigh",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "wiegst",
          "er": "wiegt",
          "perfekt": "hat gewogen"
        },
        "exampleDE": "Der Koffer wiegt 20 Kilo.",
        "exampleEN": "The suitcase weighs 20 kilos."
      },
      {
        "id": "v0287",
        "german": "wissen",
        "english": "to know (a fact)",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "weißt",
          "er": "weiß",
          "perfekt": "hat gewusst"
        },
        "exampleDE": "Ich weiß es nicht.",
        "exampleEN": "I don't know."
      },
      {
        "id": "v0288",
        "german": "wohnen",
        "english": "to live (reside)",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "wohnst",
          "er": "wohnt",
          "perfekt": "hat gewohnt"
        },
        "exampleDE": "Ich wohne in Hamburg.",
        "exampleEN": "I live in Hamburg."
      },
      {
        "id": "v0289",
        "german": "wollen",
        "english": "to want",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "willst",
          "er": "will",
          "perfekt": "hat gewollt"
        },
        "exampleDE": "Ich will Ärztin werden.",
        "exampleEN": "I want to become a doctor."
      },
      {
        "id": "v0290",
        "german": "wünschen",
        "english": "to wish",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "wünschst",
          "er": "wünscht",
          "perfekt": "hat gewünscht"
        },
        "exampleDE": "Ich wünsche dir alles Gute!",
        "exampleEN": "I wish you all the best!"
      },
      {
        "id": "v0291",
        "german": "zahlen",
        "english": "to pay",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "zahlst",
          "er": "zahlt",
          "perfekt": "hat gezahlt"
        },
        "exampleDE": "Wir möchten bitte zahlen .",
        "exampleEN": "We'd like to pay, please."
      },
      {
        "id": "v0292",
        "german": "zeichnen",
        "english": "to draw",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "zeichnest",
          "er": "zeichnet",
          "perfekt": "hat gezeichnet"
        },
        "exampleDE": "Meine Tochter zeichnet gern.",
        "exampleEN": "My daughter likes drawing."
      },
      {
        "id": "v0293",
        "german": "zeigen",
        "english": "to show",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "zeigst",
          "er": "zeigt",
          "perfekt": "hat gezeigt"
        },
        "exampleDE": "Ich zeige dir meine Fotos.",
        "exampleEN": "I'll show you my photos."
      },
      {
        "id": "v0294",
        "german": "ziehen",
        "english": "to pull",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "ziehst",
          "er": "zieht",
          "perfekt": "hat gezogen"
        },
        "exampleDE": "Bitte ziehen !",
        "exampleEN": "Please pull!"
      },
      {
        "id": "v0295",
        "german": "zuhören",
        "english": "to listen",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "hörst zu",
          "er": "hört zu",
          "perfekt": "hat zugehört"
        },
        "exampleDE": "Bitte hören Sie gut zu .",
        "exampleEN": "Please listen carefully."
      },
      {
        "id": "v0296",
        "german": "zumachen",
        "english": "to close",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "machst zu",
          "er": "macht zu",
          "perfekt": "hat zugemacht"
        },
        "exampleDE": "Mach bitte die Tür zu .",
        "exampleEN": "Please close the door."
      },
      {
        "id": "v0297",
        "german": "zunehmen",
        "english": "to put on weight",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "nimmst zu",
          "er": "nimmt zu",
          "perfekt": "hat zugenommen"
        },
        "exampleDE": "Im Winter nehme ich immer zu .",
        "exampleEN": "I always put on weight in winter."
      },
      {
        "id": "v0298",
        "german": "zurückgeben",
        "english": "to give back",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "gibst zurück",
          "er": "gibt zurück",
          "perfekt": "hat zurückgegeben"
        },
        "exampleDE": "Ich gebe dir das Buch morgen zurück .",
        "exampleEN": "I'll give you the book back tomorrow."
      },
      {
        "id": "v0299",
        "german": "zurückkommen",
        "english": "to come back",
        "level": "A1",
        "type": "verb",
        "verbForms": {
          "du": "kommst zurück",
          "er": "kommt zurück",
          "perfekt": "ist zurückgekommen"
        },
        "exampleDE": "Ich komme um 18 Uhr zurück .",
        "exampleEN": "I'll be back at 6 p.m."
      },
      {
        "id": "v0300",
        "german": "zurückrufen",
        "english": "to call back",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "rufst zurück",
          "er": "ruft zurück",
          "perfekt": "hat zurückgerufen"
        },
        "exampleDE": "Können Sie mich bitte zurückrufen ?",
        "exampleEN": "Can you call me back, please?"
      },
      {
        "id": "v0301",
        "german": "zusagen",
        "english": "to accept (an invitation)",
        "level": "A2",
        "type": "verb",
        "verbForms": {
          "du": "sagst zu",
          "er": "sagt zu",
          "perfekt": "hat zugesagt"
        },
        "exampleDE": "Ich habe für die Party zugesagt .",
        "exampleEN": "I've said yes to the party."
      }
    ]
  },
  {
    "id": "verben_praep",
    "title": "Verben mit Präpositionen",
    "emoji": "🔗",
    "entries": [
      {
        "id": "vp0001",
        "german": "Angst haben vor + Dat.",
        "english": "to be afraid of",
        "level": "A2",
        "type": "verb_prep",
        "exampleDE": "Mein Sohn hat Angst vor Hunden.",
        "exampleEN": "My son is afraid of dogs."
      },
      {
        "id": "vp0002",
        "german": "antworten auf + Akk.",
        "english": "to reply to",
        "level": "A2",
        "type": "verb_prep",
        "exampleDE": "Bitte antworte bald auf meine E-Mail.",
        "exampleEN": "Please reply to my email soon."
      },
      {
        "id": "vp0003",
        "german": "sich ärgern über + Akk.",
        "english": "to be annoyed about",
        "level": "A2",
        "type": "verb_prep",
        "exampleDE": "Ich ärgere mich über den Stau.",
        "exampleEN": "I'm annoyed about the traffic jam."
      },
      {
        "id": "vp0004",
        "german": "sich bedanken für + Akk.",
        "english": "to say thank you for",
        "level": "A2",
        "type": "verb_prep",
        "exampleDE": "Ich bedanke mich für die Einladung.",
        "exampleEN": "Thank you for the invitation."
      },
      {
        "id": "vp0005",
        "german": "sich beschweren über + Akk.",
        "english": "to complain about",
        "level": "A2",
        "type": "verb_prep",
        "exampleDE": "Er beschwert sich über den Lärm.",
        "exampleEN": "He's complaining about the noise."
      },
      {
        "id": "vp0006",
        "german": "sich bewerben um + Akk.",
        "english": "to apply for",
        "level": "A2",
        "type": "verb_prep",
        "exampleDE": "Ich bewerbe mich um eine Stelle als Koch.",
        "exampleEN": "I'm applying for a job as a cook."
      },
      {
        "id": "vp0007",
        "german": "bitten um + Akk.",
        "english": "to ask for",
        "level": "A2",
        "type": "verb_prep",
        "exampleDE": "Darf ich Sie um einen Rat bitten ?",
        "exampleEN": "May I ask you for some advice?"
      },
      {
        "id": "vp0008",
        "german": "denken an + Akk.",
        "english": "to think of",
        "level": "A2",
        "type": "verb_prep",
        "exampleDE": "Denk an den Termin morgen!",
        "exampleEN": "Remember the appointment tomorrow!"
      },
      {
        "id": "vp0009",
        "german": "einladen zu + Dat.",
        "english": "to invite to",
        "level": "A2",
        "type": "verb_prep",
        "exampleDE": "Ich lade dich zu meiner Hochzeit ein .",
        "exampleEN": "I'm inviting you to my wedding."
      },
      {
        "id": "vp0010",
        "german": "sich entschuldigen für + Akk.",
        "english": "to apologise for",
        "level": "A2",
        "type": "verb_prep",
        "exampleDE": "Ich entschuldige mich für die Verspätung.",
        "exampleEN": "I apologise for being late."
      },
      {
        "id": "vp0011",
        "german": "sich erinnern an + Akk.",
        "english": "to remember",
        "level": "A2",
        "type": "verb_prep",
        "exampleDE": "Erinnerst du dich an unseren ersten Urlaub?",
        "exampleEN": "Do you remember our first holiday?"
      },
      {
        "id": "vp0012",
        "german": "erzählen von + Dat.",
        "english": "to tell about",
        "level": "A2",
        "type": "verb_prep",
        "exampleDE": "Sie erzählt von ihrer Reise.",
        "exampleEN": "She's telling us about her trip."
      },
      {
        "id": "vp0013",
        "german": "fragen nach + Dat.",
        "english": "to ask about",
        "level": "A2",
        "type": "verb_prep",
        "exampleDE": "Der Tourist fragt nach dem Weg.",
        "exampleEN": "The tourist is asking for directions."
      },
      {
        "id": "vp0014",
        "german": "sich freuen auf + Akk.",
        "english": "to look forward to",
        "level": "A2",
        "type": "verb_prep",
        "exampleDE": "Ich freue mich auf das Wochenende.",
        "exampleEN": "I'm looking forward to the weekend."
      },
      {
        "id": "vp0015",
        "german": "sich freuen über + Akk.",
        "english": "to be happy about",
        "level": "A2",
        "type": "verb_prep",
        "exampleDE": "Sie freut sich über das Geschenk.",
        "exampleEN": "She's happy about the present."
      },
      {
        "id": "vp0016",
        "german": "gratulieren zu + Dat.",
        "english": "to congratulate on",
        "level": "A2",
        "type": "verb_prep",
        "exampleDE": "Ich gratuliere dir zum Geburtstag!",
        "exampleEN": "Happy birthday!"
      },
      {
        "id": "vp0017",
        "german": "helfen bei + Dat.",
        "english": "to help with",
        "level": "A2",
        "type": "verb_prep",
        "exampleDE": "Kannst du mir bei den Hausaufgaben helfen ?",
        "exampleEN": "Can you help me with my homework?"
      },
      {
        "id": "vp0018",
        "german": "sich interessieren für + Akk.",
        "english": "to be interested in",
        "level": "A2",
        "type": "verb_prep",
        "exampleDE": "Ich interessiere mich für Fußball.",
        "exampleEN": "I'm interested in football."
      },
      {
        "id": "vp0019",
        "german": "Lust haben auf + Akk.",
        "english": "to feel like",
        "level": "A2",
        "type": "verb_prep",
        "exampleDE": "Hast du Lust auf Pizza?",
        "exampleEN": "Do you feel like pizza?"
      },
      {
        "id": "vp0020",
        "german": "nachdenken über + Akk.",
        "english": "to think about",
        "level": "A2",
        "type": "verb_prep",
        "exampleDE": "Ich muss über das Angebot nachdenken .",
        "exampleEN": "I need to think about the offer."
      },
      {
        "id": "vp0021",
        "german": "schreiben an + Akk.",
        "english": "to write to",
        "level": "A2",
        "type": "verb_prep",
        "exampleDE": "Ich schreibe eine E-Mail an meinen Chef.",
        "exampleEN": "I'm writing an email to my boss."
      },
      {
        "id": "vp0022",
        "german": "sprechen mit / über + Dat. / + Akk.",
        "english": "to talk to / about",
        "level": "A2",
        "type": "verb_prep",
        "exampleDE": "Ich spreche mit dem Vermieter über die Heizung.",
        "exampleEN": "I'm talking to the landlord about the heating."
      },
      {
        "id": "vp0023",
        "german": "teilnehmen an + Dat.",
        "english": "to take part in",
        "level": "A2",
        "type": "verb_prep",
        "exampleDE": "Ich nehme an einem Deutschkurs teil .",
        "exampleEN": "I'm taking part in a German course."
      },
      {
        "id": "vp0024",
        "german": "telefonieren mit + Dat.",
        "english": "to talk on the phone with",
        "level": "A2",
        "type": "verb_prep",
        "exampleDE": "Ich telefoniere jeden Tag mit meiner Mutter.",
        "exampleEN": "I talk to my mother on the phone every day."
      },
      {
        "id": "vp0025",
        "german": "träumen von + Dat.",
        "english": "to dream of",
        "level": "A2",
        "type": "verb_prep",
        "exampleDE": "Er träumt von einem eigenen Haus.",
        "exampleEN": "He dreams of his own house."
      },
      {
        "id": "vp0026",
        "german": "sich treffen mit + Dat.",
        "english": "to meet (up) with",
        "level": "A2",
        "type": "verb_prep",
        "exampleDE": "Ich treffe mich heute mit Freunden.",
        "exampleEN": "I'm meeting friends today."
      },
      {
        "id": "vp0027",
        "german": "sich verabreden mit + Dat.",
        "english": "to arrange to meet",
        "level": "A2",
        "type": "verb_prep",
        "exampleDE": "Ich habe mich mit Lena verabredet .",
        "exampleEN": "I've arranged to meet Lena."
      },
      {
        "id": "vp0028",
        "german": "sich vorbereiten auf + Akk.",
        "english": "to prepare for",
        "level": "A2",
        "type": "verb_prep",
        "exampleDE": "Ich bereite mich auf die Prüfung vor .",
        "exampleEN": "I'm preparing for the exam."
      },
      {
        "id": "vp0029",
        "german": "warten auf + Akk.",
        "english": "to wait for",
        "level": "A2",
        "type": "verb_prep",
        "exampleDE": "Wir warten auf den Bus.",
        "exampleEN": "We're waiting for the bus."
      }
    ]
  },
  {
    "id": "nomen_person",
    "title": "Person & Formulare",
    "emoji": "👤",
    "entries": [
      {
        "id": "n0001",
        "german": "die Adresse",
        "article": "die",
        "plural": "Pl. die Adressen",
        "english": "address",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Wie ist Ihre Adresse ?",
        "exampleEN": "What is your address?"
      },
      {
        "id": "n0002",
        "german": "das Alter",
        "article": "das",
        "plural": "kein Plural",
        "english": "age",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Bitte schreiben Sie Ihr Alter in das Formular.",
        "exampleEN": "Please write your age on the form."
      },
      {
        "id": "n0003",
        "german": "der Ausweis",
        "article": "der",
        "plural": "Pl. die Ausweise",
        "english": "ID card",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Haben Sie Ihren Ausweis dabei?",
        "exampleEN": "Do you have your ID card with you?"
      },
      {
        "id": "n0004",
        "german": "der Beruf",
        "article": "der",
        "plural": "Pl. die Berufe",
        "english": "job, profession",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Was sind Sie von Beruf ?",
        "exampleEN": "What do you do for a living?"
      },
      {
        "id": "n0005",
        "german": "die Dame",
        "article": "die",
        "plural": "Pl. die Damen",
        "english": "lady",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Sehr geehrte Damen und Herren,",
        "exampleEN": "Dear Sir or Madam,"
      },
      {
        "id": "n0006",
        "german": "die E-Mail-Adresse",
        "article": "die",
        "plural": "Pl. die E-Mail-Adressen",
        "english": "email address",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Wie ist Ihre E-Mail-Adresse ?",
        "exampleEN": "What is your email address?"
      },
      {
        "id": "n0007",
        "german": "der/die Erwachsene",
        "article": "der/die",
        "plural": "Pl. die Erwachsenen",
        "english": "adult",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Erwachsene zahlen 10 Euro, Kinder 5 Euro.",
        "exampleEN": "Adults pay 10 euros, children 5 euros."
      },
      {
        "id": "n0008",
        "german": "der Familienname",
        "article": "der",
        "plural": "Pl. die Familiennamen",
        "english": "surname",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Mein Familienname ist Schneider.",
        "exampleEN": "My surname is Schneider."
      },
      {
        "id": "n0009",
        "german": "der Familienstand",
        "article": "der",
        "plural": "kein Plural",
        "english": "marital status",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Familienstand : ledig, verheiratet oder geschieden?",
        "exampleEN": "Marital status: single, married or divorced?"
      },
      {
        "id": "n0010",
        "german": "das Formular",
        "article": "das",
        "plural": "Pl. die Formulare",
        "english": "form",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Füllen Sie bitte das Formular aus.",
        "exampleEN": "Please fill in the form."
      },
      {
        "id": "n0011",
        "german": "das Geburtsdatum",
        "article": "das",
        "plural": "Pl. die Geburtsdaten",
        "english": "date of birth",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Mein Geburtsdatum ist der 3. Mai 1995.",
        "exampleEN": "My date of birth is 3 May 1995."
      },
      {
        "id": "n0012",
        "german": "der Geburtsort",
        "article": "der",
        "plural": "Pl. die Geburtsorte",
        "english": "place of birth",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Mein Geburtsort ist Wien.",
        "exampleEN": "My place of birth is Vienna."
      },
      {
        "id": "n0013",
        "german": "die Hausnummer",
        "article": "die",
        "plural": "Pl. die Hausnummern",
        "english": "house number",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Die Hausnummer ist 12.",
        "exampleEN": "The house number is 12."
      },
      {
        "id": "n0014",
        "german": "die Heimat",
        "article": "die",
        "plural": "kein Plural",
        "english": "home (country)",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Meine Heimat ist Pakistan.",
        "exampleEN": "My home country is Pakistan."
      },
      {
        "id": "n0015",
        "german": "der Herr",
        "article": "der",
        "plural": "Pl. die Herren",
        "english": "Mr; gentleman",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Das ist Herr Müller.",
        "exampleEN": "This is Mr Müller."
      },
      {
        "id": "n0016",
        "german": "der/die Jugendliche",
        "article": "der/die",
        "plural": "Pl. die Jugendlichen",
        "english": "young person, teenager",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Der Kurs ist für Jugendliche ab 14.",
        "exampleEN": "The course is for young people aged 14 and over."
      },
      {
        "id": "n0017",
        "german": "die Kenntnisse",
        "article": "die",
        "plural": "nur Plural",
        "english": "knowledge, skills",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Ich habe gute Kenntnisse in Englisch.",
        "exampleEN": "I have a good knowledge of English."
      },
      {
        "id": "n0018",
        "german": "das Land",
        "article": "das",
        "plural": "Pl. die Länder",
        "english": "country",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Aus welchem Land kommen Sie?",
        "exampleEN": "Which country are you from?"
      },
      {
        "id": "n0019",
        "german": "der Mensch",
        "article": "der",
        "plural": "Pl. die Menschen",
        "english": "person, human being",
        "level": "A2",
        "type": "noun",
        "exampleDE": "In der Stadt leben viele Menschen .",
        "exampleEN": "A lot of people live in the city."
      },
      {
        "id": "n0020",
        "german": "der Name",
        "article": "der",
        "plural": "Pl. die Namen",
        "english": "name",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Mein Name ist Anna Berg.",
        "exampleEN": "My name is Anna Berg."
      },
      {
        "id": "n0021",
        "german": "der Pass",
        "article": "der",
        "plural": "Pl. die Pässe",
        "english": "passport",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ich brauche einen neuen Pass .",
        "exampleEN": "I need a new passport."
      },
      {
        "id": "n0022",
        "german": "die Postleitzahl",
        "article": "die",
        "plural": "Pl. die Postleitzahlen",
        "english": "postcode",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Wie ist die Postleitzahl von Ihrem Wohnort?",
        "exampleEN": "What's the postcode of the place where you live?"
      },
      {
        "id": "n0023",
        "german": "die Sprache",
        "article": "die",
        "plural": "Pl. die Sprachen",
        "english": "language",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Welche Sprachen sprechen Sie?",
        "exampleEN": "Which languages do you speak?"
      },
      {
        "id": "n0024",
        "german": "die Staatsangehörigkeit",
        "article": "die",
        "plural": "Pl. die Staatsangehörigkeiten",
        "english": "nationality",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Welche Staatsangehörigkeit haben Sie?",
        "exampleEN": "What is your nationality?"
      },
      {
        "id": "n0025",
        "german": "die Straße",
        "article": "die",
        "plural": "Pl. die Straßen",
        "english": "street",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ich wohne in der Goethestraße .",
        "exampleEN": "I live on Goethestraße."
      },
      {
        "id": "n0026",
        "german": "die Telefonnummer",
        "article": "die",
        "plural": "Pl. die Telefonnummern",
        "english": "phone number",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Wie ist Ihre Telefonnummer ?",
        "exampleEN": "What is your phone number?"
      },
      {
        "id": "n0027",
        "german": "die Unterschrift",
        "article": "die",
        "plural": "Pl. die Unterschriften",
        "english": "signature",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Hier fehlt Ihre Unterschrift .",
        "exampleEN": "Your signature is missing here."
      },
      {
        "id": "n0028",
        "german": "der Vorname",
        "article": "der",
        "plural": "Pl. die Vornamen",
        "english": "first name",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Mein Vorname ist Maria.",
        "exampleEN": "My first name is Maria."
      },
      {
        "id": "n0029",
        "german": "der Art. Wohnort",
        "article": "der Art.",
        "plural": "Pl. die Wohnorte A1 Nomen · Plural",
        "english": "place of residence English",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Mein Wohnort ist Bremen. 25 Nomen",
        "exampleEN": "I live in Bremen. 42 Nomen Beispielsatz · example"
      }
    ]
  },
  {
    "id": "nomen_familie",
    "title": "Familie, Feste & Beziehungen",
    "emoji": "👨‍👩‍👧",
    "entries": [
      {
        "id": "n0030",
        "german": "das Baby",
        "article": "das",
        "plural": "Pl. die Babys",
        "english": "baby",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Das Baby ist drei Monate alt.",
        "exampleEN": "The baby is three months old."
      },
      {
        "id": "n0031",
        "german": "der/die Bekannte",
        "article": "der/die",
        "plural": "Pl. die Bekannten",
        "english": "acquaintance",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Das ist eine Bekannte von meiner Mutter.",
        "exampleEN": "That is an acquaintance of my mother's."
      },
      {
        "id": "n0032",
        "german": "der Besuch",
        "article": "der",
        "plural": "Pl. die Besuche",
        "english": "visit; visitors",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Morgen bekommen wir Besuch .",
        "exampleEN": "We're having visitors tomorrow."
      },
      {
        "id": "n0033",
        "german": "der Bruder",
        "article": "der",
        "plural": "Pl. die Brüder",
        "english": "brother",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Mein Bruder wohnt in Berlin.",
        "exampleEN": "My brother lives in Berlin."
      },
      {
        "id": "n0034",
        "german": "die Ehefrau",
        "article": "die",
        "plural": "Pl. die Ehefrauen",
        "english": "wife",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Meine Ehefrau arbeitet als Lehrerin.",
        "exampleEN": "My wife works as a teacher."
      },
      {
        "id": "n0035",
        "german": "der Ehemann",
        "article": "der",
        "plural": "Pl. die Ehemänner",
        "english": "husband",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Ihr Ehemann kommt aus Pakistan.",
        "exampleEN": "Her husband comes from Pakistan."
      },
      {
        "id": "n0036",
        "german": "das Ehepaar",
        "article": "das",
        "plural": "Pl. die Ehepaare",
        "english": "married couple",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Neben uns wohnt ein älteres Ehepaar .",
        "exampleEN": "An elderly couple lives next to us."
      },
      {
        "id": "n0037",
        "german": "die (Pl.) Eltern",
        "article": "die (Pl.)",
        "plural": "nur Plural",
        "english": "parents",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Meine Eltern kommen aus der Türkei.",
        "exampleEN": "My parents are from Turkey."
      },
      {
        "id": "n0038",
        "german": "der Enkel",
        "article": "der",
        "plural": "Pl. die Enkel",
        "english": "grandson; grandchild",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Meine Oma hat fünf Enkel .",
        "exampleEN": "My grandma has five grandchildren."
      },
      {
        "id": "n0039",
        "german": "die Familie",
        "article": "die",
        "plural": "Pl. die Familien",
        "english": "family",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Meine Familie ist sehr groß.",
        "exampleEN": "My family is very big."
      },
      {
        "id": "n0040",
        "german": "die Feier",
        "article": "die",
        "plural": "Pl. die Feiern",
        "english": "party, celebration",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Die Feier beginnt um 19 Uhr.",
        "exampleEN": "The party starts at 7 p.m."
      },
      {
        "id": "n0041",
        "german": "die Frau",
        "article": "die",
        "plural": "Pl. die Frauen",
        "english": "woman; wife; Mrs",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Das ist meine Frau Julia.",
        "exampleEN": "This is my wife Julia."
      },
      {
        "id": "n0042",
        "german": "der Freund",
        "article": "der",
        "plural": "Pl. die Freunde",
        "english": "friend; boyfriend",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Tom ist mein bester Freund .",
        "exampleEN": "Tom is my best friend."
      },
      {
        "id": "n0043",
        "german": "die Freundin",
        "article": "die",
        "plural": "Pl. die Freundinnen",
        "english": "(female) friend; girlfriend",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ich gehe mit meiner Freundin ins Kino.",
        "exampleEN": "I'm going to the cinema with my friend."
      },
      {
        "id": "n0044",
        "german": "der Gast",
        "article": "der",
        "plural": "Pl. die Gäste",
        "english": "guest",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Wir haben zwanzig Gäste eingeladen.",
        "exampleEN": "We've invited twenty guests."
      },
      {
        "id": "n0045",
        "german": "die (Pl.) Geschwister",
        "article": "die (Pl.)",
        "plural": "nur Plural",
        "english": "brothers and sisters",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Hast du Geschwister ?",
        "exampleEN": "Do you have any brothers or sisters?"
      },
      {
        "id": "n0046",
        "german": "der Glückwunsch",
        "article": "der",
        "plural": "Pl. die Glückwünsche",
        "english": "congratulations",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Herzlichen Glückwunsch zum Geburtstag!",
        "exampleEN": "Happy birthday!"
      },
      {
        "id": "n0047",
        "german": "die (Pl.) Großeltern",
        "article": "die (Pl.)",
        "plural": "nur Plural",
        "english": "grandparents",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Meine Großeltern wohnen auf dem Land.",
        "exampleEN": "My grandparents live in the countryside."
      },
      {
        "id": "n0048",
        "german": "die Hochzeit",
        "article": "die",
        "plural": "Pl. die Hochzeiten",
        "english": "wedding",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Die Hochzeit ist im Juni.",
        "exampleEN": "The wedding is in June."
      },
      {
        "id": "n0049",
        "german": "der Junge",
        "article": "der",
        "plural": "Pl. die Jungen",
        "english": "boy",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Der Junge ist zehn Jahre alt.",
        "exampleEN": "The boy is ten years old."
      },
      {
        "id": "n0050",
        "german": "die Kerze",
        "article": "die",
        "plural": "Pl. die Kerzen",
        "english": "candle",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Auf dem Kuchen sind dreißig Kerzen .",
        "exampleEN": "There are thirty candles on the cake."
      },
      {
        "id": "n0051",
        "german": "das Kind",
        "article": "das",
        "plural": "Pl. die Kinder",
        "english": "child",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Wir haben zwei Kinder .",
        "exampleEN": "We have two children."
      },
      {
        "id": "n0052",
        "german": "die (Pl.) Leute",
        "article": "die (Pl.)",
        "plural": "nur Plural",
        "english": "people",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Auf der Party sind viele Leute .",
        "exampleEN": "There are a lot of people at the party."
      },
      {
        "id": "n0053",
        "german": "das Mädchen",
        "article": "das",
        "plural": "Pl. die Mädchen",
        "english": "girl",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Das Mädchen heißt Lena.",
        "exampleEN": "The girl is called Lena."
      },
      {
        "id": "n0054",
        "german": "der Mann",
        "article": "der",
        "plural": "Pl. die Männer",
        "english": "man; husband",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Mein Mann arbeitet bei einer Bank.",
        "exampleEN": "My husband works at a bank."
      },
      {
        "id": "n0055",
        "german": "die Mutter",
        "article": "die",
        "plural": "Pl. die Mütter",
        "english": "mother",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Meine Mutter ist 60 Jahre alt.",
        "exampleEN": "My mother is 60 years old."
      },
      {
        "id": "n0056",
        "german": "der Nachbar",
        "article": "der",
        "plural": "Pl. die Nachbarn",
        "english": "neighbour",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Unser Nachbar ist sehr nett.",
        "exampleEN": "Our neighbour is very nice."
      },
      {
        "id": "n0057",
        "german": "die Oma",
        "article": "die",
        "plural": "Pl. die Omas",
        "english": "grandma",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Meine Oma kocht sehr gut.",
        "exampleEN": "My grandma cooks very well."
      },
      {
        "id": "n0058",
        "german": "der Onkel",
        "article": "der",
        "plural": "Pl. die Onkel",
        "english": "uncle",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Mein Onkel lebt in Amerika.",
        "exampleEN": "My uncle lives in America."
      },
      {
        "id": "n0059",
        "german": "der Opa",
        "article": "der",
        "plural": "Pl. die Opas",
        "english": "grandpa",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Mein Opa ist 85.",
        "exampleEN": "My grandpa is 85."
      },
      {
        "id": "n0060",
        "german": "das Paar",
        "article": "das",
        "plural": "Pl. die Paare",
        "english": "couple; pair",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Die beiden sind ein Paar .",
        "exampleEN": "The two of them are a couple."
      },
      {
        "id": "n0061",
        "german": "der Partner",
        "article": "der",
        "plural": "Pl. die Partner",
        "english": "partner",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Sie wohnt mit ihrem Partner zusammen.",
        "exampleEN": "She lives with her partner."
      },
      {
        "id": "n0062",
        "german": "der Rentner",
        "article": "der",
        "plural": "Pl. die Rentner",
        "english": "pensioner",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Mein Vater ist seit zwei Jahren Rentner .",
        "exampleEN": "My father has been retired for two years."
      },
      {
        "id": "n0063",
        "german": "die Schwester",
        "article": "die",
        "plural": "Pl. die Schwestern",
        "english": "sister",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Meine Schwester ist Studentin.",
        "exampleEN": "My sister is a student."
      },
      {
        "id": "n0064",
        "german": "das Silvester",
        "article": "das",
        "plural": "kein Plural",
        "english": "New Year's Eve",
        "level": "A2",
        "type": "noun",
        "exampleDE": "An Silvester gibt es ein Feuerwerk.",
        "exampleEN": "There are fireworks on New Year's Eve."
      },
      {
        "id": "n0065",
        "german": "der Sohn",
        "article": "der",
        "plural": "Pl. die Söhne",
        "english": "son",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Unser Sohn geht in die Schule.",
        "exampleEN": "Our son goes to school."
      },
      {
        "id": "n0066",
        "german": "die Tante",
        "article": "die",
        "plural": "Pl. die Tanten",
        "english": "aunt",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Meine Tante hat einen Hund.",
        "exampleEN": "My aunt has a dog."
      },
      {
        "id": "n0067",
        "german": "die Tochter",
        "article": "die",
        "plural": "Pl. die Töchter",
        "english": "daughter",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Meine Tochter ist fünf.",
        "exampleEN": "My daughter is five."
      },
      {
        "id": "n0068",
        "german": "die Überraschung",
        "article": "die",
        "plural": "Pl. die Überraschungen",
        "english": "surprise",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Die Party ist eine Überraschung .",
        "exampleEN": "The party is a surprise."
      },
      {
        "id": "n0069",
        "german": "der Vater",
        "article": "der",
        "plural": "Pl. die Väter",
        "english": "father",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Mein Vater ist Taxifahrer. 27 Nomen",
        "exampleEN": "My father is a taxi driver."
      },
      {
        "id": "n0070",
        "german": "der/die Verwandte",
        "article": "der/die",
        "plural": "Pl. die Verwandten",
        "english": "relative",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Am Wochenende besuchen wir Verwandte .",
        "exampleEN": "At the weekend we visit relatives."
      },
      {
        "id": "n0071",
        "german": "das Art. Weihnachten  Nomen · Plural",
        "article": "das Art.",
        "plural": "kein Plural",
        "english": "Christmas English",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Weihnachten feiern wir bei meinen Eltern.",
        "exampleEN": "We celebrate Christmas at my parents' house. 66 Nomen Beispielsatz · example"
      }
    ]
  },
  {
    "id": "nomen_wohnen",
    "title": "Wohnen & Umzug",
    "emoji": "🏠",
    "entries": [
      {
        "id": "n0072",
        "german": "das Apartment",
        "article": "das",
        "plural": "Pl. die Apartments",
        "english": "apartment, studio flat",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Das Apartment hat nur ein Zimmer.",
        "exampleEN": "The apartment has only one room."
      },
      {
        "id": "n0073",
        "german": "der Aufzug",
        "article": "der",
        "plural": "Pl. die Aufzüge",
        "english": "lift, elevator",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Das Haus hat keinen Aufzug .",
        "exampleEN": "The building has no lift."
      },
      {
        "id": "n0074",
        "german": "das Bad",
        "article": "das",
        "plural": "Pl. die Bäder",
        "english": "bathroom",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Das Bad ist klein.",
        "exampleEN": "The bathroom is small."
      },
      {
        "id": "n0075",
        "german": "der Balkon",
        "article": "der",
        "plural": "Pl. die Balkone",
        "english": "balcony",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Die Wohnung hat einen Balkon .",
        "exampleEN": "The flat has a balcony."
      },
      {
        "id": "n0076",
        "german": "das Bett",
        "article": "das",
        "plural": "Pl. die Betten",
        "english": "bed",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Das Bett ist sehr bequem.",
        "exampleEN": "The bed is very comfortable."
      },
      {
        "id": "n0077",
        "german": "der Boden",
        "article": "der",
        "plural": "Pl. die Böden",
        "english": "floor",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Die Tasche liegt auf dem Boden .",
        "exampleEN": "The bag is on the floor."
      },
      {
        "id": "n0078",
        "german": "das Ding",
        "article": "das",
        "plural": "Pl. die Dinge",
        "english": "thing",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Was ist das für ein Ding ?",
        "exampleEN": "What kind of thing is that?"
      },
      {
        "id": "n0079",
        "german": "die Dusche",
        "article": "die",
        "plural": "Pl. die Duschen",
        "english": "shower",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Die Dusche ist neu.",
        "exampleEN": "The shower is new."
      },
      {
        "id": "n0080",
        "german": "die Ecke",
        "article": "die",
        "plural": "Pl. die Ecken",
        "english": "corner",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Der Schrank steht in der Ecke .",
        "exampleEN": "The cupboard is in the corner."
      },
      {
        "id": "n0081",
        "german": "das Erdgeschoss",
        "article": "das",
        "plural": "Pl. die Erdgeschosse",
        "english": "ground floor",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Die Wohnung liegt im Erdgeschoss .",
        "exampleEN": "The flat is on the ground floor."
      },
      {
        "id": "n0082",
        "german": "das Fenster",
        "article": "das",
        "plural": "Pl. die Fenster",
        "english": "window",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Bitte mach das Fenster zu.",
        "exampleEN": "Please close the window."
      },
      {
        "id": "n0083",
        "german": "der Flur",
        "article": "der",
        "plural": "Pl. die Flure",
        "english": "hallway",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Die Schuhe stehen im Flur .",
        "exampleEN": "The shoes are in the hallway."
      },
      {
        "id": "n0084",
        "german": "die Garage",
        "article": "die",
        "plural": "Pl. die Garagen",
        "english": "garage",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Das Auto steht in der Garage .",
        "exampleEN": "The car is in the garage."
      },
      {
        "id": "n0085",
        "german": "der Garten",
        "article": "der",
        "plural": "Pl. die Gärten",
        "english": "garden",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Die Kinder spielen im Garten .",
        "exampleEN": "The children are playing in the garden."
      },
      {
        "id": "n0086",
        "german": "die Gegend",
        "article": "die",
        "plural": "Pl. die Gegenden",
        "english": "area",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Die Gegend ist ruhig und grün.",
        "exampleEN": "The area is quiet and green."
      },
      {
        "id": "n0087",
        "german": "das Geschirr",
        "article": "das",
        "plural": "kein Plural",
        "english": "dishes",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Wer spült heute das Geschirr ?",
        "exampleEN": "Who's doing the dishes today?"
      },
      {
        "id": "n0088",
        "german": "das Handtuch",
        "article": "das",
        "plural": "Pl. die Handtücher",
        "english": "towel",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Im Bad liegen frische Handtücher .",
        "exampleEN": "There are fresh towels in the bathroom."
      },
      {
        "id": "n0089",
        "german": "das Haus",
        "article": "das",
        "plural": "Pl. die Häuser",
        "english": "house",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Wir wohnen in einem kleinen Haus .",
        "exampleEN": "We live in a small house."
      },
      {
        "id": "n0090",
        "german": "der Haushalt",
        "article": "der",
        "plural": "Pl. die Haushalte",
        "english": "household; housework",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Wir teilen uns die Arbeit im Haushalt .",
        "exampleEN": "We share the housework."
      },
      {
        "id": "n0091",
        "german": "der Hausmeister",
        "article": "der",
        "plural": "Pl. die Hausmeister",
        "english": "caretaker",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Rufen Sie bitte den Hausmeister an.",
        "exampleEN": "Please call the caretaker."
      },
      {
        "id": "n0092",
        "german": "die Hausordnung",
        "article": "die",
        "plural": "Pl. die Hausordnungen",
        "english": "house rules",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Laut Hausordnung ist ab 22 Uhr Ruhe.",
        "exampleEN": "According to the house rules it must be quiet after 10 p.m."
      },
      {
        "id": "n0093",
        "german": "die Heizung",
        "article": "die",
        "plural": "Pl. die Heizungen",
        "english": "heating",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Die Heizung funktioniert nicht.",
        "exampleEN": "The heating isn't working."
      },
      {
        "id": "n0094",
        "german": "der Herd",
        "article": "der",
        "plural": "Pl. die Herde",
        "english": "cooker, stove",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Der Herd ist neu.",
        "exampleEN": "The cooker is new."
      },
      {
        "id": "n0095",
        "german": "die Kaution",
        "article": "die",
        "plural": "Pl. die Kautionen",
        "english": "deposit",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Die Kaution ist zwei Monatsmieten.",
        "exampleEN": "The deposit is two months' rent."
      },
      {
        "id": "n0096",
        "german": "der Keller",
        "article": "der",
        "plural": "Pl. die Keller",
        "english": "cellar, basement",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Die Fahrräder stehen im Keller .",
        "exampleEN": "The bikes are in the basement."
      },
      {
        "id": "n0097",
        "german": "die Klingel",
        "article": "die",
        "plural": "Pl. die Klingeln",
        "english": "doorbell",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Ihr Name steht an der Klingel .",
        "exampleEN": "Her name is on the doorbell."
      },
      {
        "id": "n0098",
        "german": "die Küche",
        "article": "die",
        "plural": "Pl. die Küchen",
        "english": "kitchen",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ich koche in der Küche .",
        "exampleEN": "I cook in the kitchen."
      },
      {
        "id": "n0099",
        "german": "der Kühlschrank",
        "article": "der",
        "plural": "Pl. die Kühlschränke",
        "english": "fridge",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Die Milch ist im Kühlschrank .",
        "exampleEN": "The milk is in the fridge."
      },
      {
        "id": "n0100",
        "german": "die Lampe",
        "article": "die",
        "plural": "Pl. die Lampen",
        "english": "lamp",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Die Lampe ist kaputt.",
        "exampleEN": "The lamp is broken."
      },
      {
        "id": "n0101",
        "german": "das Licht",
        "article": "das",
        "plural": "Pl. die Lichter",
        "english": "light",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Mach bitte das Licht aus.",
        "exampleEN": "Please switch off the light."
      },
      {
        "id": "n0102",
        "german": "die Miete",
        "article": "die",
        "plural": "Pl. die Mieten",
        "english": "rent",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Die Miete kostet 600 Euro.",
        "exampleEN": "The rent is 600 euros."
      },
      {
        "id": "n0103",
        "german": "der Mieter",
        "article": "der",
        "plural": "Pl. die Mieter",
        "english": "tenant",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Alle Mieter haben einen Schlüssel.",
        "exampleEN": "All tenants have a key."
      },
      {
        "id": "n0104",
        "german": "der Mietvertrag",
        "article": "der",
        "plural": "Pl. die Mietverträge",
        "english": "rental contract",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Ich habe den Mietvertrag unterschrieben.",
        "exampleEN": "I've signed the rental contract."
      },
      {
        "id": "n0105",
        "german": "das Möbel",
        "article": "das",
        "plural": "Pl. die Möbel",
        "english": "furniture (mostly pl.)",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Wir brauchen neue Möbel .",
        "exampleEN": "We need new furniture."
      },
      {
        "id": "n0106",
        "german": "der Müll",
        "article": "der",
        "plural": "kein Plural",
        "english": "rubbish",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Wann holen sie den Müll ab?",
        "exampleEN": "When do they collect the rubbish?"
      },
      {
        "id": "n0107",
        "german": "die Nähe",
        "article": "die",
        "plural": "kein Plural",
        "english": "nearness",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Gibt es hier in der Nähe einen Supermarkt?",
        "exampleEN": "Is there a supermarket near here?"
      },
      {
        "id": "n0108",
        "german": "die (Pl.) Nebenkosten",
        "article": "die (Pl.)",
        "plural": "nur Plural",
        "english": "utility costs",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Die Nebenkosten sind 200 Euro im Monat.",
        "exampleEN": "The utility costs are 200 euros a month."
      },
      {
        "id": "n0109",
        "german": "der Ort",
        "article": "der",
        "plural": "Pl. die Orte",
        "english": "place; village",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Ich wohne in einem kleinen Ort .",
        "exampleEN": "I live in a small village."
      },
      {
        "id": "n0110",
        "german": "der Quadratmeter",
        "article": "der",
        "plural": "Pl. die Quadratmeter",
        "english": "square metre",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Die Wohnung hat 60 Quadratmeter .",
        "exampleEN": "The flat is 60 square metres."
      },
      {
        "id": "n0111",
        "german": "das Regal",
        "article": "das",
        "plural": "Pl. die Regale",
        "english": "shelf",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Die Bücher stehen im Regal .",
        "exampleEN": "The books are on the shelf."
      },
      {
        "id": "n0112",
        "german": "die Reparatur",
        "article": "die",
        "plural": "Pl. die Reparaturen",
        "english": "repair",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Die Reparatur dauert zwei Tage.",
        "exampleEN": "The repair takes two days."
      },
      {
        "id": "n0113",
        "german": "das Schlafzimmer",
        "article": "das",
        "plural": "Pl. die Schlafzimmer",
        "english": "bedroom",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Das Schlafzimmer ist ruhig.",
        "exampleEN": "The bedroom is quiet."
      },
      {
        "id": "n0114",
        "german": "der Schlüssel",
        "article": "der",
        "plural": "Pl. die Schlüssel",
        "english": "key",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Wo ist mein Schlüssel ?",
        "exampleEN": "Where is my key?"
      },
      {
        "id": "n0115",
        "german": "der Schrank",
        "article": "der",
        "plural": "Pl. die Schränke",
        "english": "cupboard, wardrobe",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Die Kleidung ist im Schrank .",
        "exampleEN": "The clothes are in the wardrobe."
      },
      {
        "id": "n0116",
        "german": "der Schreibtisch",
        "article": "der",
        "plural": "Pl. die Schreibtische",
        "english": "desk",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Mein Laptop liegt auf dem Schreibtisch .",
        "exampleEN": "My laptop is on the desk."
      },
      {
        "id": "n0117",
        "german": "der Sessel",
        "article": "der",
        "plural": "Pl. die Sessel",
        "english": "armchair",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Opa sitzt im Sessel .",
        "exampleEN": "Grandpa is sitting in the armchair."
      },
      {
        "id": "n0118",
        "german": "das Sofa",
        "article": "das",
        "plural": "Pl. die Sofas",
        "english": "sofa",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Wir sitzen auf dem Sofa .",
        "exampleEN": "We're sitting on the sofa."
      },
      {
        "id": "n0119",
        "german": "der Spiegel",
        "article": "der",
        "plural": "Pl. die Spiegel",
        "english": "mirror",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Im Bad hängt ein großer Spiegel .",
        "exampleEN": "There's a big mirror in the bathroom."
      },
      {
        "id": "n0120",
        "german": "die Spülmaschine",
        "article": "die",
        "plural": "Pl. die Spülmaschinen",
        "english": "dishwasher",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Die Küche hat eine Spülmaschine .",
        "exampleEN": "The kitchen has a dishwasher."
      },
      {
        "id": "n0121",
        "german": "der Stock",
        "article": "der",
        "plural": "kein Plural",
        "english": "floor, storey",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ich wohne im dritten Stock .",
        "exampleEN": "I live on the third floor."
      },
      {
        "id": "n0122",
        "german": "der Strom",
        "article": "der",
        "plural": "kein Plural",
        "english": "electricity",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Der Strom ist sehr teuer geworden.",
        "exampleEN": "Electricity has become very expensive."
      },
      {
        "id": "n0123",
        "german": "der Stuhl",
        "article": "der",
        "plural": "Pl. die Stühle",
        "english": "chair",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Der Stuhl ist sehr alt.",
        "exampleEN": "The chair is very old."
      },
      {
        "id": "n0124",
        "german": "der Teppich",
        "article": "der",
        "plural": "Pl. die Teppiche",
        "english": "carpet, rug",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Der Teppich ist neu.",
        "exampleEN": "The rug is new."
      },
      {
        "id": "n0125",
        "german": "der Tisch",
        "article": "der",
        "plural": "Pl. die Tische",
        "english": "table",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Das Essen steht auf dem Tisch .",
        "exampleEN": "The food is on the table."
      },
      {
        "id": "n0126",
        "german": "die Toilette",
        "article": "die",
        "plural": "Pl. die Toiletten",
        "english": "toilet",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Entschuldigung, wo ist die Toilette ?",
        "exampleEN": "Excuse me, where is the toilet?"
      },
      {
        "id": "n0127",
        "german": "die Treppe",
        "article": "die",
        "plural": "Pl. die Treppen",
        "english": "stairs",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Der Aufzug ist kaputt, nimm die Treppe .",
        "exampleEN": "The lift is broken, take the stairs."
      },
      {
        "id": "n0128",
        "german": "die Tür",
        "article": "die",
        "plural": "Pl. die Türen",
        "english": "door",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Die Tür ist offen.",
        "exampleEN": "The door is open."
      },
      {
        "id": "n0129",
        "german": "der Umzug",
        "article": "der",
        "plural": "Pl. die Umzüge",
        "english": "move (house)",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Kannst du mir beim Umzug helfen?",
        "exampleEN": "Can you help me with the move?"
      },
      {
        "id": "n0130",
        "german": "der Vermieter",
        "article": "der",
        "plural": "Pl. die Vermieter",
        "english": "landlord",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Der Vermieter repariert die Heizung.",
        "exampleEN": "The landlord is repairing the heating."
      },
      {
        "id": "n0131",
        "german": "die Wand",
        "article": "die",
        "plural": "Pl. die Wände",
        "english": "wall",
        "level": "A2",
        "type": "noun",
        "exampleDE": "An der Wand hängt ein Bild.",
        "exampleEN": "There's a picture on the wall."
      },
      {
        "id": "n0132",
        "german": "die Wäsche",
        "article": "die",
        "plural": "kein Plural",
        "english": "laundry",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Ich wasche heute die Wäsche .",
        "exampleEN": "I'm doing the laundry today."
      },
      {
        "id": "n0133",
        "german": "die Waschmaschine",
        "article": "die",
        "plural": "Pl. die Waschmaschinen",
        "english": "washing machine",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Die Waschmaschine ist im Keller.",
        "exampleEN": "The washing machine is in the basement."
      },
      {
        "id": "n0134",
        "german": "der Wecker",
        "article": "der",
        "plural": "Pl. die Wecker",
        "english": "alarm clock",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Mein Wecker klingelt um sechs.",
        "exampleEN": "My alarm goes off at six."
      },
      {
        "id": "n0135",
        "german": "die Wohnung",
        "article": "die",
        "plural": "Pl. die Wohnungen",
        "english": "flat, apartment",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Die Wohnung hat drei Zimmer.",
        "exampleEN": "The flat has three rooms."
      },
      {
        "id": "n0136",
        "german": "das Wohnzimmer",
        "article": "das",
        "plural": "Pl. die Wohnzimmer",
        "english": "living room",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Das Wohnzimmer ist groß und hell.",
        "exampleEN": "The living room is big and bright."
      },
      {
        "id": "n0137",
        "german": "das Art. Zimmer",
        "article": "das Art.",
        "plural": "Pl. die Zimmer A1 Nomen · Plural",
        "english": "room English",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Mein Zimmer ist klein. 40 Nomen",
        "exampleEN": "My room is small. 75 Nomen Beispielsatz · example"
      }
    ]
  },
  {
    "id": "nomen_essen",
    "title": "Essen, Kochen & Restaurant",
    "emoji": "🍽️",
    "entries": [
      {
        "id": "n0138",
        "german": "das Abendessen",
        "article": "das",
        "plural": "Pl. die Abendessen",
        "english": "dinner, supper",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Das Abendessen ist um 19 Uhr.",
        "exampleEN": "Dinner is at 7 p.m."
      },
      {
        "id": "n0139",
        "german": "der Apfel",
        "article": "der",
        "plural": "Pl. die Äpfel",
        "english": "apple",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ich esse jeden Tag einen Apfel .",
        "exampleEN": "I eat an apple every day."
      },
      {
        "id": "n0140",
        "german": "der Appetit",
        "article": "der",
        "plural": "kein Plural",
        "english": "appetite",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Guten Appetit !",
        "exampleEN": "Enjoy your meal!"
      },
      {
        "id": "n0141",
        "german": "die Banane",
        "article": "die",
        "plural": "Pl. die Bananen",
        "english": "banana",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Die Bananen sind sehr billig.",
        "exampleEN": "The bananas are very cheap."
      },
      {
        "id": "n0142",
        "german": "das Bier",
        "article": "das",
        "plural": "Pl. die Biere",
        "english": "beer",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ein Bier , bitte!",
        "exampleEN": "A beer, please!"
      },
      {
        "id": "n0143",
        "german": "die Birne",
        "article": "die",
        "plural": "Pl. die Birnen",
        "english": "pear",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Die Birnen sind sehr süß.",
        "exampleEN": "The pears are very sweet."
      },
      {
        "id": "n0144",
        "german": "die Bohne",
        "article": "die",
        "plural": "Pl. die Bohnen",
        "english": "bean",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Ich koche Reis mit Bohnen .",
        "exampleEN": "I'm cooking rice with beans."
      },
      {
        "id": "n0145",
        "german": "das Brot",
        "article": "das",
        "plural": "Pl. die Brote",
        "english": "bread",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ich kaufe ein Brot beim Bäcker.",
        "exampleEN": "I'm buying a loaf of bread at the baker's."
      },
      {
        "id": "n0146",
        "german": "das Brötchen",
        "article": "das",
        "plural": "Pl. die Brötchen",
        "english": "bread roll",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Zum Frühstück esse ich zwei Brötchen .",
        "exampleEN": "I eat two rolls for breakfast."
      },
      {
        "id": "n0147",
        "german": "die Butter",
        "article": "die",
        "plural": "kein Plural",
        "english": "butter",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Brot mit Butter , bitte.",
        "exampleEN": "Bread and butter, please."
      },
      {
        "id": "n0148",
        "german": "das Café",
        "article": "das",
        "plural": "Pl. die Cafés",
        "english": "café",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Treffen wir uns im Café ?",
        "exampleEN": "Shall we meet at the café?"
      },
      {
        "id": "n0149",
        "german": "die Dose",
        "article": "die",
        "plural": "Pl. die Dosen",
        "english": "tin, can",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Wir brauchen zwei Dosen Tomaten.",
        "exampleEN": "We need two tins of tomatoes."
      },
      {
        "id": "n0150",
        "german": "der Durst",
        "article": "der",
        "plural": "kein Plural",
        "english": "thirst",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Ich habe großen Durst .",
        "exampleEN": "I'm very thirsty."
      },
      {
        "id": "n0151",
        "german": "das Ei",
        "article": "das",
        "plural": "Pl. die Eier",
        "english": "egg",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ich brauche sechs Eier .",
        "exampleEN": "I need six eggs."
      },
      {
        "id": "n0152",
        "german": "das Essen",
        "article": "das",
        "plural": "kein Plural",
        "english": "food; meal",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Das Essen ist sehr gut.",
        "exampleEN": "The food is very good."
      },
      {
        "id": "n0153",
        "german": "der Fisch",
        "article": "der",
        "plural": "Pl. die Fische",
        "english": "fish",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ich esse gern Fisch .",
        "exampleEN": "I like eating fish."
      },
      {
        "id": "n0154",
        "german": "die Flasche",
        "article": "die",
        "plural": "Pl. die Flaschen",
        "english": "bottle",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Eine Flasche Wasser, bitte.",
        "exampleEN": "A bottle of water, please."
      },
      {
        "id": "n0155",
        "german": "das Fleisch",
        "article": "das",
        "plural": "kein Plural",
        "english": "meat",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ich esse kein Fleisch .",
        "exampleEN": "I don't eat meat."
      },
      {
        "id": "n0156",
        "german": "das Frühstück",
        "article": "das",
        "plural": "Pl. die Frühstücke",
        "english": "breakfast",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Das Frühstück ist von 7 bis 10 Uhr.",
        "exampleEN": "Breakfast is from 7 to 10 o'clock."
      },
      {
        "id": "n0157",
        "german": "die Gabel",
        "article": "die",
        "plural": "Pl. die Gabeln",
        "english": "fork",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Kann ich bitte eine Gabel haben?",
        "exampleEN": "Can I have a fork, please?"
      },
      {
        "id": "n0158",
        "german": "das Gemüse",
        "article": "das",
        "plural": "kein Plural",
        "english": "vegetables",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Gemüse ist gesund.",
        "exampleEN": "Vegetables are healthy."
      },
      {
        "id": "n0159",
        "german": "das Gericht",
        "article": "das",
        "plural": "Pl. die Gerichte",
        "english": "dish",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Biryani ist mein Lieblings gericht .",
        "exampleEN": "Biryani is my favourite dish."
      },
      {
        "id": "n0160",
        "german": "der Geschmack",
        "article": "der",
        "plural": "kein Plural",
        "english": "taste",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Der Tee hat einen süßen Geschmack .",
        "exampleEN": "The tea has a sweet taste."
      },
      {
        "id": "n0161",
        "german": "das Getränk",
        "article": "das",
        "plural": "Pl. die Getränke",
        "english": "drink",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Welche Getränke haben Sie?",
        "exampleEN": "What drinks do you have?"
      },
      {
        "id": "n0162",
        "german": "das Glas",
        "article": "das",
        "plural": "Pl. die Gläser",
        "english": "glass",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ein Glas Saft, bitte.",
        "exampleEN": "A glass of juice, please."
      },
      {
        "id": "n0163",
        "german": "das Hähnchen",
        "article": "das",
        "plural": "Pl. die Hähnchen",
        "english": "chicken",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ich nehme Hähnchen mit Reis.",
        "exampleEN": "I'll have chicken with rice."
      },
      {
        "id": "n0164",
        "german": "das Hauptgericht",
        "article": "das",
        "plural": "Pl. die Hauptgerichte",
        "english": "main course",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Was nimmst du als Hauptgericht ?",
        "exampleEN": "What are you having as a main course?"
      },
      {
        "id": "n0165",
        "german": "der Hunger",
        "article": "der",
        "plural": "kein Plural",
        "english": "hunger",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Hast du Hunger ?",
        "exampleEN": "Are you hungry?"
      },
      {
        "id": "n0166",
        "german": "der Imbiss",
        "article": "der",
        "plural": "Pl. die Imbisse",
        "english": "snack bar",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Mittags esse ich oft am Imbiss .",
        "exampleEN": "At lunchtime I often eat at the snack bar."
      },
      {
        "id": "n0167",
        "german": "der Kaffee",
        "article": "der",
        "plural": "kein Plural",
        "english": "coffee",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Trinken Sie Kaffee oder Tee?",
        "exampleEN": "Do you drink coffee or tea?"
      },
      {
        "id": "n0168",
        "german": "die Kartoffel",
        "article": "die",
        "plural": "Pl. die Kartoffeln",
        "english": "potato",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Wir essen Kartoffeln mit Gemüse.",
        "exampleEN": "We're eating potatoes with vegetables."
      },
      {
        "id": "n0169",
        "german": "der Käse",
        "article": "der",
        "plural": "kein Plural",
        "english": "cheese",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ich möchte ein Brot mit Käse .",
        "exampleEN": "I'd like a cheese sandwich."
      },
      {
        "id": "n0170",
        "german": "der Kuchen",
        "article": "der",
        "plural": "Pl. die Kuchen",
        "english": "cake",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Der Kuchen schmeckt super.",
        "exampleEN": "The cake tastes great."
      },
      {
        "id": "n0171",
        "german": "die (Pl.) Lebensmittel",
        "article": "die (Pl.)",
        "plural": "nur Plural",
        "english": "food, groceries",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Lebensmittel kaufe ich im Supermarkt.",
        "exampleEN": "I buy groceries at the supermarket."
      },
      {
        "id": "n0172",
        "german": "der Löffel",
        "article": "der",
        "plural": "Pl. die Löffel",
        "english": "spoon",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Für die Suppe brauchst du einen Löffel .",
        "exampleEN": "You need a spoon for the soup."
      },
      {
        "id": "n0173",
        "german": "das Lokal",
        "article": "das",
        "plural": "Pl. die Lokale",
        "english": "pub, restaurant",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Das Lokal hat bis 23 Uhr offen.",
        "exampleEN": "The restaurant is open until 11 p.m."
      },
      {
        "id": "n0174",
        "german": "das Messer",
        "article": "das",
        "plural": "Pl. die Messer",
        "english": "knife",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Das Messer ist sehr scharf.",
        "exampleEN": "The knife is very sharp."
      },
      {
        "id": "n0175",
        "german": "die Milch",
        "article": "die",
        "plural": "kein Plural",
        "english": "milk",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ich trinke Kaffee mit Milch .",
        "exampleEN": "I drink coffee with milk."
      },
      {
        "id": "n0176",
        "german": "das Mineralwasser",
        "article": "das",
        "plural": "kein Plural",
        "english": "mineral water",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Ein Mineralwasser , bitte.",
        "exampleEN": "A mineral water, please."
      },
      {
        "id": "n0177",
        "german": "das Mittagessen",
        "article": "das",
        "plural": "Pl. die Mittagessen",
        "english": "lunch",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Was gibt es zum Mittagessen ?",
        "exampleEN": "What's for lunch?"
      },
      {
        "id": "n0178",
        "german": "die Nachspeise",
        "article": "die",
        "plural": "Pl. die Nachspeisen",
        "english": "dessert",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Zur Nachspeise gibt es Eis.",
        "exampleEN": "There's ice cream for dessert."
      },
      {
        "id": "n0179",
        "german": "die (Pl.) Nudeln",
        "article": "die (Pl.)",
        "plural": "nur Plural",
        "english": "pasta, noodles",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Die Kinder essen gern Nudeln .",
        "exampleEN": "The children like eating pasta."
      },
      {
        "id": "n0180",
        "german": "das Obst",
        "article": "das",
        "plural": "kein Plural",
        "english": "fruit",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ich kaufe Obst auf dem Markt.",
        "exampleEN": "I buy fruit at the market."
      },
      {
        "id": "n0181",
        "german": "das Öl",
        "article": "das",
        "plural": "Pl. die Öle",
        "english": "oil",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Zuerst brauchen wir etwas Öl .",
        "exampleEN": "First we need some oil."
      },
      {
        "id": "n0182",
        "german": "die Packung",
        "article": "die",
        "plural": "Pl. die Packungen",
        "english": "packet",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Ich kaufe eine Packung Reis.",
        "exampleEN": "I'm buying a packet of rice."
      },
      {
        "id": "n0183",
        "german": "die Pfanne",
        "article": "die",
        "plural": "Pl. die Pfannen",
        "english": "frying pan",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Brate das Fleisch in der Pfanne .",
        "exampleEN": "Fry the meat in the pan."
      },
      {
        "id": "n0184",
        "german": "der Pfeffer",
        "article": "der",
        "plural": "kein Plural",
        "english": "pepper",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Kannst du mir bitte den Pfeffer geben?",
        "exampleEN": "Can you pass me the pepper, please?"
      },
      {
        "id": "n0185",
        "german": "die Rechnung",
        "article": "die",
        "plural": "Pl. die Rechnungen",
        "english": "bill",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Die Rechnung , bitte!",
        "exampleEN": "The bill, please!"
      },
      {
        "id": "n0186",
        "german": "der Reis",
        "article": "der",
        "plural": "kein Plural",
        "english": "rice",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Möchtest du Reis oder Kartoffeln?",
        "exampleEN": "Would you like rice or potatoes?"
      },
      {
        "id": "n0187",
        "german": "das Restaurant",
        "article": "das",
        "plural": "Pl. die Restaurants",
        "english": "restaurant",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Das Restaurant ist am Montag geschlossen.",
        "exampleEN": "The restaurant is closed on Monday."
      },
      {
        "id": "n0188",
        "german": "das Rindfleisch",
        "article": "das",
        "plural": "kein Plural",
        "english": "beef",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Ich esse kein Rindfleisch .",
        "exampleEN": "I don't eat beef."
      },
      {
        "id": "n0189",
        "german": "der Saft",
        "article": "der",
        "plural": "Pl. die Säfte",
        "english": "juice",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ich trinke einen Orangensaft .",
        "exampleEN": "I'm drinking an orange juice."
      },
      {
        "id": "n0190",
        "german": "der Salat",
        "article": "der",
        "plural": "Pl. die Salate",
        "english": "salad; lettuce",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ich nehme einen Salat .",
        "exampleEN": "I'll have a salad."
      },
      {
        "id": "n0191",
        "german": "das Salz",
        "article": "das",
        "plural": "kein Plural",
        "english": "salt",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Die Suppe braucht noch Salz .",
        "exampleEN": "The soup needs more salt."
      },
      {
        "id": "n0192",
        "german": "die Schokolade",
        "article": "die",
        "plural": "Pl. die Schokoladen",
        "english": "chocolate",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Kinder essen gern Schokolade .",
        "exampleEN": "Children like eating chocolate."
      },
      {
        "id": "n0193",
        "german": "das Schweinefleisch",
        "article": "das",
        "plural": "kein Plural",
        "english": "pork",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Ist da Schweinefleisch drin?",
        "exampleEN": "Is there pork in it?"
      },
      {
        "id": "n0194",
        "german": "die Speisekarte",
        "article": "die",
        "plural": "Pl. die Speisekarten",
        "english": "menu",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Die Speisekarte , bitte.",
        "exampleEN": "The menu, please."
      },
      {
        "id": "n0195",
        "german": "die Spezialität",
        "article": "die",
        "plural": "Pl. die Spezialitäten",
        "english": "speciality",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Biryani ist eine Spezialität aus Pakistan.",
        "exampleEN": "Biryani is a speciality from Pakistan."
      },
      {
        "id": "n0196",
        "german": "das Stück",
        "article": "das",
        "plural": "Pl. die Stücke",
        "english": "piece",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Möchtest du ein Stück Kuchen?",
        "exampleEN": "Would you like a piece of cake?"
      },
      {
        "id": "n0197",
        "german": "die Suppe",
        "article": "die",
        "plural": "Pl. die Suppen",
        "english": "soup",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Die Suppe ist heiß.",
        "exampleEN": "The soup is hot."
      },
      {
        "id": "n0198",
        "german": "die Süßigkeit",
        "article": "die",
        "plural": "Pl. die Süßigkeiten",
        "english": "sweet",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Zu viele Süßigkeiten sind nicht gesund.",
        "exampleEN": "Too many sweets aren't healthy."
      },
      {
        "id": "n0199",
        "german": "die Tasse",
        "article": "die",
        "plural": "Pl. die Tassen",
        "english": "cup",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Eine Tasse Tee, bitte.",
        "exampleEN": "A cup of tea, please."
      },
      {
        "id": "n0200",
        "german": "der Tee",
        "article": "der",
        "plural": "Pl. die Tees",
        "english": "tea",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ich trinke gern grünen Tee .",
        "exampleEN": "I like drinking green tea."
      },
      {
        "id": "n0201",
        "german": "der Teller",
        "article": "der",
        "plural": "Pl. die Teller",
        "english": "plate",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Stell die Teller auf den Tisch.",
        "exampleEN": "Put the plates on the table."
      },
      {
        "id": "n0202",
        "german": "die Tomate",
        "article": "die",
        "plural": "Pl. die Tomaten",
        "english": "tomato",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Die Tomaten sind rot.",
        "exampleEN": "The tomatoes are red."
      },
      {
        "id": "n0203",
        "german": "der Topf",
        "article": "der",
        "plural": "Pl. die Töpfe",
        "english": "pot",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Das Wasser kocht im Topf .",
        "exampleEN": "The water is boiling in the pot."
      },
      {
        "id": "n0204",
        "german": "das Trinkgeld",
        "article": "das",
        "plural": "kein Plural",
        "english": "tip",
        "level": "A2",
        "type": "noun",
        "exampleDE": "In Deutschland gibt man oft 5 bis 10 Prozent Trinkgeld .",
        "exampleEN": "In Germany people often give a 5 to 10 per cent tip."
      },
      {
        "id": "n0205",
        "german": "die Tüte",
        "article": "die",
        "plural": "Pl. die Tüten",
        "english": "bag (plastic/paper)",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Brauchen Sie eine Tüte ?",
        "exampleEN": "Do you need a bag?"
      },
      {
        "id": "n0206",
        "german": "die Vorspeise",
        "article": "die",
        "plural": "Pl. die Vorspeisen",
        "english": "starter",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Als Vorspeise nehme ich eine Suppe.",
        "exampleEN": "As a starter I'll have a soup."
      },
      {
        "id": "n0207",
        "german": "das Wasser",
        "article": "das",
        "plural": "kein Plural",
        "english": "water",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ich trinke viel Wasser .",
        "exampleEN": "I drink a lot of water."
      },
      {
        "id": "n0208",
        "german": "der Wein",
        "article": "der",
        "plural": "Pl. die Weine",
        "english": "wine",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Ich trinke keinen Wein .",
        "exampleEN": "I don't drink wine."
      },
      {
        "id": "n0209",
        "german": "die Wurst",
        "article": "die",
        "plural": "Pl. die Würste",
        "english": "sausage; cold meat",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Möchtest du Brot mit Wurst ?",
        "exampleEN": "Would you like bread with cold meat?"
      },
      {
        "id": "n0210",
        "german": "der Zucker",
        "article": "der",
        "plural": "kein Plural",
        "english": "sugar",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Nehmen Sie Zucker ? 30 Nomen",
        "exampleEN": "Do you take sugar?"
      },
      {
        "id": "n0211",
        "german": "die Zutat",
        "article": "die",
        "plural": "Pl. die Zutaten",
        "english": "ingredient",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Hast du alle Zutaten gekauft?",
        "exampleEN": "Have you bought all the ingredients?"
      },
      {
        "id": "n0212",
        "german": "die Zwiebel",
        "article": "die",
        "plural": "Pl. die Zwiebeln",
        "english": "onion",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Für das Curry brauche ich drei Zwiebeln .",
        "exampleEN": "I need three onions for the curry."
      }
    ]
  },
  {
    "id": "nomen_einkaufen",
    "title": "Einkaufen & Kleidung",
    "emoji": "🛍️",
    "entries": [
      {
        "id": "n0213",
        "german": "das Angebot",
        "article": "das",
        "plural": "Pl. die Angebote",
        "english": "offer",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Heute sind Tomaten im Angebot .",
        "exampleEN": "Tomatoes are on offer today."
      },
      {
        "id": "n0214",
        "german": "der Anzug",
        "article": "der",
        "plural": "Pl. die Anzüge",
        "english": "suit",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Zur Hochzeit trägt er einen Anzug .",
        "exampleEN": "He's wearing a suit to the wedding."
      },
      {
        "id": "n0215",
        "german": "die Bäckerei",
        "article": "die",
        "plural": "Pl. die Bäckereien",
        "english": "bakery",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Die Bäckerei öffnet um 6 Uhr.",
        "exampleEN": "The bakery opens at 6 a.m."
      },
      {
        "id": "n0216",
        "german": "das Bargeld",
        "article": "das",
        "plural": "kein Plural",
        "english": "cash",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Hast du Bargeld dabei?",
        "exampleEN": "Do you have cash on you?"
      },
      {
        "id": "n0217",
        "german": "die Bestellung",
        "article": "die",
        "plural": "Pl. die Bestellungen",
        "english": "order",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Ihre Bestellung kommt morgen.",
        "exampleEN": "Your order is arriving tomorrow."
      },
      {
        "id": "n0218",
        "german": "die Bluse",
        "article": "die",
        "plural": "Pl. die Blusen",
        "english": "blouse",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Die Bluse passt gut zum Rock.",
        "exampleEN": "The blouse goes well with the skirt."
      },
      {
        "id": "n0219",
        "german": "die Brille",
        "article": "die",
        "plural": "Pl. die Brillen",
        "english": "glasses",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Ich brauche eine neue Brille .",
        "exampleEN": "I need new glasses."
      },
      {
        "id": "n0220",
        "german": "der Cent",
        "article": "der",
        "plural": "Pl. die Cent",
        "english": "cent",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Das kostet 50 Cent .",
        "exampleEN": "That costs 50 cents."
      },
      {
        "id": "n0221",
        "german": "das Einkaufszentrum",
        "article": "das",
        "plural": "Pl. die Einkaufszentren",
        "english": "shopping centre",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Am Samstag ist das Einkaufszentrum sehr voll.",
        "exampleEN": "On Saturdays the shopping centre is very full."
      },
      {
        "id": "n0222",
        "german": "die Ermäßigung",
        "article": "die",
        "plural": "Pl. die Ermäßigungen",
        "english": "reduction, discount",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Studenten bekommen eine Ermäßigung .",
        "exampleEN": "Students get a discount."
      },
      {
        "id": "n0223",
        "german": "der Euro",
        "article": "der",
        "plural": "Pl. die Euro",
        "english": "euro",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Das T-Shirt kostet 15 Euro .",
        "exampleEN": "The T-shirt costs 15 euros."
      },
      {
        "id": "n0224",
        "german": "die Farbe",
        "article": "die",
        "plural": "Pl. die Farben",
        "english": "colour",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Welche Farbe hat die Jacke?",
        "exampleEN": "What colour is the jacket?"
      },
      {
        "id": "n0225",
        "german": "der Flohmarkt",
        "article": "der",
        "plural": "Pl. die Flohmärkte",
        "english": "flea market",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Am Sonntag gehen wir auf den Flohmarkt .",
        "exampleEN": "On Sunday we're going to the flea market."
      },
      {
        "id": "n0226",
        "german": "die Garantie",
        "article": "die",
        "plural": "Pl. die Garantien",
        "english": "guarantee, warranty",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Das Handy hat zwei Jahre Garantie .",
        "exampleEN": "The phone has a two-year warranty."
      },
      {
        "id": "n0227",
        "german": "das Geld",
        "article": "das",
        "plural": "kein Plural",
        "english": "money",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ich habe kein Geld dabei.",
        "exampleEN": "I don't have any money on me."
      },
      {
        "id": "n0228",
        "german": "das Geschäft",
        "article": "das",
        "plural": "Pl. die Geschäfte",
        "english": "shop",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Die Geschäfte sind am Sonntag geschlossen.",
        "exampleEN": "The shops are closed on Sunday."
      },
      {
        "id": "n0229",
        "german": "das Gramm",
        "article": "das",
        "plural": "kein Plural",
        "english": "gram",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ich möchte 200 Gramm Käse.",
        "exampleEN": "I'd like 200 grams of cheese."
      },
      {
        "id": "n0230",
        "german": "die Größe",
        "article": "die",
        "plural": "Pl. die Größen",
        "english": "size",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Haben Sie die Hose in Größe M?",
        "exampleEN": "Do you have the trousers in size M?"
      },
      {
        "id": "n0231",
        "german": "das Hemd",
        "article": "das",
        "plural": "Pl. die Hemden",
        "english": "shirt",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Das Hemd ist zu klein.",
        "exampleEN": "The shirt is too small."
      },
      {
        "id": "n0232",
        "german": "die Hose",
        "article": "die",
        "plural": "Pl. die Hosen",
        "english": "trousers",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ich suche eine schwarze Hose .",
        "exampleEN": "I'm looking for black trousers."
      },
      {
        "id": "n0233",
        "german": "die Jacke",
        "article": "die",
        "plural": "Pl. die Jacken",
        "english": "jacket",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Die Jacke ist sehr warm.",
        "exampleEN": "The jacket is very warm."
      },
      {
        "id": "n0234",
        "german": "die (Pl.) Jeans",
        "article": "die (Pl.)",
        "plural": "nur Plural",
        "english": "jeans",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Ich trage gern Jeans .",
        "exampleEN": "I like wearing jeans."
      },
      {
        "id": "n0235",
        "german": "die Karte",
        "article": "die",
        "plural": "Pl. die Karten",
        "english": "card; ticket; menu",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Kann ich mit Karte zahlen?",
        "exampleEN": "Can I pay by card?"
      },
      {
        "id": "n0236",
        "german": "die Kasse",
        "article": "die",
        "plural": "Pl. die Kassen",
        "english": "checkout, till",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Bitte zahlen Sie an der Kasse .",
        "exampleEN": "Please pay at the checkout."
      },
      {
        "id": "n0237",
        "german": "der Kassenbon",
        "article": "der",
        "plural": "Pl. die Kassenbons",
        "english": "receipt",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Bitte heben Sie den Kassenbon auf.",
        "exampleEN": "Please keep the receipt."
      },
      {
        "id": "n0238",
        "german": "das Kaufhaus",
        "article": "das",
        "plural": "Pl. die Kaufhäuser",
        "english": "department store",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Im Kaufhaus gibt es alles.",
        "exampleEN": "You can get everything in the department store."
      },
      {
        "id": "n0239",
        "german": "die Kette",
        "article": "die",
        "plural": "Pl. die Ketten",
        "english": "necklace; chain",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Die Kette ist ein Geschenk.",
        "exampleEN": "The necklace is a present."
      },
      {
        "id": "n0240",
        "german": "das Kilo",
        "article": "das",
        "plural": "Pl. die Kilo",
        "english": "kilo",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ein Kilo Äpfel kostet 2 Euro.",
        "exampleEN": "A kilo of apples costs 2 euros."
      },
      {
        "id": "n0241",
        "german": "der Kiosk",
        "article": "der",
        "plural": "Pl. die Kioske",
        "english": "kiosk",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Am Kiosk kaufe ich eine Zeitung.",
        "exampleEN": "I buy a newspaper at the kiosk."
      },
      {
        "id": "n0242",
        "german": "das Kleid",
        "article": "das",
        "plural": "Pl. die Kleider",
        "english": "dress",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Das Kleid ist sehr schön.",
        "exampleEN": "The dress is very pretty."
      },
      {
        "id": "n0243",
        "german": "die Kleidung",
        "article": "die",
        "plural": "kein Plural",
        "english": "clothes, clothing",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ich kaufe neue Kleidung .",
        "exampleEN": "I'm buying new clothes."
      },
      {
        "id": "n0244",
        "german": "die Kreditkarte",
        "article": "die",
        "plural": "Pl. die Kreditkarten",
        "english": "credit card",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Kann ich mit Kreditkarte zahlen?",
        "exampleEN": "Can I pay by credit card?"
      },
      {
        "id": "n0245",
        "german": "der/die Kunde / Kundin",
        "article": "der/die",
        "plural": "Pl. die Kunden / Kundinnen",
        "english": "customer",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Der Kunde möchte bezahlen.",
        "exampleEN": "The customer would like to pay."
      },
      {
        "id": "n0246",
        "german": "der Laden",
        "article": "der",
        "plural": "Pl. die Läden",
        "english": "shop",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Der Laden macht um 20 Uhr zu.",
        "exampleEN": "The shop closes at 8 p.m."
      },
      {
        "id": "n0247",
        "german": "die Lieferung",
        "article": "die",
        "plural": "Pl. die Lieferungen",
        "english": "delivery",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Die Lieferung ist kostenlos.",
        "exampleEN": "Delivery is free."
      },
      {
        "id": "n0248",
        "german": "der Liter",
        "article": "der",
        "plural": "Pl. die Liter",
        "english": "litre",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ich kaufe zwei Liter Milch.",
        "exampleEN": "I'm buying two litres of milk."
      },
      {
        "id": "n0249",
        "german": "der Mantel",
        "article": "der",
        "plural": "Pl. die Mäntel",
        "english": "coat",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Im Winter trage ich einen Mantel .",
        "exampleEN": "In winter I wear a coat."
      },
      {
        "id": "n0250",
        "german": "die Marke",
        "article": "die",
        "plural": "Pl. die Marken",
        "english": "brand",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Welche Marke ist das?",
        "exampleEN": "Which brand is that?"
      },
      {
        "id": "n0251",
        "german": "der Markt",
        "article": "der",
        "plural": "Pl. die Märkte",
        "english": "market",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Am Samstag gehe ich auf den Markt .",
        "exampleEN": "On Saturday I go to the market."
      },
      {
        "id": "n0252",
        "german": "die Menge",
        "article": "die",
        "plural": "Pl. die Mengen",
        "english": "amount, a lot",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Das kostet eine Menge Geld.",
        "exampleEN": "That costs a lot of money."
      },
      {
        "id": "n0253",
        "german": "die Mode",
        "article": "die",
        "plural": "kein Plural",
        "english": "fashion",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Sie interessiert sich für Mode .",
        "exampleEN": "She's interested in fashion."
      },
      {
        "id": "n0254",
        "german": "die Mütze",
        "article": "die",
        "plural": "Pl. die Mützen",
        "english": "woolly hat",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Im Winter trage ich eine Mütze .",
        "exampleEN": "In winter I wear a woolly hat."
      },
      {
        "id": "n0255",
        "german": "die (Pl.) Öffnungszeiten",
        "article": "die (Pl.)",
        "plural": "nur Plural",
        "english": "opening hours",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Wie sind die Öffnungszeiten ?",
        "exampleEN": "What are the opening hours?"
      },
      {
        "id": "n0256",
        "german": "der Preis",
        "article": "der",
        "plural": "Pl. die Preise",
        "english": "price",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Der Preis ist gut.",
        "exampleEN": "The price is good."
      },
      {
        "id": "n0257",
        "german": "der Prospekt",
        "article": "der",
        "plural": "Pl. die Prospekte",
        "english": "brochure, leaflet",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Im Prospekt stehen die Angebote.",
        "exampleEN": "The offers are in the leaflet."
      },
      {
        "id": "n0258",
        "german": "der Pullover",
        "article": "der",
        "plural": "Pl. die Pullover",
        "english": "jumper, sweater",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Der Pullover ist aus Wolle.",
        "exampleEN": "The jumper is made of wool."
      },
      {
        "id": "n0259",
        "german": "die Qualität",
        "article": "die",
        "plural": "Pl. die Qualitäten",
        "english": "quality",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Die Qualität ist sehr gut.",
        "exampleEN": "The quality is very good."
      },
      {
        "id": "n0260",
        "german": "der Rabatt",
        "article": "der",
        "plural": "Pl. die Rabatte",
        "english": "discount",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Heute gibt es 20 Prozent Rabatt .",
        "exampleEN": "There's 20 per cent off today."
      },
      {
        "id": "n0261",
        "german": "der Rock",
        "article": "der",
        "plural": "Pl. die Röcke",
        "english": "skirt",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Sie trägt einen blauen Rock .",
        "exampleEN": "She's wearing a blue skirt."
      },
      {
        "id": "n0262",
        "german": "der Schal",
        "article": "der",
        "plural": "Pl. die Schals",
        "english": "scarf",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Nimm einen Schal mit, es ist kalt.",
        "exampleEN": "Take a scarf, it's cold."
      },
      {
        "id": "n0263",
        "german": "der Schuh",
        "article": "der",
        "plural": "Pl. die Schuhe",
        "english": "shoe",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ich brauche neue Schuhe .",
        "exampleEN": "I need new shoes."
      },
      {
        "id": "n0264",
        "german": "die Socke",
        "article": "die",
        "plural": "Pl. die Socken",
        "english": "sock",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Ich brauche warme Socken .",
        "exampleEN": "I need warm socks."
      },
      {
        "id": "n0265",
        "german": "das Sonderangebot",
        "article": "das",
        "plural": "Pl. die Sonderangebote",
        "english": "special offer",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Die Jacke ist im Sonderangebot .",
        "exampleEN": "The jacket is on special offer."
      },
      {
        "id": "n0266",
        "german": "der Stiefel",
        "article": "der",
        "plural": "Pl. die Stiefel",
        "english": "boot",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Diese Stiefel sind warm.",
        "exampleEN": "These boots are warm."
      },
      {
        "id": "n0267",
        "german": "der Supermarkt",
        "article": "der",
        "plural": "Pl. die Supermärkte",
        "english": "supermarket",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Der Supermarkt ist gleich um die Ecke.",
        "exampleEN": "The supermarket is just around the corner."
      },
      {
        "id": "n0268",
        "german": "das T-Shirt",
        "article": "das",
        "plural": "Pl. die T-Shirts",
        "english": "T-shirt",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Im Sommer trage ich T-Shirts .",
        "exampleEN": "In the summer I wear T-shirts."
      },
      {
        "id": "n0269",
        "german": "die Tasche",
        "article": "die",
        "plural": "Pl. die Taschen",
        "english": "bag",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Meine Tasche ist schwer. 40 Nomen",
        "exampleEN": "My bag is heavy."
      },
      {
        "id": "n0270",
        "german": "die Art. Umkleidekabine",
        "article": "die Art.",
        "plural": "Pl. die Umkleidekabinen Nomen · Plural",
        "english": "changing room English",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Wo ist die Umkleidekabine ?",
        "exampleEN": "Where's the changing room? 82 Nomen Beispielsatz · example"
      }
    ]
  },
  {
    "id": "nomen_reisen",
    "title": "Reisen & Verkehr",
    "emoji": "✈️",
    "entries": [
      {
        "id": "n0271",
        "german": "die Abfahrt",
        "article": "die",
        "plural": "Pl. die Abfahrten",
        "english": "departure",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Die Abfahrt ist um 9:15 Uhr.",
        "exampleEN": "Departure is at 9:15."
      },
      {
        "id": "n0272",
        "german": "die Ampel",
        "article": "die",
        "plural": "Pl. die Ampeln",
        "english": "traffic light",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Die Ampel ist rot.",
        "exampleEN": "The traffic light is red."
      },
      {
        "id": "n0273",
        "german": "die Ankunft",
        "article": "die",
        "plural": "Pl. die Ankünfte",
        "english": "arrival",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Wann ist die Ankunft in München?",
        "exampleEN": "When is the arrival in Munich?"
      },
      {
        "id": "n0274",
        "german": "der Anschluss",
        "article": "der",
        "plural": "Pl. die Anschlüsse",
        "english": "connection",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Ich habe meinen Anschluss verpasst.",
        "exampleEN": "I've missed my connection."
      },
      {
        "id": "n0275",
        "german": "die Apotheke",
        "article": "die",
        "plural": "Pl. die Apotheken",
        "english": "pharmacy",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Die Apotheke ist neben der Post.",
        "exampleEN": "The pharmacy is next to the post office."
      },
      {
        "id": "n0276",
        "german": "der Ausgang",
        "article": "der",
        "plural": "Pl. die Ausgänge",
        "english": "exit",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Wo ist der Ausgang ?",
        "exampleEN": "Where is the exit?"
      },
      {
        "id": "n0277",
        "german": "die Auskunft",
        "article": "die",
        "plural": "Pl. die Auskünfte",
        "english": "information (desk)",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Fragen Sie bitte an der Auskunft .",
        "exampleEN": "Please ask at the information desk."
      },
      {
        "id": "n0278",
        "german": "das Ausland",
        "article": "das",
        "plural": "kein Plural",
        "english": "abroad, foreign countries",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Mein Bruder arbeitet im Ausland .",
        "exampleEN": "My brother works abroad."
      },
      {
        "id": "n0279",
        "german": "das Auto",
        "article": "das",
        "plural": "Pl. die Autos",
        "english": "car",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Mein Auto ist rot.",
        "exampleEN": "My car is red."
      },
      {
        "id": "n0280",
        "german": "die Autobahn",
        "article": "die",
        "plural": "Pl. die Autobahnen",
        "english": "motorway",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Auf der Autobahn ist Stau.",
        "exampleEN": "There's a traffic jam on the motorway."
      },
      {
        "id": "n0281",
        "german": "der Automat",
        "article": "der",
        "plural": "Pl. die Automaten",
        "english": "machine (ticket, vending)",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Die Fahrkarte kaufen Sie am Automaten .",
        "exampleEN": "You buy the ticket from the machine."
      },
      {
        "id": "n0282",
        "german": "die Bahn",
        "article": "die",
        "plural": "Pl. die Bahnen",
        "english": "railway, train",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Ich fahre mit der Bahn nach Berlin.",
        "exampleEN": "I'm going to Berlin by train."
      },
      {
        "id": "n0283",
        "german": "der Bahnhof",
        "article": "der",
        "plural": "Pl. die Bahnhöfe",
        "english": "(railway) station",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Wie komme ich zum Bahnhof ?",
        "exampleEN": "How do I get to the station?"
      },
      {
        "id": "n0284",
        "german": "der Bahnsteig",
        "article": "der",
        "plural": "Pl. die Bahnsteige",
        "english": "platform",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Der Zug kommt an Bahnsteig 2.",
        "exampleEN": "The train arrives at platform 2."
      },
      {
        "id": "n0285",
        "german": "die Bank",
        "article": "die",
        "plural": "Pl. die Banken",
        "english": "bank",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Die Bank ist am Samstag geschlossen.",
        "exampleEN": "The bank is closed on Saturday."
      },
      {
        "id": "n0286",
        "german": "die Baustelle",
        "article": "die",
        "plural": "Pl. die Baustellen",
        "english": "building site; roadworks",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Wegen einer Baustelle gibt es Stau.",
        "exampleEN": "There's a traffic jam because of roadworks."
      },
      {
        "id": "n0287",
        "german": "die Bibliothek",
        "article": "die",
        "plural": "Pl. die Bibliotheken",
        "english": "library",
        "level": "A2",
        "type": "noun",
        "exampleDE": "In der Bibliothek kann man ruhig lernen.",
        "exampleEN": "You can study quietly in the library."
      },
      {
        "id": "n0288",
        "german": "der Bus",
        "article": "der",
        "plural": "Pl. die Busse",
        "english": "bus",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Der Bus kommt in fünf Minuten.",
        "exampleEN": "The bus is coming in five minutes."
      },
      {
        "id": "n0289",
        "german": "das Doppelzimmer",
        "article": "das",
        "plural": "Pl. die Doppelzimmer",
        "english": "double room",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Das Doppelzimmer kostet 90 Euro.",
        "exampleEN": "The double room costs 90 euros."
      },
      {
        "id": "n0290",
        "german": "das Dorf",
        "article": "das",
        "plural": "Pl. die Dörfer",
        "english": "village",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Meine Eltern wohnen in einem Dorf .",
        "exampleEN": "My parents live in a village."
      },
      {
        "id": "n0291",
        "german": "die Durchsage",
        "article": "die",
        "plural": "Pl. die Durchsagen",
        "english": "announcement",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Achtung, eine Durchsage !",
        "exampleEN": "Attention, an announcement!"
      },
      {
        "id": "n0292",
        "german": "der Eingang",
        "article": "der",
        "plural": "Pl. die Eingänge",
        "english": "entrance",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Der Eingang ist links.",
        "exampleEN": "The entrance is on the left."
      },
      {
        "id": "n0293",
        "german": "das Einzelzimmer",
        "article": "das",
        "plural": "Pl. die Einzelzimmer",
        "english": "single room",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Ich hätte gern ein Einzelzimmer .",
        "exampleEN": "I'd like a single room."
      },
      {
        "id": "n0294",
        "german": "die Fahrkarte",
        "article": "die",
        "plural": "Pl. die Fahrkarten",
        "english": "ticket",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Wo kann ich eine Fahrkarte kaufen?",
        "exampleEN": "Where can I buy a ticket?"
      },
      {
        "id": "n0295",
        "german": "der Fahrplan",
        "article": "der",
        "plural": "Pl. die Fahrpläne",
        "english": "timetable",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Hier ist der Fahrplan .",
        "exampleEN": "Here is the timetable."
      },
      {
        "id": "n0296",
        "german": "das Fahrrad",
        "article": "das",
        "plural": "Pl. die Fahrräder",
        "english": "bicycle",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ich fahre mit dem Fahrrad zur Arbeit.",
        "exampleEN": "I cycle to work."
      },
      {
        "id": "n0297",
        "german": "die Ferienwohnung",
        "article": "die",
        "plural": "Pl. die Ferienwohnungen",
        "english": "holiday flat",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Wir mieten eine Ferienwohnung am Meer.",
        "exampleEN": "We're renting a holiday flat by the sea."
      },
      {
        "id": "n0298",
        "german": "der Flug",
        "article": "der",
        "plural": "Pl. die Flüge",
        "english": "flight",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Der Flug dauert acht Stunden.",
        "exampleEN": "The flight takes eight hours."
      },
      {
        "id": "n0299",
        "german": "der Flughafen",
        "article": "der",
        "plural": "Pl. die Flughäfen",
        "english": "airport",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Der Flughafen ist weit weg.",
        "exampleEN": "The airport is far away."
      },
      {
        "id": "n0300",
        "german": "das Flugzeug",
        "article": "das",
        "plural": "Pl. die Flugzeuge",
        "english": "plane",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Das Flugzeug landet um 14 Uhr.",
        "exampleEN": "The plane lands at 2 p.m."
      },
      {
        "id": "n0301",
        "german": "der Führerschein",
        "article": "der",
        "plural": "Pl. die Führerscheine",
        "english": "driving licence",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Ich mache gerade den Führerschein .",
        "exampleEN": "I'm taking driving lessons at the moment."
      },
      {
        "id": "n0302",
        "german": "die Führung",
        "article": "die",
        "plural": "Pl. die Führungen",
        "english": "guided tour",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Die Führung durch das Schloss beginnt um 11 Uhr.",
        "exampleEN": "The tour of the palace starts at 11."
      },
      {
        "id": "n0303",
        "german": "das Fundbüro",
        "article": "das",
        "plural": "Pl. die Fundbüros",
        "english": "lost property office",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Fragen Sie im Fundbüro nach Ihrer Tasche.",
        "exampleEN": "Ask about your bag at the lost property office."
      },
      {
        "id": "n0304",
        "german": "das Gepäck",
        "article": "das",
        "plural": "kein Plural",
        "english": "luggage",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Wo ist mein Gepäck ?",
        "exampleEN": "Where is my luggage?"
      },
      {
        "id": "n0305",
        "german": "das Gleis",
        "article": "das",
        "plural": "Pl. die Gleise",
        "english": "platform, track",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Der Zug fährt von Gleis 3.",
        "exampleEN": "The train leaves from platform 3."
      },
      {
        "id": "n0306",
        "german": "die Grenze",
        "article": "die",
        "plural": "Pl. die Grenzen",
        "english": "border",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Wir sind schon an der Grenze zu Österreich.",
        "exampleEN": "We're already at the Austrian border."
      },
      {
        "id": "n0307",
        "german": "die Haltestelle",
        "article": "die",
        "plural": "Pl. die Haltestellen",
        "english": "(bus/tram) stop",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Die Haltestelle ist vor dem Haus.",
        "exampleEN": "The stop is in front of the house."
      },
      {
        "id": "n0308",
        "german": "die Hauptstadt",
        "article": "die",
        "plural": "Pl. die Hauptstädte",
        "english": "capital",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Islamabad ist die Hauptstadt von Pakistan.",
        "exampleEN": "Islamabad is the capital of Pakistan."
      },
      {
        "id": "n0309",
        "german": "das Hotel",
        "article": "das",
        "plural": "Pl. die Hotels",
        "english": "hotel",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Das Hotel ist im Zentrum.",
        "exampleEN": "The hotel is in the centre."
      },
      {
        "id": "n0310",
        "german": "die Jugendherberge",
        "article": "die",
        "plural": "Pl. die Jugendherbergen",
        "english": "youth hostel",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Die Jugendherberge ist sehr billig.",
        "exampleEN": "The youth hostel is very cheap."
      },
      {
        "id": "n0311",
        "german": "das Kino",
        "article": "das",
        "plural": "Pl. die Kinos",
        "english": "cinema",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Gehen wir heute ins Kino ?",
        "exampleEN": "Shall we go to the cinema today?"
      },
      {
        "id": "n0312",
        "german": "die Kirche",
        "article": "die",
        "plural": "Pl. die Kirchen",
        "english": "church",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Die Kirche ist sehr alt.",
        "exampleEN": "The church is very old."
      },
      {
        "id": "n0313",
        "german": "der Koffer",
        "article": "der",
        "plural": "Pl. die Koffer",
        "english": "suitcase",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Mein Koffer ist zu schwer.",
        "exampleEN": "My suitcase is too heavy."
      },
      {
        "id": "n0314",
        "german": "das Krankenhaus",
        "article": "das",
        "plural": "Pl. die Krankenhäuser",
        "english": "hospital",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Das Krankenhaus ist in der Stadtmitte.",
        "exampleEN": "The hospital is in the town centre."
      },
      {
        "id": "n0315",
        "german": "die Kreuzung",
        "article": "die",
        "plural": "Pl. die Kreuzungen",
        "english": "crossroads",
        "level": "A2",
        "type": "noun",
        "exampleDE": "An der Kreuzung gehen Sie links.",
        "exampleEN": "Turn left at the crossroads."
      },
      {
        "id": "n0316",
        "german": "das Museum",
        "article": "das",
        "plural": "Pl. die Museen",
        "english": "museum",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Das Museum ist montags geschlossen.",
        "exampleEN": "The museum is closed on Mondays."
      },
      {
        "id": "n0317",
        "german": "der Parkplatz",
        "article": "der",
        "plural": "Pl. die Parkplätze",
        "english": "parking space; car park",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Gibt es hier einen Parkplatz ?",
        "exampleEN": "Is there a car park here?"
      },
      {
        "id": "n0318",
        "german": "der Platz",
        "article": "der",
        "plural": "Pl. die Plätze",
        "english": "square; seat; space",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ist der Platz frei?",
        "exampleEN": "Is this seat free?"
      },
      {
        "id": "n0319",
        "german": "die Polizei",
        "article": "die",
        "plural": "kein Plural",
        "english": "police",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Ruf schnell die Polizei !",
        "exampleEN": "Call the police, quickly!"
      },
      {
        "id": "n0320",
        "german": "die Post",
        "article": "die",
        "plural": "kein Plural",
        "english": "post office; post",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ich gehe zur Post .",
        "exampleEN": "I'm going to the post office."
      },
      {
        "id": "n0321",
        "german": "das Rathaus",
        "article": "das",
        "plural": "Pl. die Rathäuser",
        "english": "town hall",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Das Rathaus ist am Marktplatz.",
        "exampleEN": "The town hall is on the market square."
      },
      {
        "id": "n0322",
        "german": "die Reise",
        "article": "die",
        "plural": "Pl. die Reisen",
        "english": "journey, trip",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Wie war die Reise ?",
        "exampleEN": "How was the trip?"
      },
      {
        "id": "n0323",
        "german": "die Rezeption",
        "article": "die",
        "plural": "Pl. die Rezeptionen",
        "english": "reception",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Den Schlüssel bekommen Sie an der Rezeption .",
        "exampleEN": "You get the key at reception."
      },
      {
        "id": "n0324",
        "german": "die Rückfahrt",
        "article": "die",
        "plural": "Pl. die Rückfahrten",
        "english": "return journey",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Die Rückfahrt ist am Sonntag.",
        "exampleEN": "The return journey is on Sunday."
      },
      {
        "id": "n0325",
        "german": "das Schiff",
        "article": "das",
        "plural": "Pl. die Schiffe",
        "english": "ship",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Wir fahren mit dem Schiff über den Rhein.",
        "exampleEN": "We're taking the ship across the Rhine."
      },
      {
        "id": "n0326",
        "german": "das Schild",
        "article": "das",
        "plural": "Pl. die Schilder",
        "english": "sign",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Auf dem Schild steht: Parken verboten.",
        "exampleEN": "The sign says: no parking."
      },
      {
        "id": "n0327",
        "german": "die Sehenswürdigkeit",
        "article": "die",
        "plural": "Pl. die Sehenswürdigkeiten",
        "english": "sight, attraction",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Köln hat viele Sehenswürdigkeiten .",
        "exampleEN": "Cologne has a lot of sights."
      },
      {
        "id": "n0328",
        "german": "die Stadt",
        "article": "die",
        "plural": "Pl. die Städte",
        "english": "town, city",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Hamburg ist eine große Stadt .",
        "exampleEN": "Hamburg is a big city."
      },
      {
        "id": "n0329",
        "german": "der Stadtplan",
        "article": "der",
        "plural": "Pl. die Stadtpläne",
        "english": "city map",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Haben Sie einen Stadtplan ?",
        "exampleEN": "Do you have a city map?"
      },
      {
        "id": "n0330",
        "german": "die Station",
        "article": "die",
        "plural": "Pl. die Stationen",
        "english": "stop, station",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Sie müssen noch drei Stationen fahren.",
        "exampleEN": "You have three more stops to go."
      },
      {
        "id": "n0331",
        "german": "der Stau",
        "article": "der",
        "plural": "Pl. die Staus",
        "english": "traffic jam",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Auf der Autobahn ist Stau .",
        "exampleEN": "There's a traffic jam on the motorway."
      },
      {
        "id": "n0332",
        "german": "der Strand",
        "article": "der",
        "plural": "Pl. die Strände",
        "english": "beach",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Im Sommer fahren wir an den Strand .",
        "exampleEN": "In summer we go to the beach."
      },
      {
        "id": "n0333",
        "german": "die Straßenbahn",
        "article": "die",
        "plural": "Pl. die Straßenbahnen",
        "english": "tram",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ich fahre mit der Straßenbahn .",
        "exampleEN": "I'm going by tram."
      },
      {
        "id": "n0334",
        "german": "die Tankstelle",
        "article": "die",
        "plural": "Pl. die Tankstellen",
        "english": "petrol station",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Wo ist die nächste Tankstelle ?",
        "exampleEN": "Where's the nearest petrol station?"
      },
      {
        "id": "n0335",
        "german": "das Taxi",
        "article": "das",
        "plural": "Pl. die Taxis",
        "english": "taxi",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Wir nehmen ein Taxi .",
        "exampleEN": "We'll take a taxi."
      },
      {
        "id": "n0336",
        "german": "das Ticket",
        "article": "das",
        "plural": "Pl. die Tickets",
        "english": "ticket",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Das Ticket kaufe ich online.",
        "exampleEN": "I buy the ticket online."
      },
      {
        "id": "n0337",
        "german": "der Tourist",
        "article": "der",
        "plural": "Pl. die Touristen",
        "english": "tourist",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Im Sommer kommen viele Touristen .",
        "exampleEN": "Lots of tourists come in summer."
      },
      {
        "id": "n0338",
        "german": "der Turm",
        "article": "der",
        "plural": "Pl. die Türme",
        "english": "tower",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Vom Turm sieht man die ganze Stadt.",
        "exampleEN": "You can see the whole city from the tower."
      },
      {
        "id": "n0339",
        "german": "die U-Bahn",
        "article": "die",
        "plural": "Pl. die U-Bahnen",
        "english": "underground, subway",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Die U-Bahn ist schneller.",
        "exampleEN": "The underground is faster."
      },
      {
        "id": "n0340",
        "german": "die Übernachtung",
        "article": "die",
        "plural": "Pl. die Übernachtungen",
        "english": "overnight stay",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Eine Übernachtung mit Frühstück kostet 70 Euro.",
        "exampleEN": "One night with breakfast costs 70 euros."
      },
      {
        "id": "n0341",
        "german": "der Unfall",
        "article": "der",
        "plural": "Pl. die Unfälle",
        "english": "accident",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Auf der Straße war ein Unfall .",
        "exampleEN": "There was an accident on the road."
      },
      {
        "id": "n0342",
        "german": "die Unterkunft",
        "article": "die",
        "plural": "Pl. die Unterkünfte",
        "english": "accommodation",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Wir suchen eine günstige Unterkunft .",
        "exampleEN": "We're looking for cheap accommodation."
      },
      {
        "id": "n0343",
        "german": "der Urlaub",
        "article": "der",
        "plural": "Pl. die Urlaube",
        "english": "holiday",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Im August machen wir Urlaub .",
        "exampleEN": "We're going on holiday in August."
      },
      {
        "id": "n0344",
        "german": "der Verkehr",
        "article": "der",
        "plural": "kein Plural",
        "english": "traffic",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Morgens ist viel Verkehr .",
        "exampleEN": "There's a lot of traffic in the mornings."
      },
      {
        "id": "n0345",
        "german": "das Verkehrsmittel",
        "article": "das",
        "plural": "Pl. die Verkehrsmittel",
        "english": "means of transport",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Ich nehme öffentliche Verkehrsmittel .",
        "exampleEN": "I use public transport."
      },
      {
        "id": "n0346",
        "german": "die Verspätung",
        "article": "die",
        "plural": "Pl. die Verspätungen",
        "english": "delay",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Der Zug hat 20 Minuten Verspätung .",
        "exampleEN": "The train is 20 minutes late."
      },
      {
        "id": "n0347",
        "german": "die Vorsicht",
        "article": "die",
        "plural": "kein Plural",
        "english": "caution",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Vorsicht , die Tür schließt!",
        "exampleEN": "Careful, the door is closing!"
      },
      {
        "id": "n0348",
        "german": "der Wagen",
        "article": "der",
        "plural": "Pl. die Wagen",
        "english": "car; carriage",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Unser Platz ist in Wagen 7.",
        "exampleEN": "Our seat is in carriage 7."
      },
      {
        "id": "n0349",
        "german": "der Weg",
        "article": "der",
        "plural": "Pl. die Wege",
        "english": "way, path",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ist das der richtige Weg ?",
        "exampleEN": "Is this the right way?"
      },
      {
        "id": "n0350",
        "german": "das Zentrum",
        "article": "das",
        "plural": "Pl. die Zentren",
        "english": "centre",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Das Hotel liegt im Zentrum .",
        "exampleEN": "The hotel is in the centre."
      },
      {
        "id": "n0351",
        "german": "der Zoo",
        "article": "der",
        "plural": "Pl. die Zoos",
        "english": "zoo",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Am Sonntag gehen wir mit den Kindern in den Zoo .",
        "exampleEN": "On Sunday we're going to the zoo with the children."
      },
      {
        "id": "n0352",
        "german": "der Art. Zug",
        "article": "der Art.",
        "plural": "Pl. die Züge A1 Nomen · Plural",
        "english": "train English",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Der Zug hat zehn Minuten Verspätung. 18 Nomen",
        "exampleEN": "The train is ten minutes late. 50 Nomen Beispielsatz · example"
      }
    ]
  },
  {
    "id": "nomen_arbeit",
    "title": "Arbeit & Beruf",
    "emoji": "💼",
    "entries": [
      {
        "id": "n0353",
        "german": "die Abteilung",
        "article": "die",
        "plural": "Pl. die Abteilungen",
        "english": "department",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Ich arbeite in der Abteilung Verkauf.",
        "exampleEN": "I work in the sales department."
      },
      {
        "id": "n0354",
        "german": "die Arbeit",
        "article": "die",
        "plural": "Pl. die Arbeiten",
        "english": "work, job",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Die Arbeit beginnt um 8 Uhr.",
        "exampleEN": "Work starts at 8 o'clock."
      },
      {
        "id": "n0355",
        "german": "der Arbeitgeber",
        "article": "der",
        "plural": "Pl. die Arbeitgeber",
        "english": "employer",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Mein Arbeitgeber zahlt das Ticket.",
        "exampleEN": "My employer pays for the ticket."
      },
      {
        "id": "n0356",
        "german": "der Arbeitsplatz",
        "article": "der",
        "plural": "Pl. die Arbeitsplätze",
        "english": "workplace; job",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Mein Arbeitsplatz ist im Büro.",
        "exampleEN": "My workplace is in the office."
      },
      {
        "id": "n0357",
        "german": "der Arbeitsvertrag",
        "article": "der",
        "plural": "Pl. die Arbeitsverträge",
        "english": "employment contract",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Ich habe meinen Arbeitsvertrag bekommen.",
        "exampleEN": "I've received my employment contract."
      },
      {
        "id": "n0358",
        "german": "der/die Arzt / Ärztin",
        "article": "der/die",
        "plural": "Pl. die Ärzte / Ärztinnen",
        "english": "doctor",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ich muss zum Arzt gehen.",
        "exampleEN": "I have to go to the doctor."
      },
      {
        "id": "n0359",
        "german": "die Ausbildung",
        "article": "die",
        "plural": "Pl. die Ausbildungen",
        "english": "vocational training",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Er macht eine Ausbildung als Mechaniker.",
        "exampleEN": "He's training as a mechanic."
      },
      {
        "id": "n0360",
        "german": "die Besprechung",
        "article": "die",
        "plural": "Pl. die Besprechungen",
        "english": "meeting",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Die Besprechung beginnt um zehn.",
        "exampleEN": "The meeting starts at ten."
      },
      {
        "id": "n0361",
        "german": "die Bewerbung",
        "article": "die",
        "plural": "Pl. die Bewerbungen",
        "english": "application",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Ich schicke meine Bewerbung per E-Mail.",
        "exampleEN": "I'm sending my application by email."
      },
      {
        "id": "n0362",
        "german": "das Büro",
        "article": "das",
        "plural": "Pl. die Büros",
        "english": "office",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Mein Büro ist im zweiten Stock.",
        "exampleEN": "My office is on the second floor."
      },
      {
        "id": "n0363",
        "german": "der/die Chef / Chefin",
        "article": "der/die",
        "plural": "Pl. die Chefs / Chefinnen",
        "english": "boss",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Meine Chefin ist sehr nett.",
        "exampleEN": "My boss is very nice."
      },
      {
        "id": "n0364",
        "german": "der Computer",
        "article": "der",
        "plural": "Pl. die Computer",
        "english": "computer",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ich arbeite viel am Computer .",
        "exampleEN": "I work a lot on the computer."
      },
      {
        "id": "n0365",
        "german": "der Drucker",
        "article": "der",
        "plural": "Pl. die Drucker",
        "english": "printer",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Der Drucker hat kein Papier mehr.",
        "exampleEN": "The printer is out of paper."
      },
      {
        "id": "n0366",
        "german": "die Erfahrung",
        "article": "die",
        "plural": "Pl. die Erfahrungen",
        "english": "experience",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Ich habe drei Jahre Erfahrung als Kellner.",
        "exampleEN": "I have three years' experience as a waiter."
      },
      {
        "id": "n0367",
        "german": "der Feierabend",
        "article": "der",
        "plural": "Pl. die Feierabende",
        "english": "end of the working day",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Um 17 Uhr habe ich Feierabend .",
        "exampleEN": "I finish work at 5 p.m."
      },
      {
        "id": "n0368",
        "german": "die Firma",
        "article": "die",
        "plural": "Pl. die Firmen",
        "english": "company, firm",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ich arbeite bei einer kleinen Firma .",
        "exampleEN": "I work for a small company."
      },
      {
        "id": "n0369",
        "german": "der/die Friseur / Friseurin",
        "article": "der/die",
        "plural": "Pl. die Friseure / Friseurinnen",
        "english": "hairdresser",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ich gehe heute zum Friseur .",
        "exampleEN": "I'm going to the hairdresser's today."
      },
      {
        "id": "n0370",
        "german": "das Gehalt",
        "article": "das",
        "plural": "Pl. die Gehälter",
        "english": "salary",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Das Gehalt kommt am Ende des Monats.",
        "exampleEN": "The salary comes at the end of the month."
      },
      {
        "id": "n0371",
        "german": "die Gruppe",
        "article": "die",
        "plural": "Pl. die Gruppen",
        "english": "group",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Wir arbeiten in Gruppen .",
        "exampleEN": "We work in groups."
      },
      {
        "id": "n0372",
        "german": "der Handwerker",
        "article": "der",
        "plural": "Pl. die Handwerker",
        "english": "tradesman",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Morgen kommt ein Handwerker .",
        "exampleEN": "A tradesman is coming tomorrow."
      },
      {
        "id": "n0373",
        "german": "die Information",
        "article": "die",
        "plural": "Pl. die Informationen",
        "english": "information",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Weitere Informationen finden Sie online.",
        "exampleEN": "You'll find more information online."
      },
      {
        "id": "n0374",
        "german": "der Job",
        "article": "der",
        "plural": "Pl. die Jobs",
        "english": "job",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ich suche einen neuen Job .",
        "exampleEN": "I'm looking for a new job."
      },
      {
        "id": "n0375",
        "german": "der/die Kellner / Kellnerin",
        "article": "der/die",
        "plural": "Pl. die Kellner / Kellnerinnen",
        "english": "waiter / waitress",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Der Kellner bringt die Speisekarte.",
        "exampleEN": "The waiter brings the menu."
      },
      {
        "id": "n0376",
        "german": "der/die Koch / Köchin",
        "article": "der/die",
        "plural": "Pl. die Köche / Köchinnen",
        "english": "cook, chef",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Mein Bruder ist Koch .",
        "exampleEN": "My brother is a chef."
      },
      {
        "id": "n0377",
        "german": "der/die Kollege / Kollegin",
        "article": "der/die",
        "plural": "Pl. die Kollegen / Kolleginnen",
        "english": "colleague",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Meine Kollegen sind sehr freundlich.",
        "exampleEN": "My colleagues are very friendly."
      },
      {
        "id": "n0378",
        "german": "der Kontakt",
        "article": "der",
        "plural": "Pl. die Kontakte",
        "english": "contact",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Ich habe noch Kontakt zu meinen alten Kollegen.",
        "exampleEN": "I'm still in contact with my old colleagues."
      },
      {
        "id": "n0379",
        "german": "das Konto",
        "article": "das",
        "plural": "Pl. die Konten",
        "english": "bank account",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ich möchte ein Konto eröffnen.",
        "exampleEN": "I'd like to open an account."
      },
      {
        "id": "n0380",
        "german": "die Kopie",
        "article": "die",
        "plural": "Pl. die Kopien",
        "english": "copy",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Machen Sie bitte zwei Kopien .",
        "exampleEN": "Please make two copies."
      },
      {
        "id": "n0381",
        "german": "die Krankmeldung",
        "article": "die",
        "plural": "Pl. die Krankmeldungen",
        "english": "sick note",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Ich schicke die Krankmeldung an die Firma.",
        "exampleEN": "I'm sending the sick note to the company."
      },
      {
        "id": "n0382",
        "german": "die Kündigung",
        "article": "die",
        "plural": "Pl. die Kündigungen",
        "english": "notice; dismissal",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Er hat die Kündigung bekommen.",
        "exampleEN": "He's been given notice."
      },
      {
        "id": "n0383",
        "german": "der Lebenslauf",
        "article": "der",
        "plural": "Pl. die Lebensläufe",
        "english": "CV",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Bitte schicken Sie uns Ihren Lebenslauf .",
        "exampleEN": "Please send us your CV."
      },
      {
        "id": "n0384",
        "german": "der/die Lehrer / Lehrerin",
        "article": "der/die",
        "plural": "Pl. die Lehrer / Lehrerinnen",
        "english": "teacher",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Unsere Lehrerin heißt Frau Klein.",
        "exampleEN": "Our teacher is called Ms Klein."
      },
      {
        "id": "n0385",
        "german": "die Maschine",
        "article": "die",
        "plural": "Pl. die Maschinen",
        "english": "machine",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Die Maschine ist kaputt.",
        "exampleEN": "The machine is broken."
      },
      {
        "id": "n0386",
        "german": "der Mitarbeiter",
        "article": "der",
        "plural": "Pl. die Mitarbeiter",
        "english": "employee",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Die Firma hat 50 Mitarbeiter .",
        "exampleEN": "The company has 50 employees."
      },
      {
        "id": "n0387",
        "german": "die Notiz",
        "article": "die",
        "plural": "Pl. die Notizen",
        "english": "note",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Ich mache mir eine Notiz .",
        "exampleEN": "I'm making a note."
      },
      {
        "id": "n0388",
        "german": "die Pause",
        "article": "die",
        "plural": "Pl. die Pausen",
        "english": "break",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Um 12 Uhr machen wir Pause .",
        "exampleEN": "We take a break at 12 o'clock."
      },
      {
        "id": "n0389",
        "german": "das Praktikum",
        "article": "das",
        "plural": "Pl. die Praktika",
        "english": "internship",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Im Sommer mache ich ein Praktikum .",
        "exampleEN": "I'm doing an internship in the summer."
      },
      {
        "id": "n0390",
        "german": "das Projekt",
        "article": "das",
        "plural": "Pl. die Projekte",
        "english": "project",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Das Projekt ist fast fertig.",
        "exampleEN": "The project is almost finished."
      },
      {
        "id": "n0391",
        "german": "die Schicht",
        "article": "die",
        "plural": "Pl. die Schichten",
        "english": "shift",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Diese Woche habe ich Schicht am Abend.",
        "exampleEN": "This week I'm on the evening shift."
      },
      {
        "id": "n0392",
        "german": "die Stelle",
        "article": "die",
        "plural": "Pl. die Stellen",
        "english": "job, position",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Ich suche eine neue Stelle .",
        "exampleEN": "I'm looking for a new job."
      },
      {
        "id": "n0393",
        "german": "der/die Student / Studentin",
        "article": "der/die",
        "plural": "Pl. die Studenten / Studentinnen",
        "english": "(university) student",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Sie ist Studentin in Leipzig.",
        "exampleEN": "She is a student in Leipzig."
      },
      {
        "id": "n0394",
        "german": "das Team",
        "article": "das",
        "plural": "Pl. die Teams",
        "english": "team",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Unser Team ist sehr nett.",
        "exampleEN": "Our team is very nice."
      },
      {
        "id": "n0395",
        "german": "die Teilzeit",
        "article": "die",
        "plural": "kein Plural",
        "english": "part-time",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Sie arbeitet in Teilzeit .",
        "exampleEN": "She works part-time."
      },
      {
        "id": "n0396",
        "german": "die Überstunde",
        "article": "die",
        "plural": "Pl. die Überstunden",
        "english": "overtime (hour)",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Letzte Woche habe ich viele Überstunden gemacht.",
        "exampleEN": "Last week I did a lot of overtime."
      },
      {
        "id": "n0397",
        "german": "die (Pl.) Unterlagen",
        "article": "die (Pl.)",
        "plural": "nur Plural",
        "english": "documents",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Bringen Sie bitte alle Unterlagen mit.",
        "exampleEN": "Please bring all your documents."
      },
      {
        "id": "n0398",
        "german": "der/die Verkäufer / Verkäuferin",
        "article": "der/die",
        "plural": "Pl. die Verkäufer / Verkäuferinnen",
        "english": "shop assistant",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Die Verkäuferin hilft mir. 22 Nomen",
        "exampleEN": "The shop assistant is helping me."
      },
      {
        "id": "n0399",
        "german": "die Vollzeit",
        "article": "die",
        "plural": "kein Plural",
        "english": "full-time",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Die Stelle ist in Vollzeit .",
        "exampleEN": "The job is full-time."
      },
      {
        "id": "n0400",
        "german": "das Vorstellungsgespräch",
        "article": "das",
        "plural": "Pl. die Vorstellungsgespräche",
        "english": "job interview",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Morgen habe ich ein Vorstellungsgespräch .",
        "exampleEN": "I have a job interview tomorrow."
      },
      {
        "id": "n0401",
        "german": "die Werkstatt",
        "article": "die",
        "plural": "Pl. die Werkstätten",
        "english": "garage; workshop",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Mein Auto ist in der Werkstatt .",
        "exampleEN": "My car is at the garage."
      },
      {
        "id": "n0402",
        "german": "der Art. Zettel",
        "article": "der Art.",
        "plural": "Pl. die Zettel Nomen · Plural",
        "english": "piece of paper, note English",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Ich schreibe es auf einen Zettel .",
        "exampleEN": "I'll write it on a piece of paper. 45 Nomen Beispielsatz · example"
      }
    ]
  },
  {
    "id": "nomen_gesundheit",
    "title": "Gesundheit & Körper",
    "emoji": "🏥",
    "entries": [
      {
        "id": "n0403",
        "german": "die Allergie",
        "article": "die",
        "plural": "Pl. die Allergien",
        "english": "allergy",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Haben Sie eine Allergie ?",
        "exampleEN": "Do you have an allergy?"
      },
      {
        "id": "n0404",
        "german": "der Arm",
        "article": "der",
        "plural": "Pl. die Arme",
        "english": "arm",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Mein Arm tut weh.",
        "exampleEN": "My arm hurts."
      },
      {
        "id": "n0405",
        "german": "das Auge",
        "article": "das",
        "plural": "Pl. die Augen",
        "english": "eye",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Sie hat blaue Augen .",
        "exampleEN": "She has blue eyes."
      },
      {
        "id": "n0406",
        "german": "der Bauch",
        "article": "der",
        "plural": "Pl. die Bäuche",
        "english": "stomach, belly",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ich habe Bauchschmerzen .",
        "exampleEN": "I have a stomach ache."
      },
      {
        "id": "n0407",
        "german": "das Bein",
        "article": "das",
        "plural": "Pl. die Beine",
        "english": "leg",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Er hat ein Problem mit dem Bein .",
        "exampleEN": "He has a problem with his leg."
      },
      {
        "id": "n0408",
        "german": "die Erkältung",
        "article": "die",
        "plural": "Pl. die Erkältungen",
        "english": "cold",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Ich habe eine starke Erkältung .",
        "exampleEN": "I've got a bad cold."
      },
      {
        "id": "n0409",
        "german": "das Fieber",
        "article": "das",
        "plural": "kein Plural",
        "english": "fever, temperature",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Das Kind hat Fieber .",
        "exampleEN": "The child has a temperature."
      },
      {
        "id": "n0410",
        "german": "der Finger",
        "article": "der",
        "plural": "Pl. die Finger",
        "english": "finger",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ich habe fünf Finger an jeder Hand.",
        "exampleEN": "I have five fingers on each hand."
      },
      {
        "id": "n0411",
        "german": "der Fuß",
        "article": "der",
        "plural": "Pl. die Füße",
        "english": "foot",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Mein Fuß tut weh.",
        "exampleEN": "My foot hurts."
      },
      {
        "id": "n0412",
        "german": "das Gesicht",
        "article": "das",
        "plural": "Pl. die Gesichter",
        "english": "face",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Wasch dir bitte das Gesicht .",
        "exampleEN": "Please wash your face."
      },
      {
        "id": "n0413",
        "german": "die Gesundheit",
        "article": "die",
        "plural": "kein Plural",
        "english": "health",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Gesundheit ! (beim Niesen)",
        "exampleEN": "Bless you! (when sneezing)"
      },
      {
        "id": "n0414",
        "german": "die Grippe",
        "article": "die",
        "plural": "kein Plural",
        "english": "flu",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Mein Chef hat die Grippe .",
        "exampleEN": "My boss has the flu."
      },
      {
        "id": "n0415",
        "german": "das Haar",
        "article": "das",
        "plural": "Pl. die Haare",
        "english": "hair",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Sie hat lange, schwarze Haare .",
        "exampleEN": "She has long black hair."
      },
      {
        "id": "n0416",
        "german": "der Hals",
        "article": "der",
        "plural": "Pl. die Hälse",
        "english": "throat; neck",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ich habe Halsschmerzen .",
        "exampleEN": "I have a sore throat."
      },
      {
        "id": "n0417",
        "german": "die Hand",
        "article": "die",
        "plural": "Pl. die Hände",
        "english": "hand",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Wasch dir bitte die Hände .",
        "exampleEN": "Please wash your hands."
      },
      {
        "id": "n0418",
        "german": "der Hausarzt",
        "article": "der",
        "plural": "Pl. die Hausärzte",
        "english": "family doctor, GP",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Zuerst gehen Sie zum Hausarzt .",
        "exampleEN": "First you go to your GP."
      },
      {
        "id": "n0419",
        "german": "die Haut",
        "article": "die",
        "plural": "kein Plural",
        "english": "skin",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Die Sonne ist nicht gut für die Haut .",
        "exampleEN": "The sun isn't good for your skin."
      },
      {
        "id": "n0420",
        "german": "das Herz",
        "article": "das",
        "plural": "Pl. die Herzen",
        "english": "heart",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Sport ist gut für das Herz .",
        "exampleEN": "Exercise is good for the heart."
      },
      {
        "id": "n0421",
        "german": "die Hilfe",
        "article": "die",
        "plural": "Pl. die Hilfen",
        "english": "help",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Hilfe ! Bitte rufen Sie die 112!",
        "exampleEN": "Help! Please call 112!"
      },
      {
        "id": "n0422",
        "german": "der Husten",
        "article": "der",
        "plural": "kein Plural",
        "english": "cough",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Gegen den Husten trinke ich Tee.",
        "exampleEN": "I drink tea for my cough."
      },
      {
        "id": "n0423",
        "german": "das Knie",
        "article": "das",
        "plural": "Pl. die Knie",
        "english": "knee",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Er hat Schmerzen im Knie .",
        "exampleEN": "He has a pain in his knee."
      },
      {
        "id": "n0424",
        "german": "der Kopf",
        "article": "der",
        "plural": "Pl. die Köpfe",
        "english": "head",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ich habe Kopfschmerzen .",
        "exampleEN": "I have a headache."
      },
      {
        "id": "n0425",
        "german": "der Körper",
        "article": "der",
        "plural": "Pl. die Körper",
        "english": "body",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Sport ist gut für den Körper .",
        "exampleEN": "Sport is good for the body."
      },
      {
        "id": "n0426",
        "german": "die Krankenkasse",
        "article": "die",
        "plural": "Pl. die Krankenkassen",
        "english": "health insurance",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Bei welcher Krankenkasse sind Sie?",
        "exampleEN": "Which health insurance are you with?"
      },
      {
        "id": "n0427",
        "german": "die Krankheit",
        "article": "die",
        "plural": "Pl. die Krankheiten",
        "english": "illness",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Das ist keine schlimme Krankheit .",
        "exampleEN": "That's not a serious illness."
      },
      {
        "id": "n0428",
        "german": "der Magen",
        "article": "der",
        "plural": "Pl. die Mägen",
        "english": "stomach",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Mir tut der Magen weh.",
        "exampleEN": "My stomach hurts."
      },
      {
        "id": "n0429",
        "german": "das Medikament",
        "article": "das",
        "plural": "Pl. die Medikamente",
        "english": "medicine",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Nehmen Sie das Medikament dreimal am Tag.",
        "exampleEN": "Take the medicine three times a day."
      },
      {
        "id": "n0430",
        "german": "der Mund",
        "article": "der",
        "plural": "Pl. die Münder",
        "english": "mouth",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Machen Sie bitte den Mund auf.",
        "exampleEN": "Please open your mouth."
      },
      {
        "id": "n0431",
        "german": "die Nase",
        "article": "die",
        "plural": "Pl. die Nasen",
        "english": "nose",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Meine Nase ist rot.",
        "exampleEN": "My nose is red."
      },
      {
        "id": "n0432",
        "german": "die Notaufnahme",
        "article": "die",
        "plural": "Pl. die Notaufnahmen",
        "english": "A & E, emergency room",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Wir fahren sofort in die Notaufnahme .",
        "exampleEN": "We're going straight to A & E."
      },
      {
        "id": "n0433",
        "german": "der Notruf",
        "article": "der",
        "plural": "Pl. die Notrufe",
        "english": "emergency call/number",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Der Notruf in Deutschland ist 112.",
        "exampleEN": "The emergency number in Germany is 112."
      },
      {
        "id": "n0434",
        "german": "das Ohr",
        "article": "das",
        "plural": "Pl. die Ohren",
        "english": "ear",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Mein Ohr tut weh.",
        "exampleEN": "My ear hurts."
      },
      {
        "id": "n0435",
        "german": "die Praxis",
        "article": "die",
        "plural": "Pl. die Praxen",
        "english": "(doctor's) surgery",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Die Praxis ist am Mittwoch geschlossen.",
        "exampleEN": "The surgery is closed on Wednesday."
      },
      {
        "id": "n0436",
        "german": "das Rezept",
        "article": "das",
        "plural": "Pl. die Rezepte",
        "english": "prescription; recipe",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Sie bekommen ein Rezept vom Arzt.",
        "exampleEN": "You get a prescription from the doctor."
      },
      {
        "id": "n0437",
        "german": "der Rücken",
        "article": "der",
        "plural": "Pl. die Rücken",
        "english": "back",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Mein Rücken tut weh.",
        "exampleEN": "My back hurts."
      },
      {
        "id": "n0438",
        "german": "die Salbe",
        "article": "die",
        "plural": "Pl. die Salben",
        "english": "ointment",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Die Salbe hilft gegen die Schmerzen.",
        "exampleEN": "The ointment helps with the pain."
      },
      {
        "id": "n0439",
        "german": "die (Pl.) Schmerzen",
        "article": "die (Pl.)",
        "plural": "nur Plural",
        "english": "pain",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Haben Sie Schmerzen ?",
        "exampleEN": "Are you in pain?"
      },
      {
        "id": "n0440",
        "german": "der Schnupfen",
        "article": "der",
        "plural": "kein Plural",
        "english": "runny nose",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Das Kind hat Schnupfen .",
        "exampleEN": "The child has a runny nose."
      },
      {
        "id": "n0441",
        "german": "die Schulter",
        "article": "die",
        "plural": "Pl. die Schultern",
        "english": "shoulder",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Meine Schulter tut weh.",
        "exampleEN": "My shoulder hurts."
      },
      {
        "id": "n0442",
        "german": "die Sprechstunde",
        "article": "die",
        "plural": "Pl. die Sprechstunden",
        "english": "consulting hours",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Die Sprechstunde ist von 8 bis 12 Uhr.",
        "exampleEN": "Consulting hours are from 8 to 12."
      },
      {
        "id": "n0443",
        "german": "die Tablette",
        "article": "die",
        "plural": "Pl. die Tabletten",
        "english": "tablet, pill",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Nehmen Sie eine Tablette .",
        "exampleEN": "Take a tablet."
      },
      {
        "id": "n0444",
        "german": "die Versichertenkarte",
        "article": "die",
        "plural": "Pl. die Versichertenkarten",
        "english": "health insurance card",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Haben Sie Ihre Versichertenkarte dabei?",
        "exampleEN": "Do you have your health insurance card with you?"
      },
      {
        "id": "n0445",
        "german": "das Wartezimmer",
        "article": "das",
        "plural": "Pl. die Wartezimmer",
        "english": "waiting room",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Bitte nehmen Sie im Wartezimmer Platz.",
        "exampleEN": "Please take a seat in the waiting room."
      },
      {
        "id": "n0446",
        "german": "der Zahn",
        "article": "der",
        "plural": "Pl. die Zähne",
        "english": "tooth",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ich putze zweimal am Tag die Zähne . 26 Nomen",
        "exampleEN": "I brush my teeth twice a day."
      },
      {
        "id": "n0447",
        "german": "der Zahnarzt",
        "article": "der",
        "plural": "Pl. die Zahnärzte",
        "english": "dentist",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Ich habe morgen einen Termin beim Zahnarzt .",
        "exampleEN": "I have a dentist's appointment tomorrow."
      }
    ]
  },
  {
    "id": "nomen_zeit",
    "title": "Zeit & Kalender",
    "emoji": "📅",
    "entries": [
      {
        "id": "n0448",
        "german": "der Abend",
        "article": "der",
        "plural": "Pl. die Abende",
        "english": "evening",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Am Abend lese ich.",
        "exampleEN": "In the evening I read."
      },
      {
        "id": "n0449",
        "german": "der Anfang",
        "article": "der",
        "plural": "Pl. die Anfänge",
        "english": "beginning",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Anfang Mai fahren wir in den Urlaub.",
        "exampleEN": "We're going on holiday at the beginning of May."
      },
      {
        "id": "n0450",
        "german": "das Datum",
        "article": "das",
        "plural": "Pl. die Daten",
        "english": "date",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Welches Datum ist heute?",
        "exampleEN": "What's the date today?"
      },
      {
        "id": "n0451",
        "german": "das Ende",
        "article": "das",
        "plural": "Pl. die Enden",
        "english": "end",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Am Ende des Monats bekomme ich mein Gehalt.",
        "exampleEN": "I get my salary at the end of the month."
      },
      {
        "id": "n0452",
        "german": "der Feiertag",
        "article": "der",
        "plural": "Pl. die Feiertage",
        "english": "public holiday",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Am Feiertag arbeite ich nicht.",
        "exampleEN": "I don't work on the public holiday."
      },
      {
        "id": "n0453",
        "german": "die (Pl.) Ferien",
        "article": "die (Pl.)",
        "plural": "nur Plural",
        "english": "(school) holidays",
        "level": "A1",
        "type": "noun",
        "exampleDE": "In den Ferien fahren wir ans Meer.",
        "exampleEN": "In the holidays we go to the seaside."
      },
      {
        "id": "n0454",
        "german": "der Frühling",
        "article": "der",
        "plural": "kein Plural",
        "english": "spring",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Im Frühling ist es warm.",
        "exampleEN": "It's warm in spring."
      },
      {
        "id": "n0455",
        "german": "der Geburtstag",
        "article": "der",
        "plural": "Pl. die Geburtstage",
        "english": "birthday",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Wann hast du Geburtstag ?",
        "exampleEN": "When is your birthday?"
      },
      {
        "id": "n0456",
        "german": "der Herbst",
        "article": "der",
        "plural": "kein Plural",
        "english": "autumn",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Im Herbst regnet es oft.",
        "exampleEN": "It often rains in autumn."
      },
      {
        "id": "n0457",
        "german": "das Jahr",
        "article": "das",
        "plural": "Pl. die Jahre",
        "english": "year",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ich wohne seit einem Jahr hier.",
        "exampleEN": "I've lived here for a year."
      },
      {
        "id": "n0458",
        "german": "der Kalender",
        "article": "der",
        "plural": "Pl. die Kalender",
        "english": "calendar",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ich schreibe den Termin in den Kalender .",
        "exampleEN": "I'm writing the appointment in the calendar."
      },
      {
        "id": "n0459",
        "german": "die Minute",
        "article": "die",
        "plural": "Pl. die Minuten",
        "english": "minute",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ich komme in zehn Minuten .",
        "exampleEN": "I'll be there in ten minutes."
      },
      {
        "id": "n0460",
        "german": "der Mittag",
        "article": "der",
        "plural": "Pl. die Mittage",
        "english": "midday, noon",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Am Mittag esse ich in der Kantine.",
        "exampleEN": "At midday I eat in the canteen."
      },
      {
        "id": "n0461",
        "german": "die Mitte",
        "article": "die",
        "plural": "kein Plural",
        "english": "middle",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Mitte Juni habe ich Prüfung.",
        "exampleEN": "I have my exam in mid-June."
      },
      {
        "id": "n0462",
        "german": "der Moment",
        "article": "der",
        "plural": "Pl. die Momente",
        "english": "moment",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Einen Moment , bitte!",
        "exampleEN": "One moment, please!"
      },
      {
        "id": "n0463",
        "german": "der Monat",
        "article": "der",
        "plural": "Pl. die Monate",
        "english": "month",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Der Kurs dauert einen Monat .",
        "exampleEN": "The course lasts one month."
      },
      {
        "id": "n0464",
        "german": "der Morgen",
        "article": "der",
        "plural": "Pl. die Morgen",
        "english": "morning",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Am Morgen trinke ich Kaffee.",
        "exampleEN": "In the morning I drink coffee."
      },
      {
        "id": "n0465",
        "german": "der Nachmittag",
        "article": "der",
        "plural": "Pl. die Nachmittage",
        "english": "afternoon",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Am Nachmittag habe ich frei.",
        "exampleEN": "I'm free in the afternoon."
      },
      {
        "id": "n0466",
        "german": "die Nacht",
        "article": "die",
        "plural": "Pl. die Nächte",
        "english": "night",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Gute Nacht !",
        "exampleEN": "Good night!"
      },
      {
        "id": "n0467",
        "german": "der Sommer",
        "article": "der",
        "plural": "kein Plural",
        "english": "summer",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Im Sommer ist es heiß.",
        "exampleEN": "It's hot in summer."
      },
      {
        "id": "n0468",
        "german": "die Stunde",
        "article": "die",
        "plural": "Pl. die Stunden",
        "english": "hour; lesson",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Der Film dauert zwei Stunden .",
        "exampleEN": "The film lasts two hours."
      },
      {
        "id": "n0469",
        "german": "der Tag",
        "article": "der",
        "plural": "Pl. die Tage",
        "english": "day",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ich arbeite acht Stunden am Tag .",
        "exampleEN": "I work eight hours a day."
      },
      {
        "id": "n0470",
        "german": "der Termin",
        "article": "der",
        "plural": "Pl. die Termine",
        "english": "appointment",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ich habe morgen einen Termin beim Arzt.",
        "exampleEN": "I have a doctor's appointment tomorrow."
      },
      {
        "id": "n0471",
        "german": "die Uhr",
        "article": "die",
        "plural": "Pl. die Uhren",
        "english": "clock, watch; o'clock",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Wie viel Uhr ist es?",
        "exampleEN": "What time is it?"
      },
      {
        "id": "n0472",
        "german": "die Uhrzeit",
        "article": "die",
        "plural": "Pl. die Uhrzeiten",
        "english": "time (of day)",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Um welche Uhrzeit beginnt der Kurs?",
        "exampleEN": "At what time does the course start?"
      },
      {
        "id": "n0473",
        "german": "der Vormittag",
        "article": "der",
        "plural": "Pl. die Vormittage",
        "english": "morning (before noon)",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Am Vormittag gehe ich einkaufen.",
        "exampleEN": "I go shopping in the morning."
      },
      {
        "id": "n0474",
        "german": "der Winter",
        "article": "der",
        "plural": "kein Plural",
        "english": "winter",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Im Winter ist es kalt.",
        "exampleEN": "It's cold in winter."
      },
      {
        "id": "n0475",
        "german": "die Woche",
        "article": "die",
        "plural": "Pl. die Wochen",
        "english": "week",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ich lerne drei Stunden pro Woche .",
        "exampleEN": "I study three hours a week."
      },
      {
        "id": "n0476",
        "german": "das Wochenende",
        "article": "das",
        "plural": "Pl. die Wochenenden",
        "english": "weekend",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Am Wochenende schlafe ich lange.",
        "exampleEN": "At the weekend I sleep in."
      },
      {
        "id": "n0477",
        "german": "die Zeit",
        "article": "die",
        "plural": "Pl. die Zeiten",
        "english": "time",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Hast du heute Zeit ? 20 Nomen",
        "exampleEN": "Do you have time today?"
      },
      {
        "id": "n0478",
        "german": "die Art. Zukunft  Nomen · Plural",
        "article": "die Art.",
        "plural": "kein Plural",
        "english": "future English",
        "level": "A2",
        "type": "noun",
        "exampleDE": "In der Zukunft möchte ich in Deutschland bleiben.",
        "exampleEN": "In the future I'd like to stay in Germany. 50 Nomen Beispielsatz · example"
      }
    ]
  },
  {
    "id": "nomen_freizeit",
    "title": "Freizeit, Sport & Kultur",
    "emoji": "⚽",
    "entries": [
      {
        "id": "n0479",
        "german": "der Ausflug",
        "article": "der",
        "plural": "Pl. die Ausflüge",
        "english": "day trip, outing",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Am Sonntag machen wir einen Ausflug .",
        "exampleEN": "On Sunday we're going on a trip."
      },
      {
        "id": "n0480",
        "german": "die Ausstellung",
        "article": "die",
        "plural": "Pl. die Ausstellungen",
        "english": "exhibition",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Im Museum gibt es eine neue Ausstellung .",
        "exampleEN": "There's a new exhibition at the museum."
      },
      {
        "id": "n0481",
        "german": "der Ball",
        "article": "der",
        "plural": "Pl. die Bälle",
        "english": "ball",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Die Kinder spielen mit dem Ball .",
        "exampleEN": "The children are playing with the ball."
      },
      {
        "id": "n0482",
        "german": "die Band",
        "article": "die",
        "plural": "Pl. die Bands",
        "english": "band (music)",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Die Band spielt heute im Park.",
        "exampleEN": "The band is playing in the park today."
      },
      {
        "id": "n0483",
        "german": "das Buch",
        "article": "das",
        "plural": "Pl. die Bücher",
        "english": "book",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Das Buch ist sehr interessant.",
        "exampleEN": "The book is very interesting."
      },
      {
        "id": "n0484",
        "german": "der Club",
        "article": "der",
        "plural": "Pl. die Clubs",
        "english": "club",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Am Wochenende gehen wir in einen Club .",
        "exampleEN": "At the weekend we're going to a club."
      },
      {
        "id": "n0485",
        "german": "die Einladung",
        "article": "die",
        "plural": "Pl. die Einladungen",
        "english": "invitation",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Danke für die Einladung !",
        "exampleEN": "Thanks for the invitation!"
      },
      {
        "id": "n0486",
        "german": "der Eintritt",
        "article": "der",
        "plural": "kein Plural",
        "english": "admission",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Der Eintritt kostet 8 Euro.",
        "exampleEN": "Admission costs 8 euros."
      },
      {
        "id": "n0487",
        "german": "die Eintrittskarte",
        "article": "die",
        "plural": "Pl. die Eintrittskarten",
        "english": "ticket (entry)",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Ich habe zwei Eintrittskarten für das Konzert.",
        "exampleEN": "I have two tickets for the concert."
      },
      {
        "id": "n0488",
        "german": "der Fan",
        "article": "der",
        "plural": "Pl. die Fans",
        "english": "fan",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Ich bin ein großer Fan von Cricket.",
        "exampleEN": "I'm a big cricket fan."
      },
      {
        "id": "n0489",
        "german": "das Fest",
        "article": "das",
        "plural": "Pl. die Feste",
        "english": "party, festival",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Das Fest beginnt um 18 Uhr.",
        "exampleEN": "The party starts at 6 p.m."
      },
      {
        "id": "n0490",
        "german": "das Festival",
        "article": "das",
        "plural": "Pl. die Festivals",
        "english": "festival",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Im Sommer gibt es viele Festivals .",
        "exampleEN": "There are lots of festivals in summer."
      },
      {
        "id": "n0491",
        "german": "der Film",
        "article": "der",
        "plural": "Pl. die Filme",
        "english": "film",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Der Film war toll.",
        "exampleEN": "The film was great."
      },
      {
        "id": "n0492",
        "german": "das Fitnessstudio",
        "article": "das",
        "plural": "Pl. die Fitnessstudios",
        "english": "gym",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ich gehe zweimal pro Woche ins Fitnessstudio .",
        "exampleEN": "I go to the gym twice a week."
      },
      {
        "id": "n0493",
        "german": "das Foto",
        "article": "das",
        "plural": "Pl. die Fotos",
        "english": "photo",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Schau mal, ein Foto von meiner Familie!",
        "exampleEN": "Look, a photo of my family!"
      },
      {
        "id": "n0494",
        "german": "die Freizeit",
        "article": "die",
        "plural": "kein Plural",
        "english": "free time",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Was machst du in deiner Freizeit ?",
        "exampleEN": "What do you do in your free time?"
      },
      {
        "id": "n0495",
        "german": "der Fußball",
        "article": "der",
        "plural": "Pl. die Fußbälle",
        "english": "football",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Am Samstag spielen wir Fußball .",
        "exampleEN": "On Saturday we play football."
      },
      {
        "id": "n0496",
        "german": "das Geschenk",
        "article": "das",
        "plural": "Pl. die Geschenke",
        "english": "present, gift",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Das Geschenk ist für dich.",
        "exampleEN": "The present is for you."
      },
      {
        "id": "n0497",
        "german": "die Geschichte",
        "article": "die",
        "plural": "Pl. die Geschichten",
        "english": "story; history",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Oma erzählt eine Geschichte .",
        "exampleEN": "Grandma is telling a story."
      },
      {
        "id": "n0498",
        "german": "die Gitarre",
        "article": "die",
        "plural": "Pl. die Gitarren",
        "english": "guitar",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Er spielt Gitarre .",
        "exampleEN": "He plays the guitar."
      },
      {
        "id": "n0499",
        "german": "das Hobby",
        "article": "das",
        "plural": "Pl. die Hobbys",
        "english": "hobby",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Mein Hobby ist Kochen.",
        "exampleEN": "My hobby is cooking."
      },
      {
        "id": "n0500",
        "german": "das Instrument",
        "article": "das",
        "plural": "Pl. die Instrumente",
        "english": "instrument",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Spielst du ein Instrument ?",
        "exampleEN": "Do you play an instrument?"
      },
      {
        "id": "n0501",
        "german": "die Kamera",
        "article": "die",
        "plural": "Pl. die Kameras",
        "english": "camera",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Meine Kamera macht sehr gute Fotos.",
        "exampleEN": "My camera takes very good photos."
      },
      {
        "id": "n0502",
        "german": "das Klavier",
        "article": "das",
        "plural": "Pl. die Klaviere",
        "english": "piano",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Meine Tochter lernt Klavier .",
        "exampleEN": "My daughter is learning the piano."
      },
      {
        "id": "n0503",
        "german": "das Konzert",
        "article": "das",
        "plural": "Pl. die Konzerte",
        "english": "concert",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Das Konzert ist am Freitag.",
        "exampleEN": "The concert is on Friday."
      },
      {
        "id": "n0504",
        "german": "der Krimi",
        "article": "der",
        "plural": "Pl. die Krimis",
        "english": "crime story/film",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Am Sonntag sehe ich gern einen Krimi .",
        "exampleEN": "On Sundays I like watching a crime drama."
      },
      {
        "id": "n0505",
        "german": "die Kultur",
        "article": "die",
        "plural": "Pl. die Kulturen",
        "english": "culture",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Ich interessiere mich für die deutsche Kultur .",
        "exampleEN": "I'm interested in German culture."
      },
      {
        "id": "n0506",
        "german": "die Kunst",
        "article": "die",
        "plural": "Pl. die Künste",
        "english": "art",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Im Museum gibt es moderne Kunst .",
        "exampleEN": "There's modern art in the museum."
      },
      {
        "id": "n0507",
        "german": "das Lied",
        "article": "das",
        "plural": "Pl. die Lieder",
        "english": "song",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Das Lied kenne ich!",
        "exampleEN": "I know this song!"
      },
      {
        "id": "n0508",
        "german": "die Lust",
        "article": "die",
        "plural": "kein Plural",
        "english": "desire; mood",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Ich habe heute keine Lust auf Sport.",
        "exampleEN": "I don't feel like sport today."
      },
      {
        "id": "n0509",
        "german": "die Mannschaft",
        "article": "die",
        "plural": "Pl. die Mannschaften",
        "english": "team",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Unsere Mannschaft hat 3 zu 1 gewonnen.",
        "exampleEN": "Our team won 3-1."
      },
      {
        "id": "n0510",
        "german": "das Mitglied",
        "article": "das",
        "plural": "Pl. die Mitglieder",
        "english": "member",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Ich bin Mitglied in einem Sportverein.",
        "exampleEN": "I'm a member of a sports club."
      },
      {
        "id": "n0511",
        "german": "die Musik",
        "article": "die",
        "plural": "kein Plural",
        "english": "music",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ich höre gern Musik .",
        "exampleEN": "I like listening to music."
      },
      {
        "id": "n0512",
        "german": "der Park",
        "article": "der",
        "plural": "Pl. die Parks",
        "english": "park",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Wir gehen im Park spazieren.",
        "exampleEN": "We go for a walk in the park."
      },
      {
        "id": "n0513",
        "german": "die Party",
        "article": "die",
        "plural": "Pl. die Partys",
        "english": "party",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Kommst du zu meiner Party ?",
        "exampleEN": "Are you coming to my party?"
      },
      {
        "id": "n0514",
        "german": "das Programm",
        "article": "das",
        "plural": "Pl. die Programme",
        "english": "programme",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Was ist heute im Programm ?",
        "exampleEN": "What's on the programme today?"
      },
      {
        "id": "n0515",
        "german": "das Schwimmbad",
        "article": "das",
        "plural": "Pl. die Schwimmbäder",
        "english": "swimming pool",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Das Schwimmbad ist im Sommer geöffnet.",
        "exampleEN": "The swimming pool is open in the summer."
      },
      {
        "id": "n0516",
        "german": "der Spaziergang",
        "article": "der",
        "plural": "Pl. die Spaziergänge",
        "english": "walk",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Nach dem Essen machen wir einen Spaziergang .",
        "exampleEN": "After the meal we go for a walk."
      },
      {
        "id": "n0517",
        "german": "der Spaß",
        "article": "der",
        "plural": "kein Plural",
        "english": "fun",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Viel Spaß auf der Party!",
        "exampleEN": "Have fun at the party!"
      },
      {
        "id": "n0518",
        "german": "das Spiel",
        "article": "das",
        "plural": "Pl. die Spiele",
        "english": "game, match",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Das Spiel beginnt um 15 Uhr.",
        "exampleEN": "The match starts at 3 p.m."
      },
      {
        "id": "n0519",
        "german": "der Spieler",
        "article": "der",
        "plural": "Pl. die Spieler",
        "english": "player",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Die Spieler kommen auf den Platz.",
        "exampleEN": "The players are coming onto the pitch."
      },
      {
        "id": "n0520",
        "german": "der Sport",
        "article": "der",
        "plural": "kein Plural",
        "english": "sport",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ich mache gern Sport .",
        "exampleEN": "I like doing sport."
      },
      {
        "id": "n0521",
        "german": "der Tanz",
        "article": "der",
        "plural": "Pl. die Tänze",
        "english": "dance",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Darf ich dich um einen Tanz bitten?",
        "exampleEN": "May I have this dance?"
      },
      {
        "id": "n0522",
        "german": "das Theater",
        "article": "das",
        "plural": "Pl. die Theater",
        "english": "theatre",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Wir gehen heute Abend ins Theater .",
        "exampleEN": "We're going to the theatre tonight."
      },
      {
        "id": "n0523",
        "german": "das Training",
        "article": "das",
        "plural": "Pl. die Trainings",
        "english": "training",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Das Training ist dienstags um 18 Uhr.",
        "exampleEN": "Training is on Tuesdays at 6 p.m."
      },
      {
        "id": "n0524",
        "german": "der Traum",
        "article": "der",
        "plural": "Pl. die Träume",
        "english": "dream",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Ein eigenes Haus ist mein Traum .",
        "exampleEN": "My own house is my dream."
      },
      {
        "id": "n0525",
        "german": "die Veranstaltung",
        "article": "die",
        "plural": "Pl. die Veranstaltungen",
        "english": "event",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Die Veranstaltung ist kostenlos.",
        "exampleEN": "The event is free."
      },
      {
        "id": "n0526",
        "german": "der Verein",
        "article": "der",
        "plural": "Pl. die Vereine",
        "english": "club",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Er spielt in einem Fußballverein . 23 Nomen",
        "exampleEN": "He plays in a football club."
      },
      {
        "id": "n0527",
        "german": "der Witz",
        "article": "der",
        "plural": "Pl. die Witze",
        "english": "joke",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Kennst du einen guten Witz ?",
        "exampleEN": "Do you know a good joke?"
      },
      {
        "id": "n0528",
        "german": "der Art. Wunsch",
        "article": "der Art.",
        "plural": "Pl. die Wünsche Nomen · Plural",
        "english": "wish English",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Hast du einen Wunsch zum Geburtstag?",
        "exampleEN": "Is there anything you'd like for your birthday? 81 Nomen Beispielsatz · example"
      }
    ]
  },
  {
    "id": "nomen_lernen",
    "title": "Lernen, Medien & Kommunikation",
    "emoji": "📱",
    "entries": [
      {
        "id": "n0529",
        "german": "der Abschluss",
        "article": "der",
        "plural": "Pl. die Abschlüsse",
        "english": "degree, qualification",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Ich habe einen Abschluss in Informatik.",
        "exampleEN": "I have a degree in computer science."
      },
      {
        "id": "n0530",
        "german": "der Absender",
        "article": "der",
        "plural": "Pl. die Absender",
        "english": "sender",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Der Absender steht auf dem Brief.",
        "exampleEN": "The sender is written on the letter."
      },
      {
        "id": "n0531",
        "german": "die Ahnung",
        "article": "die",
        "plural": "Pl. die Ahnungen",
        "english": "idea, clue",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Ich habe keine Ahnung .",
        "exampleEN": "I have no idea."
      },
      {
        "id": "n0532",
        "german": "der Akku",
        "article": "der",
        "plural": "Pl. die Akkus",
        "english": "battery (rechargeable)",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Mein Akku ist fast leer.",
        "exampleEN": "My battery is almost dead."
      },
      {
        "id": "n0533",
        "german": "die Anmeldung",
        "article": "die",
        "plural": "Pl. die Anmeldungen",
        "english": "registration",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Die Anmeldung für den Kurs ist online.",
        "exampleEN": "Registration for the course is online."
      },
      {
        "id": "n0534",
        "german": "der Anruf",
        "article": "der",
        "plural": "Pl. die Anrufe",
        "english": "phone call",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ich warte auf einen Anruf .",
        "exampleEN": "I'm waiting for a call."
      },
      {
        "id": "n0535",
        "german": "der Anrufbeantworter",
        "article": "der",
        "plural": "Pl. die Anrufbeantworter",
        "english": "answering machine",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Bitte sprechen Sie auf den Anrufbeantworter .",
        "exampleEN": "Please leave a message on the answering machine."
      },
      {
        "id": "n0536",
        "german": "die Antwort",
        "article": "die",
        "plural": "Pl. die Antworten",
        "english": "answer",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Die Antwort ist richtig.",
        "exampleEN": "The answer is correct."
      },
      {
        "id": "n0537",
        "german": "die Anzeige",
        "article": "die",
        "plural": "Pl. die Anzeigen",
        "english": "advert",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ich lese die Anzeigen in der Zeitung.",
        "exampleEN": "I read the adverts in the newspaper."
      },
      {
        "id": "n0538",
        "german": "die App",
        "article": "die",
        "plural": "Pl. die Apps",
        "english": "app",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Die Tickets kaufe ich mit einer App .",
        "exampleEN": "I buy the tickets with an app."
      },
      {
        "id": "n0539",
        "german": "der Artikel",
        "article": "der",
        "plural": "Pl. die Artikel",
        "english": "article",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Ich habe einen Artikel über Paderborn gelesen.",
        "exampleEN": "I read an article about Paderborn."
      },
      {
        "id": "n0540",
        "german": "die Aufgabe",
        "article": "die",
        "plural": "Pl. die Aufgaben",
        "english": "task, exercise",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Lesen Sie die Aufgabe .",
        "exampleEN": "Read the task."
      },
      {
        "id": "n0541",
        "german": "das Bild",
        "article": "das",
        "plural": "Pl. die Bilder",
        "english": "picture",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Sehen Sie das Bild an.",
        "exampleEN": "Look at the picture."
      },
      {
        "id": "n0542",
        "german": "der Bildschirm",
        "article": "der",
        "plural": "Pl. die Bildschirme",
        "english": "screen",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Der Bildschirm ist zu dunkel.",
        "exampleEN": "The screen is too dark."
      },
      {
        "id": "n0543",
        "german": "der Bleistift",
        "article": "der",
        "plural": "Pl. die Bleistifte",
        "english": "pencil",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Schreiben Sie mit Bleistift .",
        "exampleEN": "Write in pencil."
      },
      {
        "id": "n0544",
        "german": "der Brief",
        "article": "der",
        "plural": "Pl. die Briefe",
        "english": "letter",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ich schreibe einen Brief an meine Oma.",
        "exampleEN": "I'm writing a letter to my grandma."
      },
      {
        "id": "n0545",
        "german": "die Briefmarke",
        "article": "die",
        "plural": "Pl. die Briefmarken",
        "english": "stamp",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ich brauche eine Briefmarke für den Brief.",
        "exampleEN": "I need a stamp for the letter."
      },
      {
        "id": "n0546",
        "german": "der Buchstabe",
        "article": "der",
        "plural": "Pl. die Buchstaben",
        "english": "letter (of the alphabet)",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Das Wort hat fünf Buchstaben .",
        "exampleEN": "The word has five letters."
      },
      {
        "id": "n0547",
        "german": "die Datei",
        "article": "die",
        "plural": "Pl. die Dateien",
        "english": "file",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Ich schicke dir die Datei per E-Mail.",
        "exampleEN": "I'll send you the file by email."
      },
      {
        "id": "n0548",
        "german": "die E-Mail",
        "article": "die",
        "plural": "Pl. die E-Mails",
        "english": "email",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ich schreibe dir eine E-Mail .",
        "exampleEN": "I'll write you an email."
      },
      {
        "id": "n0549",
        "german": "der Empfänger",
        "article": "der",
        "plural": "Pl. die Empfänger",
        "english": "recipient",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Schreiben Sie den Empfänger auf den Brief.",
        "exampleEN": "Write the recipient's name on the letter."
      },
      {
        "id": "n0550",
        "german": "die Erlaubnis",
        "article": "die",
        "plural": "Pl. die Erlaubnisse",
        "english": "permission",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Für das Foto brauchen Sie eine Erlaubnis .",
        "exampleEN": "You need permission for the photo."
      },
      {
        "id": "n0551",
        "german": "das Fach",
        "article": "das",
        "plural": "Pl. die Fächer",
        "english": "subject",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Mein Lieblings fach war Mathe.",
        "exampleEN": "My favourite subject was maths."
      },
      {
        "id": "n0552",
        "german": "der Fehler",
        "article": "der",
        "plural": "Pl. die Fehler",
        "english": "mistake",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Kein Problem, jeder macht Fehler .",
        "exampleEN": "No problem, everyone makes mistakes."
      },
      {
        "id": "n0553",
        "german": "der Fernseher",
        "article": "der",
        "plural": "Pl. die Fernseher",
        "english": "television (set)",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Der Fernseher ist im Wohnzimmer.",
        "exampleEN": "The TV is in the living room."
      },
      {
        "id": "n0554",
        "german": "die Frage",
        "article": "die",
        "plural": "Pl. die Fragen",
        "english": "question",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ich habe eine Frage .",
        "exampleEN": "I have a question."
      },
      {
        "id": "n0555",
        "german": "das Gegenteil",
        "article": "das",
        "plural": "Pl. die Gegenteile",
        "english": "opposite",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Was ist das Gegenteil von groß?",
        "exampleEN": "What's the opposite of big?"
      },
      {
        "id": "n0556",
        "german": "das Gerät",
        "article": "das",
        "plural": "Pl. die Geräte",
        "english": "device, appliance",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Das Gerät ist kaputt.",
        "exampleEN": "The device is broken."
      },
      {
        "id": "n0557",
        "german": "das Gespräch",
        "article": "das",
        "plural": "Pl. die Gespräche",
        "english": "conversation",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Das Gespräch war sehr nett.",
        "exampleEN": "The conversation was very nice."
      },
      {
        "id": "n0558",
        "german": "das Handy",
        "article": "das",
        "plural": "Pl. die Handys",
        "english": "mobile phone",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Mein Handy ist kaputt.",
        "exampleEN": "My mobile phone is broken."
      },
      {
        "id": "n0559",
        "german": "die Hausaufgabe",
        "article": "die",
        "plural": "Pl. die Hausaufgaben",
        "english": "homework",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Hast du deine Hausaufgaben gemacht?",
        "exampleEN": "Have you done your homework?"
      },
      {
        "id": "n0560",
        "german": "das Heft",
        "article": "das",
        "plural": "Pl. die Hefte",
        "english": "exercise book",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Schreiben Sie das Wort in Ihr Heft .",
        "exampleEN": "Write the word in your exercise book."
      },
      {
        "id": "n0561",
        "german": "die Homepage",
        "article": "die",
        "plural": "Pl. die Homepages",
        "english": "website, homepage",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Die Öffnungszeiten stehen auf der Homepage .",
        "exampleEN": "The opening hours are on the website."
      },
      {
        "id": "n0562",
        "german": "die Idee",
        "article": "die",
        "plural": "Pl. die Ideen",
        "english": "idea",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Das ist eine gute Idee !",
        "exampleEN": "That's a good idea!"
      },
      {
        "id": "n0563",
        "german": "das Interesse",
        "article": "das",
        "plural": "Pl. die Interessen",
        "english": "interest",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Ich habe großes Interesse an dem Kurs.",
        "exampleEN": "I'm very interested in the course."
      },
      {
        "id": "n0564",
        "german": "das Internet",
        "article": "das",
        "plural": "kein Plural",
        "english": "internet",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ich suche die Information im Internet .",
        "exampleEN": "I'm looking for the information on the internet."
      },
      {
        "id": "n0565",
        "german": "der Kindergarten",
        "article": "der",
        "plural": "Pl. die Kindergärten",
        "english": "nursery school",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Meine Tochter geht in den Kindergarten .",
        "exampleEN": "My daughter goes to nursery school."
      },
      {
        "id": "n0566",
        "german": "die Klasse",
        "article": "die",
        "plural": "Pl. die Klassen",
        "english": "class; year (at school)",
        "level": "A1",
        "type": "noun",
        "exampleDE": "In meiner Klasse sind 15 Leute.",
        "exampleEN": "There are 15 people in my class."
      },
      {
        "id": "n0567",
        "german": "der Kuli",
        "article": "der",
        "plural": "Pl. die Kulis",
        "english": "ballpoint pen",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Hast du einen Kuli für mich?",
        "exampleEN": "Do you have a pen for me?"
      },
      {
        "id": "n0568",
        "german": "der Kurs",
        "article": "der",
        "plural": "Pl. die Kurse",
        "english": "course",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Der Kurs ist am Montag und Mittwoch.",
        "exampleEN": "The course is on Monday and Wednesday."
      },
      {
        "id": "n0569",
        "german": "das Ladegerät",
        "article": "das",
        "plural": "Pl. die Ladegeräte",
        "english": "charger",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Hast du ein Ladegerät für mich?",
        "exampleEN": "Do you have a charger for me?"
      },
      {
        "id": "n0570",
        "german": "der Laptop",
        "article": "der",
        "plural": "Pl. die Laptops",
        "english": "laptop",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Ich arbeite oft am Laptop .",
        "exampleEN": "I often work on my laptop."
      },
      {
        "id": "n0571",
        "german": "der Link",
        "article": "der",
        "plural": "Pl. die Links",
        "english": "link",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Ich schicke dir den Link .",
        "exampleEN": "I'll send you the link."
      },
      {
        "id": "n0572",
        "german": "die Lösung",
        "article": "die",
        "plural": "Pl. die Lösungen",
        "english": "solution",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Die Lösungen sind am Ende des Buches.",
        "exampleEN": "The answers are at the end of the book."
      },
      {
        "id": "n0573",
        "german": "die Mailbox",
        "article": "die",
        "plural": "Pl. die Mailboxen",
        "english": "voicemail",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Bitte sprich auf meine Mailbox .",
        "exampleEN": "Please leave a message on my voicemail."
      },
      {
        "id": "n0574",
        "german": "die Meinung",
        "article": "die",
        "plural": "Pl. die Meinungen",
        "english": "opinion",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Was ist deine Meinung ?",
        "exampleEN": "What's your opinion?"
      },
      {
        "id": "n0575",
        "german": "die Nachricht",
        "article": "die",
        "plural": "Pl. die Nachrichten",
        "english": "message; (pl.) news",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ich habe deine Nachricht bekommen.",
        "exampleEN": "I got your message."
      },
      {
        "id": "n0576",
        "german": "die (Pl.) Nachrichten",
        "article": "die (Pl.)",
        "plural": "nur Plural",
        "english": "the news",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Ich sehe jeden Abend die Nachrichten .",
        "exampleEN": "I watch the news every evening."
      },
      {
        "id": "n0577",
        "german": "die Note",
        "article": "die",
        "plural": "Pl. die Noten",
        "english": "grade, mark",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Sie hat eine gute Note bekommen.",
        "exampleEN": "She got a good mark."
      },
      {
        "id": "n0578",
        "german": "die Nummer",
        "article": "die",
        "plural": "Pl. die Nummern",
        "english": "number",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Wie ist deine Nummer ?",
        "exampleEN": "What's your number?"
      },
      {
        "id": "n0579",
        "german": "das Paket",
        "article": "das",
        "plural": "Pl. die Pakete",
        "english": "parcel",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Das Paket ist für Sie.",
        "exampleEN": "The parcel is for you."
      },
      {
        "id": "n0580",
        "german": "das Papier",
        "article": "das",
        "plural": "kein Plural",
        "english": "paper",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ich brauche ein Blatt Papier .",
        "exampleEN": "I need a sheet of paper."
      },
      {
        "id": "n0581",
        "german": "das Passwort",
        "article": "das",
        "plural": "Pl. die Passwörter",
        "english": "password",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Ich habe mein Passwort vergessen.",
        "exampleEN": "I've forgotten my password."
      },
      {
        "id": "n0582",
        "german": "die Postkarte",
        "article": "die",
        "plural": "Pl. die Postkarten",
        "english": "postcard",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ich schicke dir eine Postkarte aus Rom.",
        "exampleEN": "I'll send you a postcard from Rome."
      },
      {
        "id": "n0583",
        "german": "die Prüfung",
        "article": "die",
        "plural": "Pl. die Prüfungen",
        "english": "exam",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Die Prüfung ist am Freitag.",
        "exampleEN": "The exam is on Friday."
      },
      {
        "id": "n0584",
        "german": "das Radio",
        "article": "das",
        "plural": "Pl. die Radios",
        "english": "radio",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Im Auto höre ich Radio .",
        "exampleEN": "I listen to the radio in the car."
      },
      {
        "id": "n0585",
        "german": "der Satz",
        "article": "der",
        "plural": "Pl. die Sätze",
        "english": "sentence",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Schreiben Sie einen Satz .",
        "exampleEN": "Write a sentence."
      },
      {
        "id": "n0586",
        "german": "die Schule",
        "article": "die",
        "plural": "Pl. die Schulen",
        "english": "school",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Die Kinder gehen in die Schule .",
        "exampleEN": "The children go to school."
      },
      {
        "id": "n0587",
        "german": "der Schüler",
        "article": "der",
        "plural": "Pl. die Schüler",
        "english": "pupil, school student",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Die Schüler haben heute frei.",
        "exampleEN": "The pupils have the day off today."
      },
      {
        "id": "n0588",
        "german": "die Seite",
        "article": "die",
        "plural": "Pl. die Seiten",
        "english": "page; side",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Öffnen Sie das Buch auf Seite 20.",
        "exampleEN": "Open the book at page 20."
      },
      {
        "id": "n0589",
        "german": "die Sendung",
        "article": "die",
        "plural": "Pl. die Sendungen",
        "english": "programme (TV/radio)",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Die Sendung beginnt um 20 Uhr.",
        "exampleEN": "The programme starts at 8 p.m."
      },
      {
        "id": "n0590",
        "german": "die SMS",
        "article": "die",
        "plural": "Pl. die SMS",
        "english": "text message",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Schreib mir eine SMS !",
        "exampleEN": "Send me a text!"
      },
      {
        "id": "n0591",
        "german": "die Sprachschule",
        "article": "die",
        "plural": "Pl. die Sprachschulen",
        "english": "language school",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Ich lerne Deutsch an einer Sprachschule .",
        "exampleEN": "I'm learning German at a language school."
      },
      {
        "id": "n0592",
        "german": "der Stift",
        "article": "der",
        "plural": "Pl. die Stifte",
        "english": "pen, pencil",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Mein Stift ist weg.",
        "exampleEN": "My pen is gone."
      },
      {
        "id": "n0593",
        "german": "das Studium",
        "article": "das",
        "plural": "kein Plural",
        "english": "university studies",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Nach dem Studium möchte ich hier arbeiten.",
        "exampleEN": "After my studies I'd like to work here."
      },
      {
        "id": "n0594",
        "german": "die Tabelle",
        "article": "die",
        "plural": "Pl. die Tabellen",
        "english": "table, chart",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Ergänzen Sie die Tabelle .",
        "exampleEN": "Complete the table."
      },
      {
        "id": "n0595",
        "german": "das Telefon",
        "article": "das",
        "plural": "Pl. die Telefone",
        "english": "telephone",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Das Telefon klingelt.",
        "exampleEN": "The phone is ringing."
      },
      {
        "id": "n0596",
        "german": "der Test",
        "article": "der",
        "plural": "Pl. die Tests",
        "english": "test",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Morgen schreiben wir einen Test .",
        "exampleEN": "We're doing a test tomorrow."
      },
      {
        "id": "n0597",
        "german": "der Text",
        "article": "der",
        "plural": "Pl. die Texte",
        "english": "text",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Lesen Sie den Text .",
        "exampleEN": "Read the text."
      },
      {
        "id": "n0598",
        "german": "das Thema",
        "article": "das",
        "plural": "Pl. die Themen",
        "english": "topic",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Das Thema ist sehr interessant.",
        "exampleEN": "The topic is very interesting."
      },
      {
        "id": "n0599",
        "german": "der Tipp",
        "article": "der",
        "plural": "Pl. die Tipps",
        "english": "tip",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Hast du einen Tipp für mich?",
        "exampleEN": "Do you have a tip for me?"
      },
      {
        "id": "n0600",
        "german": "die Übung",
        "article": "die",
        "plural": "Pl. die Übungen",
        "english": "exercise",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Machen Sie bitte Übung 3.",
        "exampleEN": "Please do exercise 3."
      },
      {
        "id": "n0601",
        "german": "die Universität",
        "article": "die",
        "plural": "Pl. die Universitäten",
        "english": "university",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Mein Bruder studiert an der Universität Köln.",
        "exampleEN": "My brother studies at the University of Cologne."
      },
      {
        "id": "n0602",
        "german": "der Unterricht",
        "article": "der",
        "plural": "kein Plural",
        "english": "lessons, class",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Der Unterricht beginnt um 9 Uhr.",
        "exampleEN": "Lessons start at 9 o'clock."
      },
      {
        "id": "n0603",
        "german": "die Volkshochschule",
        "article": "die",
        "plural": "Pl. die Volkshochschulen",
        "english": "adult education centre",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Ich lerne Deutsch an der Volkshochschule .",
        "exampleEN": "I'm learning German at the adult education centre."
      },
      {
        "id": "n0604",
        "german": "das Wort",
        "article": "das",
        "plural": "Pl. die Wörter",
        "english": "word",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Was bedeutet dieses Wort ?",
        "exampleEN": "What does this word mean?"
      },
      {
        "id": "n0605",
        "german": "das Wörterbuch",
        "article": "das",
        "plural": "Pl. die Wörterbücher",
        "english": "dictionary",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ich suche das Wort im Wörterbuch . 18 Nomen",
        "exampleEN": "I'm looking the word up in the dictionary."
      },
      {
        "id": "n0606",
        "german": "die Zahl",
        "article": "die",
        "plural": "Pl. die Zahlen",
        "english": "number",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Schreiben Sie die Zahl in Worten.",
        "exampleEN": "Write the number in words."
      },
      {
        "id": "n0607",
        "german": "die Zeitschrift",
        "article": "die",
        "plural": "Pl. die Zeitschriften",
        "english": "magazine",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Beim Arzt lese ich Zeitschriften .",
        "exampleEN": "At the doctor's I read magazines."
      },
      {
        "id": "n0608",
        "german": "die Zeitung",
        "article": "die",
        "plural": "Pl. die Zeitungen",
        "english": "newspaper",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Mein Vater liest die Zeitung . 18 Nomen",
        "exampleEN": "My father reads the newspaper."
      },
      {
        "id": "n0609",
        "german": "das Art. Zeugnis",
        "article": "das Art.",
        "plural": "Pl. die Zeugnisse Nomen · Plural",
        "english": "certificate; report English",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Für die Bewerbung brauche ich mein Zeugnis .",
        "exampleEN": "I need my certificate for the application. 15 Nomen Beispielsatz · example"
      }
    ]
  },
  {
    "id": "nomen_aemter",
    "title": "Ämter, Bank & Post",
    "emoji": "🏛️",
    "entries": [
      {
        "id": "n0610",
        "german": "das Amt",
        "article": "das",
        "plural": "Pl. die Ämter",
        "english": "(public) office",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Ich muss morgen zum Amt .",
        "exampleEN": "I have to go to the office tomorrow."
      },
      {
        "id": "n0611",
        "german": "der Antrag",
        "article": "der",
        "plural": "Pl. die Anträge",
        "english": "application (form)",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Füllen Sie bitte den Antrag aus.",
        "exampleEN": "Please fill in the application form."
      },
      {
        "id": "n0612",
        "german": "die Aufenthaltserlaubnis",
        "article": "die",
        "plural": "Pl. die Aufenthaltserlaubnisse",
        "english": "residence permit",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Meine Aufenthaltserlaubnis ist zwei Jahre gültig.",
        "exampleEN": "My residence permit is valid for two years."
      },
      {
        "id": "n0613",
        "german": "die Ausländerbehörde",
        "article": "die",
        "plural": "Pl. die Ausländerbehörden",
        "english": "immigration office",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Ich habe einen Termin bei der Ausländerbehörde .",
        "exampleEN": "I have an appointment at the immigration office."
      },
      {
        "id": "n0614",
        "german": "die Bankkarte",
        "article": "die",
        "plural": "Pl. die Bankkarten",
        "english": "bank card",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Ich zahle mit der Bankkarte .",
        "exampleEN": "I'm paying with my bank card."
      },
      {
        "id": "n0615",
        "german": "die Bescheinigung",
        "article": "die",
        "plural": "Pl. die Bescheinigungen",
        "english": "certificate, confirmation",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Ich brauche eine Bescheinigung vom Arbeitgeber.",
        "exampleEN": "I need a confirmation from my employer."
      },
      {
        "id": "n0616",
        "german": "der Briefkasten",
        "article": "der",
        "plural": "Pl. die Briefkästen",
        "english": "letterbox, postbox",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Der Brief liegt im Briefkasten .",
        "exampleEN": "The letter is in the letterbox."
      },
      {
        "id": "n0617",
        "german": "das Bürgeramt",
        "article": "das",
        "plural": "Pl. die Bürgerämter",
        "english": "citizens' office",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Die Anmeldung macht man im Bürgeramt .",
        "exampleEN": "You register at the citizens' office."
      },
      {
        "id": "n0618",
        "german": "das Einschreiben",
        "article": "das",
        "plural": "Pl. die Einschreiben",
        "english": "registered letter",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Ich schicke die Kündigung per Einschreiben .",
        "exampleEN": "I'm sending the cancellation by registered post."
      },
      {
        "id": "n0619",
        "german": "die Gebühr",
        "article": "die",
        "plural": "Pl. die Gebühren",
        "english": "fee",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Die Gebühr kostet 30 Euro.",
        "exampleEN": "The fee is 30 euros."
      },
      {
        "id": "n0620",
        "german": "der Geldautomat",
        "article": "der",
        "plural": "Pl. die Geldautomaten",
        "english": "cash machine",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Gibt es hier einen Geldautomaten ?",
        "exampleEN": "Is there a cash machine here?"
      },
      {
        "id": "n0621",
        "german": "die Steuer",
        "article": "die",
        "plural": "Pl. die Steuern",
        "english": "tax",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Vom Gehalt zahlt man Steuern .",
        "exampleEN": "You pay taxes on your salary."
      },
      {
        "id": "n0622",
        "german": "die Überweisung",
        "article": "die",
        "plural": "Pl. die Überweisungen",
        "english": "bank transfer; referral",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Die Überweisung dauert einen Tag.",
        "exampleEN": "The bank transfer takes one day."
      },
      {
        "id": "n0623",
        "german": "die Versicherung",
        "article": "die",
        "plural": "Pl. die Versicherungen",
        "english": "insurance",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Hast du eine Versicherung für das Fahrrad?",
        "exampleEN": "Do you have insurance for your bike?"
      },
      {
        "id": "n0624",
        "german": "das Art. Visum",
        "article": "das Art.",
        "plural": "Pl. die Visa Nomen · Plural",
        "english": "visa English",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Für Deutschland brauche ich ein Visum .",
        "exampleEN": "I need a visa for Germany. 34 Nomen Beispielsatz · example"
      }
    ]
  },
  {
    "id": "nomen_natur",
    "title": "Natur, Umwelt & Wetter",
    "emoji": "🌳",
    "entries": [
      {
        "id": "n0625",
        "german": "der Baum",
        "article": "der",
        "plural": "Pl. die Bäume",
        "english": "tree",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Im Garten steht ein großer Baum .",
        "exampleEN": "There's a big tree in the garden."
      },
      {
        "id": "n0626",
        "german": "der Berg",
        "article": "der",
        "plural": "Pl. die Berge",
        "english": "mountain",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Wir wandern auf einen Berg .",
        "exampleEN": "We're hiking up a mountain."
      },
      {
        "id": "n0627",
        "german": "das Blatt",
        "article": "das",
        "plural": "Pl. die Blätter",
        "english": "leaf; sheet",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Im Herbst werden die Blätter bunt.",
        "exampleEN": "In autumn the leaves change colour."
      },
      {
        "id": "n0628",
        "german": "die Blume",
        "article": "die",
        "plural": "Pl. die Blumen",
        "english": "flower",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Die Blumen sind sehr schön.",
        "exampleEN": "The flowers are very beautiful."
      },
      {
        "id": "n0629",
        "german": "das Eis",
        "article": "das",
        "plural": "kein Plural",
        "english": "ice; ice cream",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Pass auf, auf der Straße ist Eis !",
        "exampleEN": "Be careful, there's ice on the road!"
      },
      {
        "id": "n0630",
        "german": "der Fluss",
        "article": "der",
        "plural": "Pl. die Flüsse",
        "english": "river",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Der Rhein ist ein großer Fluss .",
        "exampleEN": "The Rhine is a big river."
      },
      {
        "id": "n0631",
        "german": "das Gewitter",
        "article": "das",
        "plural": "Pl. die Gewitter",
        "english": "thunderstorm",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Heute Abend gibt es ein Gewitter .",
        "exampleEN": "There's going to be a thunderstorm this evening."
      },
      {
        "id": "n0632",
        "german": "der Grad",
        "article": "der",
        "plural": "Pl. die Grad",
        "english": "degree",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Heute sind es nur zwei Grad .",
        "exampleEN": "It's only two degrees today."
      },
      {
        "id": "n0633",
        "german": "der Himmel",
        "article": "der",
        "plural": "kein Plural",
        "english": "sky",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Der Himmel ist blau.",
        "exampleEN": "The sky is blue."
      },
      {
        "id": "n0634",
        "german": "der Hund",
        "article": "der",
        "plural": "Pl. die Hunde",
        "english": "dog",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Unser Hund heißt Max.",
        "exampleEN": "Our dog is called Max."
      },
      {
        "id": "n0635",
        "german": "die Insel",
        "article": "die",
        "plural": "Pl. die Inseln",
        "english": "island",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Rügen ist eine Insel in der Ostsee.",
        "exampleEN": "Rügen is an island in the Baltic Sea."
      },
      {
        "id": "n0636",
        "german": "die Katze",
        "article": "die",
        "plural": "Pl. die Katzen",
        "english": "cat",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Die Katze schläft auf dem Sofa.",
        "exampleEN": "The cat is sleeping on the sofa."
      },
      {
        "id": "n0637",
        "german": "das Klima",
        "article": "das",
        "plural": "kein Plural",
        "english": "climate",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Das Klima in Deutschland ist anders als in Pakistan.",
        "exampleEN": "The climate in Germany is different from Pakistan."
      },
      {
        "id": "n0638",
        "german": "die Landschaft",
        "article": "die",
        "plural": "Pl. die Landschaften",
        "english": "landscape",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Die Landschaft im Sauerland ist sehr schön.",
        "exampleEN": "The landscape in the Sauerland is very beautiful."
      },
      {
        "id": "n0639",
        "german": "die Luft",
        "article": "die",
        "plural": "kein Plural",
        "english": "air",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Hier auf dem Land ist die Luft sauber.",
        "exampleEN": "The air is clean here in the countryside."
      },
      {
        "id": "n0640",
        "german": "das Meer",
        "article": "das",
        "plural": "Pl. die Meere",
        "english": "sea",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Im Sommer fahren wir ans Meer .",
        "exampleEN": "In the summer we go to the seaside."
      },
      {
        "id": "n0641",
        "german": "die Natur",
        "article": "die",
        "plural": "kein Plural",
        "english": "nature",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Am Wochenende bin ich gern in der Natur .",
        "exampleEN": "At the weekend I like being out in nature."
      },
      {
        "id": "n0642",
        "german": "der Nebel",
        "article": "der",
        "plural": "kein Plural",
        "english": "fog",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Am Morgen war viel Nebel .",
        "exampleEN": "There was a lot of fog in the morning."
      },
      {
        "id": "n0643",
        "german": "die Pflanze",
        "article": "die",
        "plural": "Pl. die Pflanzen",
        "english": "plant",
        "level": "A2",
        "type": "noun",
        "exampleDE": "In meinem Zimmer stehen viele Pflanzen .",
        "exampleEN": "There are a lot of plants in my room."
      },
      {
        "id": "n0644",
        "german": "der Regen",
        "article": "der",
        "plural": "kein Plural",
        "english": "rain",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Bei Regen bleibe ich zu Hause.",
        "exampleEN": "When it rains I stay at home."
      },
      {
        "id": "n0645",
        "german": "der Schnee",
        "article": "der",
        "plural": "kein Plural",
        "english": "snow",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Die Kinder spielen im Schnee .",
        "exampleEN": "The children are playing in the snow."
      },
      {
        "id": "n0646",
        "german": "der See",
        "article": "der",
        "plural": "Pl. die Seen",
        "english": "lake",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Wir schwimmen im See .",
        "exampleEN": "We swim in the lake."
      },
      {
        "id": "n0647",
        "german": "die Sonne",
        "article": "die",
        "plural": "kein Plural",
        "english": "sun",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Heute scheint die Sonne .",
        "exampleEN": "The sun is shining today."
      },
      {
        "id": "n0648",
        "german": "die Temperatur",
        "article": "die",
        "plural": "Pl. die Temperaturen",
        "english": "temperature",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Die Temperatur ist heute 20 Grad.",
        "exampleEN": "The temperature today is 20 degrees."
      },
      {
        "id": "n0649",
        "german": "das Tier",
        "article": "das",
        "plural": "Pl. die Tiere",
        "english": "animal",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Hast du ein Tier zu Hause?",
        "exampleEN": "Do you have a pet at home?"
      },
      {
        "id": "n0650",
        "german": "die Umwelt",
        "article": "die",
        "plural": "kein Plural",
        "english": "environment",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Fahrradfahren ist gut für die Umwelt .",
        "exampleEN": "Cycling is good for the environment."
      },
      {
        "id": "n0651",
        "german": "der Vogel",
        "article": "der",
        "plural": "Pl. die Vögel",
        "english": "bird",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Am Morgen singen die Vögel .",
        "exampleEN": "The birds sing in the morning."
      },
      {
        "id": "n0652",
        "german": "der Wald",
        "article": "der",
        "plural": "Pl. die Wälder",
        "english": "forest",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Am Sonntag wandern wir im Wald .",
        "exampleEN": "On Sunday we go hiking in the forest."
      },
      {
        "id": "n0653",
        "german": "die Welt",
        "article": "die",
        "plural": "Pl. die Welten",
        "english": "world",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Ich möchte die Welt sehen.",
        "exampleEN": "I'd like to see the world."
      },
      {
        "id": "n0654",
        "german": "das Wetter",
        "article": "das",
        "plural": "kein Plural",
        "english": "weather",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Wie ist das Wetter heute?",
        "exampleEN": "What's the weather like today?"
      },
      {
        "id": "n0655",
        "german": "die Wettervorhersage",
        "article": "die",
        "plural": "Pl. die Wettervorhersagen",
        "english": "weather forecast",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Laut Wettervorhersage regnet es morgen.",
        "exampleEN": "According to the forecast it will rain tomorrow."
      },
      {
        "id": "n0656",
        "german": "die Wiese",
        "article": "die",
        "plural": "Pl. die Wiesen",
        "english": "meadow",
        "level": "A2",
        "type": "noun",
        "exampleDE": "Wir machen ein Picknick auf der Wiese .",
        "exampleEN": "We're having a picnic in the meadow."
      },
      {
        "id": "n0657",
        "german": "der Wind",
        "article": "der",
        "plural": "Pl. die Winde",
        "english": "wind",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Der Wind ist heute stark.",
        "exampleEN": "The wind is strong today."
      },
      {
        "id": "n0658",
        "german": "die Land Wolke",
        "article": "die Land",
        "plural": "Pl. die Wolken A1 Sprache Person (m / f)",
        "english": "cloud",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Am Himmel sind viele Wolken .",
        "exampleEN": "There are lots of clouds in the sky. 18 Länder Beispielsatz · example"
      }
    ]
  },
  {
    "id": "nomen_laender",
    "title": "Länder & Sprachen",
    "emoji": "🌍",
    "entries": [
      {
        "id": "n0659",
        "german": "Deutschland",
        "article": "",
        "plural": "Person: der Deutsche / die Deutsche",
        "english": "Germany",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ich komme aus Deutschland .",
        "exampleEN": "I'm from Germany."
      },
      {
        "id": "n0660",
        "german": "Österreich",
        "article": "",
        "plural": "Person: Österreicher / Österreicherin",
        "english": "Austria",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Wien liegt in Österreich .",
        "exampleEN": "Vienna is in Austria."
      },
      {
        "id": "n0661",
        "german": "die Schweiz",
        "article": "die",
        "plural": "Person: Schweizer / Schweizerin",
        "english": "Switzerland",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Er kommt aus der Schweiz .",
        "exampleEN": "He's from Switzerland."
      },
      {
        "id": "n0662",
        "german": "Großbritannien",
        "article": "",
        "plural": "Person: Brite / Britin",
        "english": "Great Britain",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Sie wohnt in Großbritannien .",
        "exampleEN": "She lives in Great Britain."
      },
      {
        "id": "n0663",
        "german": "die USA (Pl.)",
        "article": "die",
        "plural": "Person: Amerikaner / Amerikanerin",
        "english": "the USA",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Mein Onkel lebt in den USA .",
        "exampleEN": "My uncle lives in the USA."
      },
      {
        "id": "n0664",
        "german": "Frankreich",
        "article": "",
        "plural": "Person: Franzose / Französin",
        "english": "France",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ich fahre nach Frankreich .",
        "exampleEN": "I'm going to France."
      },
      {
        "id": "n0665",
        "german": "Spanien",
        "article": "",
        "plural": "Person: Spanier / Spanierin",
        "english": "Spain",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ana kommt aus Spanien .",
        "exampleEN": "Ana is from Spain."
      },
      {
        "id": "n0666",
        "german": "Italien",
        "article": "",
        "plural": "Person: Italiener / Italienerin",
        "english": "Italy",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Wir machen Urlaub in Italien .",
        "exampleEN": "We're on holiday in Italy."
      },
      {
        "id": "n0667",
        "german": "Polen",
        "article": "",
        "plural": "Person: Pole / Polin",
        "english": "My colleague is Polish.",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Meine Kollegin ist Polin .",
        "exampleEN": "My colleague is Polish."
      },
      {
        "id": "n0668",
        "german": "die Ukraine",
        "article": "die",
        "plural": "Person: Ukrainer / Ukrainerin",
        "english": "Ukraine",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Sie kommt aus der Ukraine .",
        "exampleEN": "She's from Ukraine."
      },
      {
        "id": "n0669",
        "german": "Russland",
        "article": "",
        "plural": "Person: Russe / Russin",
        "english": "He speaks Russian.",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Er spricht Russisch .",
        "exampleEN": "He speaks Russian."
      },
      {
        "id": "n0670",
        "german": "die Türkei",
        "article": "die",
        "plural": "Person: Türke / Türkin",
        "english": "Turkey",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Ich fliege in die Türkei .",
        "exampleEN": "I'm flying to Turkey."
      },
      {
        "id": "n0671",
        "german": "Syrien",
        "article": "",
        "plural": "Person: Syrer / Syrerin",
        "english": "Syria people speak Arabic",
        "level": "A1",
        "type": "noun",
        "exampleDE": "In Syrien spricht man Arabisch .",
        "exampleEN": "In Syria people speak Arabic."
      },
      {
        "id": "n0672",
        "german": "der Iran",
        "article": "der",
        "plural": "Person: Iraner / Iranerin",
        "english": "Iran",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Mein Nachbar kommt aus dem Iran .",
        "exampleEN": "My neighbour is from Iran."
      },
      {
        "id": "n0673",
        "german": "Indien",
        "article": "",
        "plural": "Person: Inder / Inderin",
        "english": "Raj is Indian.",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Raj ist Inder .",
        "exampleEN": "Raj is Indian."
      },
      {
        "id": "n0674",
        "german": "Pakistan",
        "article": "",
        "plural": "Person: Pakistaner / Pakistanerin",
        "english": "Pakistan people speak Urdu",
        "level": "A1",
        "type": "noun",
        "exampleDE": "In Pakistan spricht man Urdu .",
        "exampleEN": "In Pakistan people speak Urdu."
      },
      {
        "id": "n0675",
        "german": "China",
        "article": "",
        "plural": "Person: Chinese / Chinesin",
        "english": "China",
        "level": "A1",
        "type": "noun",
        "exampleDE": "Li kommt aus China .",
        "exampleEN": "Li is from China."
      },
      {
        "id": "n0676",
        "german": "Brasilien",
        "article": "",
        "plural": "Person: Brasilianer / Brasilianerin",
        "english": "Brazil",
        "level": "A1",
        "type": "noun",
        "exampleDE": "In Brasilien ist es warm.",
        "exampleEN": "It's warm in Brazil."
      }
    ]
  },
  {
    "id": "adjektive_gegenteile",
    "title": "Adjektive: Gegenteile",
    "emoji": "↔️",
    "entries": [
      {
        "id": "a0001",
        "german": "alt ↔ jung",
        "english": "old ↔ young",
        "level": "A1",
        "type": "adjective",
        "exampleDE": "Mein Opa ist alt , mein Bruder ist jung .",
        "exampleEN": "My grandpa is old, my brother is young."
      },
      {
        "id": "a0002",
        "german": "alt ↔ neu",
        "english": "old ↔ new",
        "level": "A1",
        "type": "adjective",
        "exampleDE": "Mein Handy ist alt , dein Handy ist neu .",
        "exampleEN": "My phone is old, your phone is new."
      },
      {
        "id": "a0003",
        "german": "arm ↔ reich",
        "english": "poor ↔ rich",
        "level": "A1",
        "type": "adjective",
        "exampleDE": "Er ist nicht arm , aber auch nicht reich .",
        "exampleEN": "He isn't poor, but he isn't rich either."
      },
      {
        "id": "a0004",
        "german": "breit ↔ schmal",
        "english": "wide ↔ narrow",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Die Straße ist sehr schmal .",
        "exampleEN": "The street is very narrow."
      },
      {
        "id": "a0005",
        "german": "dick ↔ dünn",
        "english": "thick, fat ↔ thin",
        "level": "A1",
        "type": "adjective",
        "exampleDE": "Das Buch ist dick , das Heft ist dünn .",
        "exampleEN": "The book is thick, the exercise book is thin."
      },
      {
        "id": "a0006",
        "german": "einfach ↔ schwierig",
        "english": "easy ↔ difficult",
        "level": "A1",
        "type": "adjective",
        "exampleDE": "Die erste Aufgabe ist einfach , die zweite ist schwierig .",
        "exampleEN": "The first task is easy, the second is difficult."
      },
      {
        "id": "a0007",
        "german": "eng ↔ weit",
        "english": "tight ↔ loose, wide",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Die Hose ist mir zu eng .",
        "exampleEN": "The trousers are too tight for me."
      },
      {
        "id": "a0008",
        "german": "fleißig ↔ faul",
        "english": "hard-working ↔ lazy",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Meine Kollegin ist sehr fleißig .",
        "exampleEN": "My colleague is very hard-working."
      },
      {
        "id": "a0009",
        "german": "frei ↔ besetzt",
        "english": "free ↔ taken, occupied",
        "level": "A1",
        "type": "adjective",
        "exampleDE": "Ist der Platz frei ? Nein, er ist besetzt .",
        "exampleEN": "Is this seat free? No, it's taken."
      },
      {
        "id": "a0010",
        "german": "freundlich ↔ unfreundlich",
        "english": "friendly ↔ unfriendly",
        "level": "A1",
        "type": "adjective",
        "exampleDE": "Die Verkäuferin ist freundlich , der Kellner ist unfreundlich .",
        "exampleEN": "The shop assistant is friendly, the waiter is unfriendly."
      },
      {
        "id": "a0011",
        "german": "früh ↔ spät",
        "english": "early ↔ late",
        "level": "A1",
        "type": "adjective",
        "exampleDE": "Ich stehe früh auf und gehe spät ins Bett.",
        "exampleEN": "I get up early and go to bed late."
      },
      {
        "id": "a0012",
        "german": "gefährlich ↔ sicher",
        "english": "dangerous ↔ safe",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Die Gegend ist auch nachts sicher .",
        "exampleEN": "The area is safe even at night."
      },
      {
        "id": "a0013",
        "german": "geöffnet ↔ geschlossen",
        "english": "open ↔ closed",
        "level": "A1",
        "type": "adjective",
        "exampleDE": "Die Bank ist am Montag geöffnet und am Sonntag geschlossen .",
        "exampleEN": "The bank is open on Monday and closed on Sunday."
      },
      {
        "id": "a0014",
        "german": "gesund ↔ krank",
        "english": "healthy, well ↔ ill",
        "level": "A1",
        "type": "adjective",
        "exampleDE": "Gestern war ich krank , heute bin ich wieder gesund .",
        "exampleEN": "Yesterday I was ill, today I'm well again."
      },
      {
        "id": "a0015",
        "german": "glücklich ↔ traurig",
        "english": "happy ↔ sad",
        "level": "A1",
        "type": "adjective",
        "exampleDE": "Sie ist glücklich , aber er ist traurig .",
        "exampleEN": "She is happy, but he is sad."
      },
      {
        "id": "a0016",
        "german": "groß ↔ klein",
        "english": "big, tall ↔ small, short",
        "level": "A1",
        "type": "adjective",
        "exampleDE": "Das Haus ist groß , aber die Küche ist klein .",
        "exampleEN": "The house is big, but the kitchen is small."
      },
      {
        "id": "a0017",
        "german": "gültig ↔ ungültig",
        "english": "valid ↔ invalid",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Mein Pass ist noch zwei Jahre gültig .",
        "exampleEN": "My passport is valid for two more years."
      },
      {
        "id": "a0018",
        "german": "gut ↔ schlecht",
        "english": "good ↔ bad",
        "level": "A1",
        "type": "adjective",
        "exampleDE": "Heute ist das Wetter gut , gestern war es schlecht .",
        "exampleEN": "Today the weather is good, yesterday it was bad."
      },
      {
        "id": "a0019",
        "german": "hart ↔ weich",
        "english": "hard ↔ soft",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Das Bett ist zu hart .",
        "exampleEN": "The bed is too hard."
      },
      {
        "id": "a0020",
        "german": "hell ↔ dunkel",
        "english": "bright, light ↔ dark",
        "level": "A1",
        "type": "adjective",
        "exampleDE": "Das Wohnzimmer ist hell , das Bad ist dunkel .",
        "exampleEN": "The living room is bright, the bathroom is dark."
      },
      {
        "id": "a0021",
        "german": "hoch ↔ tief",
        "english": "high ↔ deep, low",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Der Berg ist sehr hoch .",
        "exampleEN": "The mountain is very high."
      },
      {
        "id": "a0022",
        "german": "höflich ↔ unhöflich",
        "english": "polite ↔ rude",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Der Kellner war sehr höflich .",
        "exampleEN": "The waiter was very polite."
      },
      {
        "id": "a0023",
        "german": "hungrig ↔ satt",
        "english": "hungry ↔ full",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Danke, ich bin schon satt .",
        "exampleEN": "Thank you, I'm already full."
      },
      {
        "id": "a0024",
        "german": "interessant ↔ langweilig",
        "english": "interesting ↔ boring",
        "level": "A1",
        "type": "adjective",
        "exampleDE": "Das Buch ist interessant , der Film ist langweilig .",
        "exampleEN": "The book is interesting, the film is boring."
      },
      {
        "id": "a0025",
        "german": "klug ↔ dumm",
        "english": "clever ↔ stupid",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Das war keine kluge Idee.",
        "exampleEN": "That wasn't a clever idea."
      },
      {
        "id": "a0026",
        "german": "lang ↔ kurz",
        "english": "long ↔ short",
        "level": "A1",
        "type": "adjective",
        "exampleDE": "Der Rock ist zu lang , die Hose ist zu kurz .",
        "exampleEN": "The skirt is too long, the trousers are too short."
      },
      {
        "id": "a0027",
        "german": "laut ↔ leise",
        "english": "loud ↔ quiet",
        "level": "A1",
        "type": "adjective",
        "exampleDE": "Die Musik ist zu laut . Bitte mach sie leiser !",
        "exampleEN": "The music is too loud. Please turn it down!"
      },
      {
        "id": "a0028",
        "german": "lebendig ↔ tot",
        "english": "alive ↔ dead",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Der Vogel ist tot .",
        "exampleEN": "The bird is dead."
      },
      {
        "id": "a0029",
        "german": "ledig ↔ verheiratet",
        "english": "single ↔ married",
        "level": "A1",
        "type": "adjective",
        "exampleDE": "Mein Bruder ist ledig , meine Schwester ist verheiratet .",
        "exampleEN": "My brother is single, my sister is married."
      },
      {
        "id": "a0030",
        "german": "leicht ↔ schwer",
        "english": "light; easy ↔ heavy; difficult",
        "level": "A1",
        "type": "adjective",
        "exampleDE": "Die Tasche ist leicht , aber der Koffer ist schwer .",
        "exampleEN": "The bag is light, but the suitcase is heavy."
      },
      {
        "id": "a0031",
        "german": "männlich ↔ weiblich",
        "english": "male ↔ female",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Kreuzen Sie an: männlich oder weiblich .",
        "exampleEN": "Tick: male or female."
      },
      {
        "id": "a0032",
        "german": "müde ↔ wach",
        "english": "tired ↔ awake",
        "level": "A1",
        "type": "adjective",
        "exampleDE": "Ich bin müde , aber das Baby ist noch wach .",
        "exampleEN": "I'm tired, but the baby is still awake."
      },
      {
        "id": "a0033",
        "german": "nah ↔ weit",
        "english": "near ↔ far",
        "level": "A1",
        "type": "adjective",
        "exampleDE": "Der Supermarkt ist nah , der Bahnhof ist weit .",
        "exampleEN": "The supermarket is near, the station is far."
      },
      {
        "id": "a0034",
        "german": "nass ↔ trocken",
        "english": "wet ↔ dry",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Die Wäsche ist noch nass .",
        "exampleEN": "The laundry is still wet."
      },
      {
        "id": "a0035",
        "german": "offen ↔ zu",
        "english": "open ↔ closed",
        "level": "A1",
        "type": "adjective",
        "exampleDE": "Die Tür ist offen , das Fenster ist zu .",
        "exampleEN": "The door is open, the window is closed."
      },
      {
        "id": "a0036",
        "german": "öffentlich ↔ privat",
        "english": "public ↔ private",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Ich fahre mit öffentlichen Verkehrsmitteln.",
        "exampleEN": "I travel by public transport."
      },
      {
        "id": "a0037",
        "german": "richtig ↔ falsch",
        "english": "right, correct ↔ wrong",
        "level": "A1",
        "type": "adjective",
        "exampleDE": "Ist die Antwort richtig oder falsch ?",
        "exampleEN": "Is the answer right or wrong?"
      },
      {
        "id": "a0038",
        "german": "sauber ↔ schmutzig",
        "english": "clean ↔ dirty",
        "level": "A1",
        "type": "adjective",
        "exampleDE": "Die Küche ist sauber , aber das Bad ist schmutzig .",
        "exampleEN": "The kitchen is clean, but the bathroom is dirty."
      },
      {
        "id": "a0039",
        "german": "schnell ↔ langsam",
        "english": "fast ↔ slow",
        "level": "A1",
        "type": "adjective",
        "exampleDE": "Der Zug ist schnell , der Bus ist langsam .",
        "exampleEN": "The train is fast, the bus is slow."
      },
      {
        "id": "a0040",
        "german": "schön ↔ hässlich",
        "english": "beautiful ↔ ugly",
        "level": "A1",
        "type": "adjective",
        "exampleDE": "Das Kleid ist schön , aber die Schuhe sind hässlich .",
        "exampleEN": "The dress is pretty, but the shoes are ugly."
      },
      {
        "id": "a0041",
        "german": "stark ↔ schwach",
        "english": "strong ↔ weak",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Der Kaffee ist mir zu stark .",
        "exampleEN": "The coffee is too strong for me."
      },
      {
        "id": "a0042",
        "german": "teuer ↔ billig",
        "english": "expensive ↔ cheap",
        "level": "A1",
        "type": "adjective",
        "exampleDE": "Das Restaurant ist teuer , die Pizzeria ist billig .",
        "exampleEN": "The restaurant is expensive, the pizzeria is cheap."
      },
      {
        "id": "a0043",
        "german": "viel ↔ wenig",
        "english": "a lot, much ↔ little, not much",
        "level": "A1",
        "type": "adjective",
        "exampleDE": "Ich habe viel Arbeit und wenig Zeit.",
        "exampleEN": "I have a lot of work and little time."
      },
      {
        "id": "a0044",
        "german": "voll ↔ leer",
        "english": "full ↔ empty",
        "level": "A1",
        "type": "adjective",
        "exampleDE": "Der Bus ist voll , der Zug ist leer .",
        "exampleEN": "The bus is full, the train is empty."
      },
      {
        "id": "a0045",
        "german": "warm ↔ kalt",
        "english": "warm ↔ cold",
        "level": "A1",
        "type": "adjective",
        "exampleDE": "Im Sommer ist es warm , im Winter ist es kalt . 19 Einträge",
        "exampleEN": "It's warm in summer and cold in winter."
      },
      {
        "id": "a0046",
        "german": "zufrieden ↔ unzufrieden Adjektiv",
        "english": "satisfied ↔ dissatisfied English",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Bist du mit deiner Wohnung zufrieden ?",
        "exampleEN": "Are you happy with your flat? 98 Adjektive Beispielsatz · example"
      }
    ]
  },
  {
    "id": "adjektive_weitere",
    "title": "Weitere Adjektive",
    "emoji": "✨",
    "entries": [
      {
        "id": "a0047",
        "german": "ähnlich",
        "english": "similar",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Die zwei Brüder sehen sich sehr ähnlich .",
        "exampleEN": "The two brothers look very similar."
      },
      {
        "id": "a0048",
        "german": "aktiv",
        "english": "active",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Meine Oma ist noch sehr aktiv .",
        "exampleEN": "My grandma is still very active."
      },
      {
        "id": "a0049",
        "german": "aktuell",
        "english": "current",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Hier sind die aktuellen Nachrichten.",
        "exampleEN": "Here's the latest news."
      },
      {
        "id": "a0050",
        "german": "ander-",
        "english": "other, different",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Ich möchte eine andere Farbe.",
        "exampleEN": "I'd like a different colour."
      },
      {
        "id": "a0051",
        "german": "anstrengend",
        "english": "tiring, exhausting",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Die Arbeit war heute sehr anstrengend .",
        "exampleEN": "Work was very tiring today."
      },
      {
        "id": "a0052",
        "german": "arbeitslos",
        "english": "unemployed",
        "level": "A1",
        "type": "adjective",
        "exampleDE": "Mein Nachbar ist seit einem Jahr arbeitslos .",
        "exampleEN": "My neighbour has been unemployed for a year."
      },
      {
        "id": "a0053",
        "german": "aufgeregt",
        "english": "excited, nervous",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Vor der Prüfung bin ich immer aufgeregt .",
        "exampleEN": "I'm always nervous before the exam."
      },
      {
        "id": "a0054",
        "german": "aufregend",
        "english": "exciting",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Der erste Tag in Deutschland war sehr aufregend .",
        "exampleEN": "The first day in Germany was very exciting."
      },
      {
        "id": "a0055",
        "german": "bekannt",
        "english": "well-known, famous",
        "level": "A1",
        "type": "adjective",
        "exampleDE": "Der Kölner Dom ist sehr bekannt .",
        "exampleEN": "Cologne Cathedral is very famous."
      },
      {
        "id": "a0056",
        "german": "beliebt",
        "english": "popular",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Dieses Restaurant ist sehr beliebt .",
        "exampleEN": "This restaurant is very popular."
      },
      {
        "id": "a0057",
        "german": "bequem",
        "english": "comfortable",
        "level": "A1",
        "type": "adjective",
        "exampleDE": "Das Sofa ist sehr bequem .",
        "exampleEN": "The sofa is very comfortable."
      },
      {
        "id": "a0058",
        "german": "berühmt",
        "english": "famous",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Der Kölner Dom ist sehr berühmt .",
        "exampleEN": "Cologne Cathedral is very famous."
      },
      {
        "id": "a0059",
        "german": "bewölkt",
        "english": "cloudy",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Heute ist es bewölkt .",
        "exampleEN": "It's cloudy today."
      },
      {
        "id": "a0060",
        "german": "bitter",
        "english": "bitter",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Der Kaffee ist sehr bitter .",
        "exampleEN": "The coffee is very bitter."
      },
      {
        "id": "a0061",
        "german": "blöd",
        "english": "stupid, annoying",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "So ein blöder Tag!",
        "exampleEN": "What a stupid day!"
      },
      {
        "id": "a0062",
        "german": "blond",
        "english": "blond",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Sie hat blonde Haare.",
        "exampleEN": "She has blond hair."
      },
      {
        "id": "a0063",
        "german": "böse",
        "english": "angry; bad",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Bist du böse auf mich?",
        "exampleEN": "Are you angry with me?"
      },
      {
        "id": "a0064",
        "german": "deutlich",
        "english": "clear(ly)",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Bitte sprechen Sie deutlich .",
        "exampleEN": "Please speak clearly."
      },
      {
        "id": "a0065",
        "german": "direkt",
        "english": "direct(ly)",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Der Zug fährt direkt nach München.",
        "exampleEN": "The train goes direct to Munich."
      },
      {
        "id": "a0066",
        "german": "dringend",
        "english": "urgent",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Ich brauche dringend einen Termin.",
        "exampleEN": "I urgently need an appointment."
      },
      {
        "id": "a0067",
        "german": "durstig",
        "english": "thirsty",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Nach dem Sport bin ich sehr durstig .",
        "exampleEN": "I'm very thirsty after sport."
      },
      {
        "id": "a0068",
        "german": "echt",
        "english": "real; really",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Das ist echt lecker!",
        "exampleEN": "That's really tasty!"
      },
      {
        "id": "a0069",
        "german": "egal",
        "english": "doesn't matter",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Das ist mir egal .",
        "exampleEN": "I don't mind."
      },
      {
        "id": "a0070",
        "german": "ehrlich",
        "english": "honest",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Sag mir bitte ehrlich deine Meinung.",
        "exampleEN": "Please tell me your honest opinion."
      },
      {
        "id": "a0071",
        "german": "eigen",
        "english": "own",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Ich möchte eine eigene Wohnung.",
        "exampleEN": "I'd like my own flat."
      },
      {
        "id": "a0072",
        "german": "eilig",
        "english": "urgent; in a hurry",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Ich habe es eilig .",
        "exampleEN": "I'm in a hurry."
      },
      {
        "id": "a0073",
        "german": "einverstanden",
        "english": "agreed",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Bist du einverstanden ?",
        "exampleEN": "Do you agree?"
      },
      {
        "id": "a0074",
        "german": "erfolgreich",
        "english": "successful",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Das Projekt war sehr erfolgreich .",
        "exampleEN": "The project was very successful."
      },
      {
        "id": "a0075",
        "german": "erkältet",
        "english": "having a cold",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Ich bin erkältet und bleibe zu Hause.",
        "exampleEN": "I have a cold and am staying at home."
      },
      {
        "id": "a0076",
        "german": "fantastisch",
        "english": "fantastic",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Das Konzert war fantastisch !",
        "exampleEN": "The concert was fantastic!"
      },
      {
        "id": "a0077",
        "german": "fertig",
        "english": "finished, ready",
        "level": "A1",
        "type": "adjective",
        "exampleDE": "Das Essen ist fertig !",
        "exampleEN": "The food is ready!"
      },
      {
        "id": "a0078",
        "german": "fett",
        "english": "fatty",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Das Essen ist zu fett .",
        "exampleEN": "The food is too fatty."
      },
      {
        "id": "a0079",
        "german": "fit",
        "english": "fit",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Ich möchte wieder fit werden.",
        "exampleEN": "I want to get fit again."
      },
      {
        "id": "a0080",
        "german": "freiwillig",
        "english": "voluntary",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Die Teilnahme ist freiwillig .",
        "exampleEN": "Taking part is voluntary."
      },
      {
        "id": "a0081",
        "german": "fremd",
        "english": "foreign; strange",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Am Anfang war alles fremd für mich.",
        "exampleEN": "At the beginning everything was strange to me."
      },
      {
        "id": "a0082",
        "german": "frisch",
        "english": "fresh",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Das Brot ist ganz frisch .",
        "exampleEN": "The bread is very fresh."
      },
      {
        "id": "a0083",
        "german": "froh",
        "english": "glad",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Ich bin froh , dass du da bist.",
        "exampleEN": "I'm glad you're here."
      },
      {
        "id": "a0084",
        "german": "furchtbar",
        "english": "terrible",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Das Wetter ist furchtbar .",
        "exampleEN": "The weather is terrible."
      },
      {
        "id": "a0085",
        "german": "geboren",
        "english": "born",
        "level": "A1",
        "type": "adjective",
        "exampleDE": "Ich bin 1995 in Wien geboren .",
        "exampleEN": "I was born in Vienna in 1995."
      },
      {
        "id": "a0086",
        "german": "gemütlich",
        "english": "cosy",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Eure Wohnung ist sehr gemütlich .",
        "exampleEN": "Your flat is very cosy."
      },
      {
        "id": "a0087",
        "german": "geschieden",
        "english": "divorced",
        "level": "A1",
        "type": "adjective",
        "exampleDE": "Meine Eltern sind geschieden .",
        "exampleEN": "My parents are divorced."
      },
      {
        "id": "a0088",
        "german": "gestresst",
        "english": "stressed",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Vor Weihnachten sind alle gestresst .",
        "exampleEN": "Everyone is stressed before Christmas."
      },
      {
        "id": "a0089",
        "german": "gleich",
        "english": "same",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Wir haben das gleiche Handy.",
        "exampleEN": "We have the same phone."
      },
      {
        "id": "a0090",
        "german": "günstig",
        "english": "cheap, good value",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Im Internet ist der Fernseher günstiger .",
        "exampleEN": "The TV is cheaper online."
      },
      {
        "id": "a0091",
        "german": "heiß",
        "english": "hot",
        "level": "A1",
        "type": "adjective",
        "exampleDE": "Der Kaffee ist sehr heiß .",
        "exampleEN": "The coffee is very hot."
      },
      {
        "id": "a0092",
        "german": "herzlich",
        "english": "warm, cordial",
        "level": "A1",
        "type": "adjective",
        "exampleDE": "Herzlichen Glückwunsch zum Geburtstag!",
        "exampleEN": "Happy birthday!"
      },
      {
        "id": "a0093",
        "german": "hübsch",
        "english": "pretty",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Das Kleid ist sehr hübsch .",
        "exampleEN": "The dress is very pretty."
      },
      {
        "id": "a0094",
        "german": "intelligent",
        "english": "intelligent",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Sie ist sehr intelligent .",
        "exampleEN": "She's very intelligent."
      },
      {
        "id": "a0095",
        "german": "international",
        "english": "international",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Unser Team ist sehr international .",
        "exampleEN": "Our team is very international."
      },
      {
        "id": "a0096",
        "german": "kaputt",
        "english": "broken",
        "level": "A1",
        "type": "adjective",
        "exampleDE": "Mein Fahrrad ist kaputt .",
        "exampleEN": "My bike is broken."
      },
      {
        "id": "a0097",
        "german": "klar",
        "english": "clear; sure",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Ist alles klar ? Ja, klar !",
        "exampleEN": "Is everything clear? Yes, sure!"
      },
      {
        "id": "a0098",
        "german": "kompliziert",
        "english": "complicated",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Das Formular ist sehr kompliziert .",
        "exampleEN": "The form is very complicated."
      },
      {
        "id": "a0099",
        "german": "kostenlos",
        "english": "free (of charge)",
        "level": "A1",
        "type": "adjective",
        "exampleDE": "Der Eintritt ist kostenlos .",
        "exampleEN": "Admission is free."
      },
      {
        "id": "a0100",
        "german": "kühl",
        "english": "cool",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Heute ist es kühl , nimm eine Jacke mit.",
        "exampleEN": "It's cool today, take a jacket."
      },
      {
        "id": "a0101",
        "german": "lecker",
        "english": "tasty, delicious",
        "level": "A1",
        "type": "adjective",
        "exampleDE": "Die Suppe ist sehr lecker .",
        "exampleEN": "The soup is very tasty."
      },
      {
        "id": "a0102",
        "german": "letzt-",
        "english": "last",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Letzte Woche war ich krank.",
        "exampleEN": "I was ill last week."
      },
      {
        "id": "a0103",
        "german": "lustig",
        "english": "funny",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Der Film war sehr lustig .",
        "exampleEN": "The film was very funny."
      },
      {
        "id": "a0104",
        "german": "modern",
        "english": "modern",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Die Küche ist ganz modern .",
        "exampleEN": "The kitchen is very modern."
      },
      {
        "id": "a0105",
        "german": "möglich",
        "english": "possible",
        "level": "A1",
        "type": "adjective",
        "exampleDE": "Ist ein Termin am Montag möglich ?",
        "exampleEN": "Is an appointment on Monday possible?"
      },
      {
        "id": "a0106",
        "german": "nächst-",
        "english": "next",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Nächste Woche habe ich Urlaub.",
        "exampleEN": "I'm on holiday next week."
      },
      {
        "id": "a0107",
        "german": "neblig",
        "english": "foggy",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Am Morgen ist es oft neblig .",
        "exampleEN": "It's often foggy in the morning."
      },
      {
        "id": "a0108",
        "german": "nervös",
        "english": "nervous",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Vor dem Gespräch war ich sehr nervös .",
        "exampleEN": "I was very nervous before the interview."
      },
      {
        "id": "a0109",
        "german": "nett",
        "english": "nice, kind",
        "level": "A1",
        "type": "adjective",
        "exampleDE": "Deine Freunde sind sehr nett .",
        "exampleEN": "Your friends are very nice."
      },
      {
        "id": "a0110",
        "german": "neugierig",
        "english": "curious",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Kinder sind sehr neugierig .",
        "exampleEN": "Children are very curious."
      },
      {
        "id": "a0111",
        "german": "normal",
        "english": "normal",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Das ist in Deutschland ganz normal .",
        "exampleEN": "That's quite normal in Germany."
      },
      {
        "id": "a0112",
        "german": "notwendig",
        "english": "necessary",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Ist das wirklich notwendig ?",
        "exampleEN": "Is that really necessary?"
      },
      {
        "id": "a0113",
        "german": "nützlich",
        "english": "useful",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Die App ist sehr nützlich .",
        "exampleEN": "The app is very useful."
      },
      {
        "id": "a0114",
        "german": "online",
        "english": "online",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Ich kaufe viel online .",
        "exampleEN": "I buy a lot online."
      },
      {
        "id": "a0115",
        "german": "persönlich",
        "english": "personal; in person",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Ich möchte persönlich mit Ihnen sprechen.",
        "exampleEN": "I'd like to speak to you in person."
      },
      {
        "id": "a0116",
        "german": "praktisch",
        "english": "practical",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Die Tasche ist sehr praktisch .",
        "exampleEN": "The bag is very practical."
      },
      {
        "id": "a0117",
        "german": "pünktlich",
        "english": "on time, punctual",
        "level": "A1",
        "type": "adjective",
        "exampleDE": "Der Zug ist heute pünktlich .",
        "exampleEN": "The train is on time today."
      },
      {
        "id": "a0118",
        "german": "regelmäßig",
        "english": "regular(ly)",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Ich mache regelmäßig Sport.",
        "exampleEN": "I do sport regularly."
      },
      {
        "id": "a0119",
        "german": "ruhig",
        "english": "quiet, calm",
        "level": "A1",
        "type": "adjective",
        "exampleDE": "Wir wohnen in einer ruhigen Straße.",
        "exampleEN": "We live on a quiet street."
      },
      {
        "id": "a0120",
        "german": "rund",
        "english": "round",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Unser Tisch ist rund .",
        "exampleEN": "Our table is round."
      },
      {
        "id": "a0121",
        "german": "salzig",
        "english": "salty",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Die Suppe ist zu salzig .",
        "exampleEN": "The soup is too salty."
      },
      {
        "id": "a0122",
        "german": "sauer",
        "english": "sour; annoyed",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Mein Chef ist heute sauer .",
        "exampleEN": "My boss is annoyed today."
      },
      {
        "id": "a0123",
        "german": "schade",
        "english": "a pity",
        "level": "A1",
        "type": "adjective",
        "exampleDE": "Du kannst nicht kommen? Das ist schade !",
        "exampleEN": "You can't come? That's a pity!"
      },
      {
        "id": "a0124",
        "german": "scharf",
        "english": "spicy; sharp",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Das Essen ist mir zu scharf .",
        "exampleEN": "The food is too spicy for me."
      },
      {
        "id": "a0125",
        "german": "selbstständig",
        "english": "self-employed; independent",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Er ist selbstständig und hat eine eigene Firma.",
        "exampleEN": "He's self-employed and has his own company."
      },
      {
        "id": "a0126",
        "german": "sonnig",
        "english": "sunny",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Morgen wird es sonnig .",
        "exampleEN": "It's going to be sunny tomorrow."
      },
      {
        "id": "a0127",
        "german": "spannend",
        "english": "exciting",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Das Buch ist sehr spannend .",
        "exampleEN": "The book is very exciting."
      },
      {
        "id": "a0128",
        "german": "sportlich",
        "english": "sporty",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Mein Bruder ist sehr sportlich .",
        "exampleEN": "My brother is very sporty."
      },
      {
        "id": "a0129",
        "german": "still",
        "english": "quiet, still",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Sei bitte still !",
        "exampleEN": "Please be quiet!"
      },
      {
        "id": "a0130",
        "german": "stolz",
        "english": "proud",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Meine Eltern sind stolz auf mich.",
        "exampleEN": "My parents are proud of me."
      },
      {
        "id": "a0131",
        "german": "streng",
        "english": "strict",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Unser Lehrer ist ziemlich streng .",
        "exampleEN": "Our teacher is quite strict."
      },
      {
        "id": "a0132",
        "german": "süß",
        "english": "sweet; cute",
        "level": "A1",
        "type": "adjective",
        "exampleDE": "Der Kuchen ist sehr süß .",
        "exampleEN": "The cake is very sweet."
      },
      {
        "id": "a0133",
        "german": "sympathisch",
        "english": "likeable, nice",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Die neue Kollegin ist sehr sympathisch .",
        "exampleEN": "The new colleague is very likeable."
      },
      {
        "id": "a0134",
        "german": "täglich",
        "english": "daily",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Ich trinke täglich zwei Liter Wasser.",
        "exampleEN": "I drink two litres of water every day."
      },
      {
        "id": "a0135",
        "german": "toll",
        "english": "great",
        "level": "A1",
        "type": "adjective",
        "exampleDE": "Die Party war toll !",
        "exampleEN": "The party was great!"
      },
      {
        "id": "a0136",
        "german": "typisch",
        "english": "typical",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Was ist typisch deutsch?",
        "exampleEN": "What's typically German?"
      },
      {
        "id": "a0137",
        "german": "verboten",
        "english": "forbidden",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Parken ist hier verboten .",
        "exampleEN": "Parking is forbidden here."
      },
      {
        "id": "a0138",
        "german": "verletzt",
        "english": "injured",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Bei dem Unfall war niemand verletzt .",
        "exampleEN": "Nobody was injured in the accident."
      },
      {
        "id": "a0139",
        "german": "verliebt",
        "english": "in love",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Sie ist verliebt .",
        "exampleEN": "She's in love."
      },
      {
        "id": "a0140",
        "german": "verrückt",
        "english": "crazy",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Das ist ja verrückt !",
        "exampleEN": "That's crazy!"
      },
      {
        "id": "a0141",
        "german": "verschieden",
        "english": "different",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Die Preise sind sehr verschieden .",
        "exampleEN": "The prices are very different."
      },
      {
        "id": "a0142",
        "german": "wahr",
        "english": "true",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "Das ist nicht wahr !",
        "exampleEN": "That's not true!"
      },
      {
        "id": "a0143",
        "german": "wichtig",
        "english": "important",
        "level": "A1",
        "type": "adjective",
        "exampleDE": "Der Termin ist sehr wichtig . 12 Einträge",
        "exampleEN": "The appointment is very important."
      },
      {
        "id": "a0144",
        "german": "windig Farbe",
        "english": "windy English",
        "level": "A2",
        "type": "adjective",
        "exampleDE": "An der Nordsee ist es oft windig .",
        "exampleEN": "It's often windy on the North Sea coast. 12 Farben Beispielsatz · example"
      }
    ]
  },
  {
    "id": "adjektive_farben",
    "title": "Farben",
    "emoji": "🎨",
    "entries": [
      {
        "id": "a0145",
        "german": "blau",
        "english": "blue",
        "level": "A1",
        "type": "adjective",
        "exampleDE": "Der Himmel ist blau .",
        "exampleEN": "The sky is blue."
      },
      {
        "id": "a0146",
        "german": "braun",
        "english": "brown",
        "level": "A1",
        "type": "adjective",
        "exampleDE": "Mein Hund ist braun .",
        "exampleEN": "My dog is brown."
      },
      {
        "id": "a0147",
        "german": "bunt",
        "english": "colourful",
        "level": "A1",
        "type": "adjective",
        "exampleDE": "Die Blumen sind bunt .",
        "exampleEN": "The flowers are colourful."
      },
      {
        "id": "a0148",
        "german": "gelb",
        "english": "yellow",
        "level": "A1",
        "type": "adjective",
        "exampleDE": "Die Banane ist gelb .",
        "exampleEN": "The banana is yellow."
      },
      {
        "id": "a0149",
        "german": "grau",
        "english": "grey",
        "level": "A1",
        "type": "adjective",
        "exampleDE": "Im Winter ist der Himmel oft grau .",
        "exampleEN": "In winter the sky is often grey."
      },
      {
        "id": "a0150",
        "german": "grün",
        "english": "green",
        "level": "A1",
        "type": "adjective",
        "exampleDE": "Im Frühling ist alles grün .",
        "exampleEN": "In spring everything is green."
      },
      {
        "id": "a0151",
        "german": "lila",
        "english": "purple",
        "level": "A1",
        "type": "adjective",
        "exampleDE": "Sie trägt ein lila Kleid.",
        "exampleEN": "She's wearing a purple dress."
      },
      {
        "id": "a0152",
        "german": "orange",
        "english": "orange",
        "level": "A1",
        "type": "adjective",
        "exampleDE": "Die Orange ist orange .",
        "exampleEN": "The orange is orange."
      },
      {
        "id": "a0153",
        "german": "rosa",
        "english": "pink",
        "level": "A1",
        "type": "adjective",
        "exampleDE": "Das Baby hat eine rosa Jacke.",
        "exampleEN": "The baby has a pink jacket."
      },
      {
        "id": "a0154",
        "german": "rot",
        "english": "red",
        "level": "A1",
        "type": "adjective",
        "exampleDE": "Die Tomaten sind rot .",
        "exampleEN": "The tomatoes are red."
      },
      {
        "id": "a0155",
        "german": "schwarz",
        "english": "black",
        "level": "A1",
        "type": "adjective",
        "exampleDE": "Ich trinke den Kaffee schwarz .",
        "exampleEN": "I drink my coffee black."
      },
      {
        "id": "a0156",
        "german": "weiß",
        "english": "white",
        "level": "A1",
        "type": "adjective",
        "exampleDE": "Im Winter ist alles weiß .",
        "exampleEN": "In winter everything is white."
      }
    ]
  },
  {
    "id": "adverbien",
    "title": "Adverbien & kleine Wörter",
    "emoji": "💬",
    "entries": [
      {
        "id": "adv0001",
        "german": "ab und zu",
        "english": "now and then",
        "level": "A2",
        "type": "adverb",
        "exampleDE": "Ab und zu gehe ich ins Kino.",
        "exampleEN": "Now and then I go to the cinema."
      },
      {
        "id": "adv0002",
        "german": "abends",
        "english": "in the evening(s)",
        "level": "A1",
        "type": "adverb",
        "exampleDE": "Abends sehe ich fern.",
        "exampleEN": "In the evenings I watch TV."
      },
      {
        "id": "adv0003",
        "german": "alle / alles",
        "english": "all, everyone / everything",
        "level": "A2",
        "type": "adverb",
        "exampleDE": "Alle sind da. Alles ist gut.",
        "exampleEN": "Everyone is here. Everything is fine."
      },
      {
        "id": "adv0004",
        "german": "allein",
        "english": "alone",
        "level": "A1",
        "type": "adverb",
        "exampleDE": "Ich wohne allein .",
        "exampleEN": "I live alone."
      },
      {
        "id": "adv0005",
        "german": "am liebsten",
        "english": "most of all (gern → lieber → am liebsten)",
        "level": "A2",
        "type": "adverb",
        "exampleDE": "Am liebsten esse ich Biryani.",
        "exampleEN": "Most of all I like eating biryani."
      },
      {
        "id": "adv0006",
        "german": "anders",
        "english": "differently",
        "level": "A2",
        "type": "adverb",
        "exampleDE": "Bei uns macht man das anders .",
        "exampleEN": "We do that differently at home."
      },
      {
        "id": "adv0007",
        "german": "auch",
        "english": "also, too",
        "level": "A1",
        "type": "adverb",
        "exampleDE": "Ich komme auch aus Polen.",
        "exampleEN": "I'm from Poland too."
      },
      {
        "id": "adv0008",
        "german": "auf jeden Fall ↔ auf keinen Fall",
        "english": "definitely ↔ definitely not",
        "level": "A2",
        "type": "adverb",
        "exampleDE": "Ich komme auf jeden Fall .",
        "exampleEN": "I'm definitely coming."
      },
      {
        "id": "adv0009",
        "german": "bald",
        "english": "soon",
        "level": "A1",
        "type": "adverb",
        "exampleDE": "Bis bald !",
        "exampleEN": "See you soon!"
      },
      {
        "id": "adv0010",
        "german": "bar",
        "english": "(in) cash",
        "level": "A1",
        "type": "adverb",
        "exampleDE": "Ich zahle bar . 11 Wörter",
        "exampleEN": "I'll pay cash."
      },
      {
        "id": "adv0011",
        "german": "beide",
        "english": "both",
        "level": "A2",
        "type": "adverb",
        "exampleDE": "Beide Kinder gehen zur Schule.",
        "exampleEN": "Both children go to school."
      },
      {
        "id": "adv0012",
        "german": "besonders",
        "english": "especially",
        "level": "A2",
        "type": "adverb",
        "exampleDE": "Ich mag Obst, besonders Mangos.",
        "exampleEN": "I like fruit, especially mangos."
      },
      {
        "id": "adv0013",
        "german": "bestimmt",
        "english": "certainly, surely",
        "level": "A2",
        "type": "adverb",
        "exampleDE": "Das klappt bestimmt .",
        "exampleEN": "That will surely work out."
      },
      {
        "id": "adv0014",
        "german": "bitte",
        "english": "please; here you are",
        "level": "A1",
        "type": "adverb",
        "exampleDE": "Ein Wasser, bitte .",
        "exampleEN": "A water, please."
      },
      {
        "id": "adv0015",
        "german": "da",
        "english": "there; here",
        "level": "A1",
        "type": "adverb",
        "exampleDE": "Ist Herr Weber da ?",
        "exampleEN": "Is Mr Weber there?"
      },
      {
        "id": "adv0016",
        "german": "dabei",
        "english": "with you; there",
        "level": "A2",
        "type": "adverb",
        "exampleDE": "Hast du deinen Ausweis dabei ?",
        "exampleEN": "Do you have your ID with you?"
      },
      {
        "id": "adv0017",
        "german": "damals",
        "english": "back then",
        "level": "A2",
        "type": "adverb",
        "exampleDE": "Damals war ich noch Student.",
        "exampleEN": "Back then I was still a student."
      },
      {
        "id": "adv0018",
        "german": "danach",
        "english": "after that, afterwards",
        "level": "A1",
        "type": "adverb",
        "exampleDE": "Danach gehen wir spazieren.",
        "exampleEN": "After that we go for a walk."
      },
      {
        "id": "adv0019",
        "german": "danke",
        "english": "thank you",
        "level": "A1",
        "type": "adverb",
        "exampleDE": "Danke für das Geschenk!",
        "exampleEN": "Thank you for the present!"
      },
      {
        "id": "adv0020",
        "german": "dann",
        "english": "then",
        "level": "A1",
        "type": "adverb",
        "exampleDE": "Ich koche und dann essen wir.",
        "exampleEN": "I cook and then we eat."
      },
      {
        "id": "adv0021",
        "german": "doch",
        "english": "yes (after a negative question)",
        "level": "A1",
        "type": "adverb",
        "exampleDE": "Kommst du nicht? Doch , ich komme!",
        "exampleEN": "Aren't you coming? Yes, I am!"
      },
      {
        "id": "adv0022",
        "german": "dort",
        "english": "there",
        "level": "A1",
        "type": "adverb",
        "exampleDE": "Dort ist die Post.",
        "exampleEN": "The post office is over there."
      },
      {
        "id": "adv0023",
        "german": "draußen",
        "english": "outside",
        "level": "A2",
        "type": "adverb",
        "exampleDE": "Die Kinder spielen draußen .",
        "exampleEN": "The children are playing outside."
      },
      {
        "id": "adv0024",
        "german": "drinnen",
        "english": "inside",
        "level": "A2",
        "type": "adverb",
        "exampleDE": "Es regnet, wir bleiben drinnen .",
        "exampleEN": "It's raining, we're staying inside."
      },
      {
        "id": "adv0025",
        "german": "drüben",
        "english": "over there",
        "level": "A2",
        "type": "adverb",
        "exampleDE": "Die Haltestelle ist da drüben .",
        "exampleEN": "The stop is over there."
      },
      {
        "id": "adv0026",
        "german": "eigentlich",
        "english": "actually",
        "level": "A2",
        "type": "adverb",
        "exampleDE": "Eigentlich wollte ich heute Sport machen.",
        "exampleEN": "Actually I wanted to do sport today."
      },
      {
        "id": "adv0027",
        "german": "ein bisschen",
        "english": "a little, a bit",
        "level": "A1",
        "type": "adverb",
        "exampleDE": "Ich spreche ein bisschen Deutsch.",
        "exampleEN": "I speak a little German."
      },
      {
        "id": "adv0028",
        "german": "einmal",
        "english": "once",
        "level": "A1",
        "type": "adverb",
        "exampleDE": "Ich gehe einmal pro Woche schwimmen.",
        "exampleEN": "I go swimming once a week."
      },
      {
        "id": "adv0029",
        "german": "endlich",
        "english": "finally",
        "level": "A2",
        "type": "adverb",
        "exampleDE": "Endlich ist Wochenende!",
        "exampleEN": "Finally it's the weekend!"
      },
      {
        "id": "adv0030",
        "german": "erst",
        "english": "only, not until; first",
        "level": "A2",
        "type": "adverb",
        "exampleDE": "Der Kurs beginnt erst um zehn.",
        "exampleEN": "The course doesn't start until ten."
      },
      {
        "id": "adv0031",
        "german": "etwas",
        "english": "something; a little",
        "level": "A2",
        "type": "adverb",
        "exampleDE": "Möchtest du etwas trinken?",
        "exampleEN": "Would you like something to drink?"
      },
      {
        "id": "adv0032",
        "german": "fast",
        "english": "almost",
        "level": "A2",
        "type": "adverb",
        "exampleDE": "Ich bin fast fertig.",
        "exampleEN": "I'm almost finished."
      },
      {
        "id": "adv0033",
        "german": "früher",
        "english": "in the past, earlier",
        "level": "A2",
        "type": "adverb",
        "exampleDE": "Früher habe ich in Lahore gewohnt.",
        "exampleEN": "I used to live in Lahore."
      },
      {
        "id": "adv0034",
        "german": "ganz",
        "english": "quite; completely",
        "level": "A1",
        "type": "adverb",
        "exampleDE": "Das Essen ist ganz gut.",
        "exampleEN": "The food is quite good."
      },
      {
        "id": "adv0035",
        "german": "gar nicht",
        "english": "not at all",
        "level": "A2",
        "type": "adverb",
        "exampleDE": "Das finde ich gar nicht gut.",
        "exampleEN": "I don't like that at all."
      },
      {
        "id": "adv0036",
        "german": "genau",
        "english": "exactly",
        "level": "A1",
        "type": "adverb",
        "exampleDE": "Ja, genau !",
        "exampleEN": "Yes, exactly!"
      },
      {
        "id": "adv0037",
        "german": "genug",
        "english": "enough",
        "level": "A2",
        "type": "adverb",
        "exampleDE": "Haben wir genug Brot?",
        "exampleEN": "Do we have enough bread?"
      },
      {
        "id": "adv0038",
        "german": "gerade",
        "english": "just; right now",
        "level": "A2",
        "type": "adverb",
        "exampleDE": "Ich koche gerade .",
        "exampleEN": "I'm cooking right now."
      },
      {
        "id": "adv0039",
        "german": "geradeaus",
        "english": "straight ahead",
        "level": "A1",
        "type": "adverb",
        "exampleDE": "Gehen Sie immer geradeaus .",
        "exampleEN": "Keep going straight ahead."
      },
      {
        "id": "adv0040",
        "german": "gern",
        "english": "gladly; to like (doing)",
        "level": "A1",
        "type": "adverb",
        "exampleDE": "Ich tanze gern .",
        "exampleEN": "I like dancing."
      },
      {
        "id": "adv0041",
        "german": "gestern",
        "english": "yesterday",
        "level": "A1",
        "type": "adverb",
        "exampleDE": "Gestern war ich im Kino.",
        "exampleEN": "Yesterday I was at the cinema."
      },
      {
        "id": "adv0042",
        "german": "gleich",
        "english": "in a moment, right away",
        "level": "A1",
        "type": "adverb",
        "exampleDE": "Ich komme gleich !",
        "exampleEN": "I'm coming right away!"
      },
      {
        "id": "adv0043",
        "german": "heute",
        "english": "today",
        "level": "A1",
        "type": "adverb",
        "exampleDE": "Heute habe ich keine Zeit.",
        "exampleEN": "I don't have time today."
      },
      {
        "id": "adv0044",
        "german": "hier",
        "english": "here",
        "level": "A1",
        "type": "adverb",
        "exampleDE": "Ich wohne hier .",
        "exampleEN": "I live here."
      },
      {
        "id": "adv0045",
        "german": "hoffentlich",
        "english": "hopefully",
        "level": "A2",
        "type": "adverb",
        "exampleDE": "Hoffentlich kommt der Zug pünktlich.",
        "exampleEN": "Hopefully the train will be on time."
      },
      {
        "id": "adv0046",
        "german": "immer",
        "english": "always",
        "level": "A1",
        "type": "adverb",
        "exampleDE": "Ich trinke immer Kaffee am Morgen.",
        "exampleEN": "I always drink coffee in the morning."
      },
      {
        "id": "adv0047",
        "german": "inzwischen",
        "english": "meanwhile; by now",
        "level": "A2",
        "type": "adverb",
        "exampleDE": "Inzwischen spreche ich gut Deutsch.",
        "exampleEN": "By now I speak good German."
      },
      {
        "id": "adv0048",
        "german": "irgendwann",
        "english": "at some point",
        "level": "A2",
        "type": "adverb",
        "exampleDE": "Irgendwann möchte ich nach Japan reisen.",
        "exampleEN": "At some point I'd like to travel to Japan."
      },
      {
        "id": "adv0049",
        "german": "irgendwo",
        "english": "somewhere",
        "level": "A2",
        "type": "adverb",
        "exampleDE": "Mein Schlüssel ist irgendwo hier.",
        "exampleEN": "My key is somewhere here."
      },
      {
        "id": "adv0050",
        "german": "ja",
        "english": "yes",
        "level": "A1",
        "type": "adverb",
        "exampleDE": "Ja , das ist richtig.",
        "exampleEN": "Yes, that's correct."
      },
      {
        "id": "adv0051",
        "german": "jeden Tag",
        "english": "every day",
        "level": "A1",
        "type": "adverb",
        "exampleDE": "Ich lerne jeden Tag Deutsch. 11 Wörter",
        "exampleEN": "I study German every day."
      },
      {
        "id": "adv0052",
        "german": "jeder / jede / jedes",
        "english": "every, each",
        "level": "A2",
        "type": "adverb",
        "exampleDE": "Ich gehe jeden Tag zu Fuß.",
        "exampleEN": "I walk every day."
      },
      {
        "id": "adv0053",
        "german": "jemand ↔ niemand",
        "english": "somebody ↔ nobody",
        "level": "A2",
        "type": "adverb",
        "exampleDE": "Ist jemand zu Hause? Nein, niemand .",
        "exampleEN": "Is anybody at home? No, nobody."
      },
      {
        "id": "adv0054",
        "german": "jetzt",
        "english": "now",
        "level": "A1",
        "type": "adverb",
        "exampleDE": "Ich muss jetzt gehen.",
        "exampleEN": "I have to go now."
      },
      {
        "id": "adv0055",
        "german": "kein / keine",
        "english": "no, not a",
        "level": "A2",
        "type": "adverb",
        "exampleDE": "Ich habe keine Zeit.",
        "exampleEN": "I don't have time."
      },
      {
        "id": "adv0056",
        "german": "leider",
        "english": "unfortunately",
        "level": "A1",
        "type": "adverb",
        "exampleDE": "Leider habe ich keine Zeit.",
        "exampleEN": "Unfortunately I don't have time."
      },
      {
        "id": "adv0057",
        "german": "lieber",
        "english": "rather, prefer",
        "level": "A1",
        "type": "adverb",
        "exampleDE": "Ich trinke lieber Tee.",
        "exampleEN": "I prefer tea."
      },
      {
        "id": "adv0058",
        "german": "links",
        "english": "(on the) left",
        "level": "A1",
        "type": "adverb",
        "exampleDE": "Die Toilette ist links .",
        "exampleEN": "The toilet is on the left."
      },
      {
        "id": "adv0059",
        "german": "mal",
        "english": "just (softens a request); times",
        "level": "A2",
        "type": "adverb",
        "exampleDE": "Komm mal her!",
        "exampleEN": "Come here a moment!"
      },
      {
        "id": "adv0060",
        "german": "man",
        "english": "one, people, you",
        "level": "A2",
        "type": "adverb",
        "exampleDE": "Hier darf man nicht parken.",
        "exampleEN": "You're not allowed to park here."
      },
      {
        "id": "adv0061",
        "german": "manchmal",
        "english": "sometimes",
        "level": "A1",
        "type": "adverb",
        "exampleDE": "Manchmal koche ich für meine Freunde.",
        "exampleEN": "Sometimes I cook for my friends."
      },
      {
        "id": "adv0062",
        "german": "mehr",
        "english": "more",
        "level": "A2",
        "type": "adverb",
        "exampleDE": "Ich möchte mehr Deutsch sprechen.",
        "exampleEN": "I'd like to speak more German."
      },
      {
        "id": "adv0063",
        "german": "meistens",
        "english": "usually, mostly",
        "level": "A1",
        "type": "adverb",
        "exampleDE": "Meistens fahre ich mit dem Bus.",
        "exampleEN": "I usually go by bus."
      },
      {
        "id": "adv0064",
        "german": "mindestens",
        "english": "at least",
        "level": "A2",
        "type": "adverb",
        "exampleDE": "Die Fahrt dauert mindestens zwei Stunden.",
        "exampleEN": "The journey takes at least two hours."
      },
      {
        "id": "adv0065",
        "german": "mittags",
        "english": "at midday",
        "level": "A1",
        "type": "adverb",
        "exampleDE": "Mittags esse ich in der Kantine.",
        "exampleEN": "At midday I eat in the canteen."
      },
      {
        "id": "adv0066",
        "german": "montags",
        "english": "on Mondays",
        "level": "A1",
        "type": "adverb",
        "exampleDE": "Montags habe ich Deutschkurs.",
        "exampleEN": "I have German class on Mondays."
      },
      {
        "id": "adv0067",
        "german": "morgen",
        "english": "tomorrow",
        "level": "A1",
        "type": "adverb",
        "exampleDE": "Morgen gehe ich zum Arzt.",
        "exampleEN": "Tomorrow I'm going to the doctor."
      },
      {
        "id": "adv0068",
        "german": "morgens",
        "english": "in the morning(s)",
        "level": "A1",
        "type": "adverb",
        "exampleDE": "Morgens trinke ich Tee.",
        "exampleEN": "In the mornings I drink tea."
      },
      {
        "id": "adv0069",
        "german": "nach Hause",
        "english": "(to) home",
        "level": "A1",
        "type": "adverb",
        "exampleDE": "Um 18 Uhr gehe ich nach Hause .",
        "exampleEN": "At 6 p.m. I go home."
      },
      {
        "id": "adv0070",
        "german": "nachher",
        "english": "afterwards, later",
        "level": "A2",
        "type": "adverb",
        "exampleDE": "Wir sehen uns nachher .",
        "exampleEN": "See you later."
      },
      {
        "id": "adv0071",
        "german": "natürlich",
        "english": "of course",
        "level": "A1",
        "type": "adverb",
        "exampleDE": "Natürlich helfe ich dir.",
        "exampleEN": "Of course I'll help you."
      },
      {
        "id": "adv0072",
        "german": "nebenan",
        "english": "next door",
        "level": "A2",
        "type": "adverb",
        "exampleDE": "Unsere Nachbarn nebenan sind sehr nett.",
        "exampleEN": "Our neighbours next door are very nice."
      },
      {
        "id": "adv0073",
        "german": "nein",
        "english": "no",
        "level": "A1",
        "type": "adverb",
        "exampleDE": "Nein , danke.",
        "exampleEN": "No, thank you."
      },
      {
        "id": "adv0074",
        "german": "neulich",
        "english": "recently, the other day",
        "level": "A2",
        "type": "adverb",
        "exampleDE": "Neulich habe ich Ali in der Stadt getroffen.",
        "exampleEN": "The other day I met Ali in town."
      },
      {
        "id": "adv0075",
        "german": "nicht",
        "english": "not",
        "level": "A1",
        "type": "adverb",
        "exampleDE": "Ich bin nicht müde.",
        "exampleEN": "I'm not tired."
      },
      {
        "id": "adv0076",
        "german": "nichts",
        "english": "nothing",
        "level": "A2",
        "type": "adverb",
        "exampleDE": "Ich habe nichts gegessen.",
        "exampleEN": "I haven't eaten anything."
      },
      {
        "id": "adv0077",
        "german": "nie",
        "english": "never",
        "level": "A1",
        "type": "adverb",
        "exampleDE": "Ich rauche nie .",
        "exampleEN": "I never smoke."
      },
      {
        "id": "adv0078",
        "german": "nirgends",
        "english": "nowhere",
        "level": "A2",
        "type": "adverb",
        "exampleDE": "Ich finde meine Brille nirgends .",
        "exampleEN": "I can't find my glasses anywhere."
      },
      {
        "id": "adv0079",
        "german": "noch",
        "english": "still; another",
        "level": "A1",
        "type": "adverb",
        "exampleDE": "Ich wohne noch bei meinen Eltern.",
        "exampleEN": "I still live with my parents."
      },
      {
        "id": "adv0080",
        "german": "noch nicht",
        "english": "not yet",
        "level": "A1",
        "type": "adverb",
        "exampleDE": "Ich habe noch nicht gegessen.",
        "exampleEN": "I haven't eaten yet."
      },
      {
        "id": "adv0081",
        "german": "nur",
        "english": "only",
        "level": "A1",
        "type": "adverb",
        "exampleDE": "Ich habe nur zehn Euro.",
        "exampleEN": "I only have ten euros."
      },
      {
        "id": "adv0082",
        "german": "oben",
        "english": "up, upstairs",
        "level": "A1",
        "type": "adverb",
        "exampleDE": "Das Schlafzimmer ist oben .",
        "exampleEN": "The bedroom is upstairs."
      },
      {
        "id": "adv0083",
        "german": "oft",
        "english": "often",
        "level": "A1",
        "type": "adverb",
        "exampleDE": "Wir gehen oft ins Kino.",
        "exampleEN": "We often go to the cinema."
      },
      {
        "id": "adv0084",
        "german": "plötzlich",
        "english": "suddenly",
        "level": "A2",
        "type": "adverb",
        "exampleDE": "Plötzlich hat es geregnet.",
        "exampleEN": "Suddenly it started raining."
      },
      {
        "id": "adv0085",
        "german": "rechts",
        "english": "(on the) right",
        "level": "A1",
        "type": "adverb",
        "exampleDE": "Gehen Sie hier rechts .",
        "exampleEN": "Turn right here."
      },
      {
        "id": "adv0086",
        "german": "schon",
        "english": "already",
        "level": "A1",
        "type": "adverb",
        "exampleDE": "Bist du schon fertig?",
        "exampleEN": "Are you finished already?"
      },
      {
        "id": "adv0087",
        "german": "schon mal",
        "english": "ever, before",
        "level": "A2",
        "type": "adverb",
        "exampleDE": "Warst du schon mal in Hamburg?",
        "exampleEN": "Have you ever been to Hamburg?"
      },
      {
        "id": "adv0088",
        "german": "sehr",
        "english": "very",
        "level": "A1",
        "type": "adverb",
        "exampleDE": "Das ist sehr gut!",
        "exampleEN": "That's very good!"
      },
      {
        "id": "adv0089",
        "german": "selbst",
        "english": "myself, yourself …",
        "level": "A2",
        "type": "adverb",
        "exampleDE": "Den Kuchen habe ich selbst gebacken.",
        "exampleEN": "I baked the cake myself."
      },
      {
        "id": "adv0090",
        "german": "selten",
        "english": "rarely",
        "level": "A1",
        "type": "adverb",
        "exampleDE": "Ich esse selten Fleisch.",
        "exampleEN": "I rarely eat meat."
      },
      {
        "id": "adv0091",
        "german": "sofort",
        "english": "immediately",
        "level": "A2",
        "type": "adverb",
        "exampleDE": "Ich komme sofort !",
        "exampleEN": "I'm coming right away!"
      },
      {
        "id": "adv0092",
        "german": "sogar",
        "english": "even",
        "level": "A2",
        "type": "adverb",
        "exampleDE": "Er arbeitet sogar am Sonntag.",
        "exampleEN": "He even works on Sundays."
      },
      {
        "id": "adv0093",
        "german": "sonst",
        "english": "otherwise; else",
        "level": "A2",
        "type": "adverb",
        "exampleDE": "Beeil dich, sonst verpasst du den Bus.",
        "exampleEN": "Hurry up, otherwise you'll miss the bus."
      },
      {
        "id": "adv0094",
        "german": "später",
        "english": "later",
        "level": "A1",
        "type": "adverb",
        "exampleDE": "Ich rufe dich später an.",
        "exampleEN": "I'll call you later."
      },
      {
        "id": "adv0095",
        "german": "überall",
        "english": "everywhere",
        "level": "A2",
        "type": "adverb",
        "exampleDE": "Ich habe überall gesucht.",
        "exampleEN": "I've looked everywhere."
      },
      {
        "id": "adv0096",
        "german": "übermorgen ↔ vorgestern",
        "english": "the day after tomorrow ↔ the day before yesterday",
        "level": "A2",
        "type": "adverb",
        "exampleDE": "Übermorgen fliege ich nach Lahore.",
        "exampleEN": "The day after tomorrow I'm flying to Lahore."
      },
      {
        "id": "adv0097",
        "german": "unbedingt",
        "english": "definitely, absolutely",
        "level": "A2",
        "type": "adverb",
        "exampleDE": "Den Film musst du unbedingt sehen!",
        "exampleEN": "You absolutely have to see that film!"
      },
      {
        "id": "adv0098",
        "german": "ungefähr",
        "english": "about, roughly",
        "level": "A2",
        "type": "adverb",
        "exampleDE": "Die Fahrt dauert ungefähr eine Stunde.",
        "exampleEN": "The journey takes about an hour."
      },
      {
        "id": "adv0099",
        "german": "unten",
        "english": "down, downstairs",
        "level": "A1",
        "type": "adverb",
        "exampleDE": "Die Küche ist unten .",
        "exampleEN": "The kitchen is downstairs."
      },
      {
        "id": "adv0100",
        "german": "unterwegs",
        "english": "on the way, out and about",
        "level": "A2",
        "type": "adverb",
        "exampleDE": "Ich bin gerade unterwegs .",
        "exampleEN": "I'm out and about at the moment."
      },
      {
        "id": "adv0101",
        "german": "vielleicht",
        "english": "maybe, perhaps",
        "level": "A1",
        "type": "adverb",
        "exampleDE": "Vielleicht komme ich morgen.",
        "exampleEN": "Maybe I'll come tomorrow."
      },
      {
        "id": "adv0102",
        "german": "vorher",
        "english": "before(hand)",
        "level": "A2",
        "type": "adverb",
        "exampleDE": "Ruf mich bitte vorher an.",
        "exampleEN": "Please call me beforehand."
      },
      {
        "id": "adv0103",
        "german": "vorne ↔ hinten",
        "english": "at the front ↔ at the back",
        "level": "A2",
        "type": "adverb",
        "exampleDE": "Ich sitze gern vorne im Bus.",
        "exampleEN": "I like sitting at the front of the bus."
      },
      {
        "id": "adv0104",
        "german": "wahrscheinlich",
        "english": "probably",
        "level": "A2",
        "type": "adverb",
        "exampleDE": "Ich komme wahrscheinlich etwas später.",
        "exampleEN": "I'll probably be a bit late."
      },
      {
        "id": "adv0105",
        "german": "weg",
        "english": "away, gone",
        "level": "A2",
        "type": "adverb",
        "exampleDE": "Mein Fahrrad ist weg !",
        "exampleEN": "My bike is gone!"
      },
      {
        "id": "adv0106",
        "german": "wenigstens",
        "english": "at least",
        "level": "A2",
        "type": "adverb",
        "exampleDE": "Ruf wenigstens kurz an!",
        "exampleEN": "At least give me a quick call!"
      },
      {
        "id": "adv0107",
        "german": "wieder",
        "english": "again",
        "level": "A1",
        "type": "adverb",
        "exampleDE": "Wann kommst du wieder ?",
        "exampleEN": "When are you coming again?"
      },
      {
        "id": "adv0108",
        "german": "wirklich",
        "english": "really",
        "level": "A1",
        "type": "adverb",
        "exampleDE": "Das ist wirklich schön.",
        "exampleEN": "That's really nice."
      },
      {
        "id": "adv0109",
        "german": "ziemlich",
        "english": "quite, rather",
        "level": "A2",
        "type": "adverb",
        "exampleDE": "Die Wohnung ist ziemlich teuer.",
        "exampleEN": "The flat is quite expensive."
      },
      {
        "id": "adv0110",
        "german": "zu",
        "english": "too",
        "level": "A1",
        "type": "adverb",
        "exampleDE": "Die Hose ist zu groß.",
        "exampleEN": "The trousers are too big."
      },
      {
        "id": "adv0111",
        "german": "zu Hause",
        "english": "at home",
        "level": "A1",
        "type": "adverb",
        "exampleDE": "Heute bin ich zu Hause .",
        "exampleEN": "Today I'm at home."
      },
      {
        "id": "adv0112",
        "german": "zuerst",
        "english": "first",
        "level": "A1",
        "type": "adverb",
        "exampleDE": "Zuerst esse ich, dann lerne ich.",
        "exampleEN": "First I eat, then I study."
      },
      {
        "id": "adv0113",
        "german": "zuletzt",
        "english": "last",
        "level": "A2",
        "type": "adverb",
        "exampleDE": "Wann warst du zuletzt beim Arzt?",
        "exampleEN": "When were you last at the doctor's?"
      },
      {
        "id": "adv0114",
        "german": "zum Schluss",
        "english": "finally, at the end",
        "level": "A2",
        "type": "adverb",
        "exampleDE": "Zum Schluss trinken wir einen Tee.",
        "exampleEN": "At the end we have a tea."
      },
      {
        "id": "adv0115",
        "german": "zurück",
        "english": "back",
        "level": "A1",
        "type": "adverb",
        "exampleDE": "Ich bin um 5 Uhr zurück . 11 Wörter",
        "exampleEN": "I'll be back at 5."
      },
      {
        "id": "adv0116",
        "german": "zusammen",
        "english": "together",
        "level": "A1",
        "type": "adverb",
        "exampleDE": "Wir kochen zusammen .",
        "exampleEN": "We're cooking together."
      }
    ]
  },
  {
    "id": "praep_konn_fragen",
    "title": "Präpositionen, Konnektoren & Fragen",
    "emoji": "🧭",
    "entries": [
      {
        "id": "prep0001",
        "german": "in",
        "rule": "wo? + Dativ (im) · wohin? + Akk. (ins)",
        "english": "in; into",
        "level": "A1",
        "type": "preposition",
        "exampleDE": "Ich wohne in Berlin. Wir gehen ins Kino.",
        "exampleEN": "I live in Berlin. We're going to the cinema."
      },
      {
        "id": "prep0002",
        "german": "an",
        "rule": "wo? + Dativ (am) · wohin? + Akk.",
        "english": "at, on (vertical)",
        "level": "A1",
        "type": "preposition",
        "exampleDE": "Das Bild hängt an der Wand.",
        "exampleEN": "The picture is hanging on the wall."
      },
      {
        "id": "prep0003",
        "german": "auf",
        "rule": "wo? + Dativ · wohin? + Akk.",
        "english": "on (top of)",
        "level": "A1",
        "type": "preposition",
        "exampleDE": "Das Buch liegt auf dem Tisch.",
        "exampleEN": "The book is on the table."
      },
      {
        "id": "prep0004",
        "german": "neben",
        "rule": "wo? + Dativ · wohin? + Akk.",
        "english": "next to",
        "level": "A1",
        "type": "preposition",
        "exampleDE": "Die Apotheke ist neben der Bank.",
        "exampleEN": "The pharmacy is next to the bank."
      },
      {
        "id": "prep0005",
        "german": "vor",
        "rule": "wo? + Dativ · wohin? + Akk.",
        "english": "in front of",
        "level": "A1",
        "type": "preposition",
        "exampleDE": "Das Auto steht vor dem Haus.",
        "exampleEN": "The car is in front of the house."
      },
      {
        "id": "prep0006",
        "german": "hinter",
        "rule": "wo? + Dativ · wohin? + Akk.",
        "english": "behind",
        "level": "A1",
        "type": "preposition",
        "exampleDE": "Der Garten ist hinter dem Haus.",
        "exampleEN": "The garden is behind the house."
      },
      {
        "id": "prep0007",
        "german": "unter",
        "rule": "wo? + Dativ · wohin? + Akk.",
        "english": "under",
        "level": "A1",
        "type": "preposition",
        "exampleDE": "Die Katze schläft unter dem Tisch.",
        "exampleEN": "The cat is sleeping under the table."
      },
      {
        "id": "prep0008",
        "german": "zwischen",
        "rule": "wo? + Dativ · wohin? + Akk.",
        "english": "between",
        "level": "A1",
        "type": "preposition",
        "exampleDE": "Die Post ist zwischen dem Bahnhof und der Bank. 5 Einträge",
        "exampleEN": "The post office is between the station and the bank."
      },
      {
        "id": "prep0009",
        "german": "aus",
        "rule": "+ Dativ · woher?",
        "english": "from (a country/town)",
        "level": "A1",
        "type": "preposition",
        "exampleDE": "Ich komme aus der Türkei.",
        "exampleEN": "I'm from Turkey."
      },
      {
        "id": "prep0010",
        "german": "nach",
        "rule": "cities and countries without article",
        "english": "to",
        "level": "A1",
        "type": "preposition",
        "exampleDE": "Ich fahre nach Hamburg.",
        "exampleEN": "I'm going to Hamburg."
      },
      {
        "id": "prep0011",
        "german": "zu",
        "rule": "+ Dativ (zum / zur) · people, places",
        "english": "to",
        "level": "A1",
        "type": "preposition",
        "exampleDE": "Ich gehe zum Arzt und dann zur Post.",
        "exampleEN": "I'm going to the doctor and then to the post office."
      },
      {
        "id": "prep0012",
        "german": "bei",
        "rule": "+ Dativ (beim)",
        "english": "at (sb's place / a company)",
        "level": "A1",
        "type": "preposition",
        "exampleDE": "Ich wohne bei meiner Tante. Er arbeitet bei einer Bank.",
        "exampleEN": "I live at my aunt's. He works at a bank."
      },
      {
        "id": "prep0013",
        "german": "von",
        "rule": "+ Dativ (vom)",
        "english": "from; of",
        "level": "A1",
        "type": "preposition",
        "exampleDE": "Das Geschenk ist von meinem Bruder. 8 Einträge",
        "exampleEN": "The present is from my brother."
      },
      {
        "id": "prep0014",
        "german": "um",
        "rule": "clock time",
        "english": "at",
        "level": "A1",
        "type": "preposition",
        "exampleDE": "Der Kurs beginnt um 9 Uhr.",
        "exampleEN": "The course starts at 9 o'clock."
      },
      {
        "id": "prep0015",
        "german": "am",
        "rule": "days, parts of the day, dates",
        "english": "on",
        "level": "A1",
        "type": "preposition",
        "exampleDE": "Am Montag habe ich frei. Am Abend lese ich.",
        "exampleEN": "I'm off on Monday. In the evening I read."
      },
      {
        "id": "prep0016",
        "german": "im",
        "rule": "months, seasons",
        "english": "in",
        "level": "A1",
        "type": "preposition",
        "exampleDE": "Im Juli fahren wir in Urlaub.",
        "exampleEN": "In July we're going on holiday."
      },
      {
        "id": "prep0017",
        "german": "von… bis",
        "rule": "from… to / until",
        "english": "from… until",
        "level": "A1",
        "type": "preposition",
        "exampleDE": "Ich arbeite von 8 bis 16 Uhr.",
        "exampleEN": "I work from 8 a.m. until 4 p.m."
      },
      {
        "id": "prep0018",
        "german": "seit",
        "rule": "+ Dativ · started in the past, still true",
        "english": "since, for",
        "level": "A1",
        "type": "preposition",
        "exampleDE": "Ich lerne seit einem Jahr Deutsch.",
        "exampleEN": "I've been learning German for a year."
      },
      {
        "id": "prep0019",
        "german": "ab",
        "rule": "from (a point in time on)",
        "english": "from",
        "level": "A1",
        "type": "preposition",
        "exampleDE": "Ab Montag habe ich Urlaub.",
        "exampleEN": "From Monday I'm on holiday."
      },
      {
        "id": "prep0020",
        "german": "vor",
        "rule": "+ Dativ",
        "english": "before; ago",
        "level": "A1",
        "type": "preposition",
        "exampleDE": "Vor dem Essen wasche ich mir die Hände. Ich war vor zwei Jahren in Rom.",
        "exampleEN": "I wash my hands before eating. I was in Rome two years ago."
      },
      {
        "id": "prep0021",
        "german": "nach",
        "rule": "+ Dativ",
        "english": "after",
        "level": "A1",
        "type": "preposition",
        "exampleDE": "Nach dem Kurs trinken wir einen Kaffee. 3 Einträge",
        "exampleEN": "After the course we have a coffee."
      },
      {
        "id": "prep0022",
        "german": "mit",
        "rule": "+ Dativ",
        "english": "with; by (transport)",
        "level": "A1",
        "type": "preposition",
        "exampleDE": "Ich fahre mit dem Bus.",
        "exampleEN": "I'm going by bus."
      },
      {
        "id": "prep0023",
        "german": "für",
        "rule": "+ Akkusativ",
        "english": "for",
        "level": "A1",
        "type": "preposition",
        "exampleDE": "Das Geschenk ist für dich.",
        "exampleEN": "The present is for you."
      },
      {
        "id": "prep0024",
        "german": "ohne",
        "rule": "+ Akkusativ",
        "english": "without",
        "level": "A1",
        "type": "preposition",
        "exampleDE": "Ich trinke Kaffee ohne Zucker.",
        "exampleEN": "I drink coffee without sugar."
      },
      {
        "id": "prep0025",
        "german": "durch",
        "rule": "+ Akk.",
        "english": "through",
        "level": "A2",
        "type": "preposition",
        "exampleDE": "Wir gehen durch den Park.",
        "exampleEN": "We're walking through the park."
      },
      {
        "id": "prep0026",
        "german": "gegen",
        "rule": "+ Akk.",
        "english": "against; around (time)",
        "level": "A2",
        "type": "preposition",
        "exampleDE": "Ich komme gegen acht Uhr.",
        "exampleEN": "I'll come around eight o'clock."
      },
      {
        "id": "prep0027",
        "german": "bis",
        "rule": "+ Akk.",
        "english": "until; as far as",
        "level": "A2",
        "type": "preposition",
        "exampleDE": "Der Laden ist bis 20 Uhr offen.",
        "exampleEN": "The shop is open until 8 p.m."
      },
      {
        "id": "prep0028",
        "german": "außer",
        "rule": "+ Dat.",
        "english": "except",
        "level": "A2",
        "type": "preposition",
        "exampleDE": "Alle kommen, außer Tom.",
        "exampleEN": "Everyone is coming except Tom."
      },
      {
        "id": "prep0029",
        "german": "gegenüber (von)",
        "rule": "+ Dat.",
        "english": "opposite",
        "level": "A2",
        "type": "preposition",
        "exampleDE": "Die Bank ist gegenüber vom Bahnhof.",
        "exampleEN": "The bank is opposite the station."
      },
      {
        "id": "prep0030",
        "german": "über",
        "rule": "+ Akk./Dat.",
        "english": "over, above; about",
        "level": "A2",
        "type": "preposition",
        "exampleDE": "Das Bild hängt über dem Sofa.",
        "exampleEN": "The picture hangs above the sofa."
      },
      {
        "id": "prep0031",
        "german": "wegen Wort",
        "rule": "+ Gen. (oft Dat.) Regel · rule",
        "english": "because of English",
        "level": "A2",
        "type": "preposition",
        "exampleDE": "Wegen des Wetters fällt das Spiel aus.",
        "exampleEN": "The match is cancelled because of the weather. 5 Wörter Beispielsatz · example"
      },
      {
        "id": "prep0032",
        "german": "und",
        "rule": "verb stays in position 2",
        "english": "and",
        "level": "A1",
        "type": "preposition",
        "exampleDE": "Ich heiße Ana und ich komme aus Brasilien.",
        "exampleEN": "My name is Ana and I'm from Brazil."
      },
      {
        "id": "prep0033",
        "german": "aber",
        "rule": "verb stays in position 2",
        "english": "but",
        "level": "A1",
        "type": "preposition",
        "exampleDE": "Das Hotel ist schön, aber teuer.",
        "exampleEN": "The hotel is nice but expensive."
      },
      {
        "id": "prep0034",
        "german": "oder",
        "rule": "verb stays in position 2",
        "english": "or",
        "level": "A1",
        "type": "preposition",
        "exampleDE": "Möchtest du Tee oder Kaffee?",
        "exampleEN": "Would you like tea or coffee?"
      },
      {
        "id": "prep0035",
        "german": "denn",
        "rule": "verb stays in position 2 · reason",
        "english": "because",
        "level": "A1",
        "type": "preposition",
        "exampleDE": "Ich bleibe zu Hause, denn ich bin krank.",
        "exampleEN": "I'm staying at home because I'm ill."
      },
      {
        "id": "prep0036",
        "german": "sondern Wort",
        "rule": "after nicht / kein Regel · rule",
        "english": "but (rather) after nicht/kein English",
        "level": "A2",
        "type": "preposition",
        "exampleDE": "Ich trinke keinen Kaffee, sondern Tee.",
        "exampleEN": "I don't drink coffee but tea. 4 Wörter Beispielsatz · example"
      },
      {
        "id": "prep0037",
        "german": "deshalb",
        "rule": "verb comes next",
        "english": "that's why, so",
        "level": "A2",
        "type": "preposition",
        "exampleDE": "Ich bin müde, deshalb gehe ich früh ins Bett.",
        "exampleEN": "I'm tired, so I'm going to bed early."
      },
      {
        "id": "prep0038",
        "german": "trotzdem",
        "rule": "verb comes next",
        "english": "nevertheless, still",
        "level": "A2",
        "type": "preposition",
        "exampleDE": "Es regnet, trotzdem gehen wir spazieren.",
        "exampleEN": "It's raining, but we're still going for a walk."
      },
      {
        "id": "prep0039",
        "german": "also",
        "rule": "verb comes next",
        "english": "so",
        "level": "A2",
        "type": "preposition",
        "exampleDE": "Der Bus ist weg, also nehmen wir ein Taxi.",
        "exampleEN": "The bus has gone, so we'll take a taxi."
      },
      {
        "id": "prep0040",
        "german": "außerdem",
        "rule": "verb comes next",
        "english": "also, in addition",
        "level": "A2",
        "type": "preposition",
        "exampleDE": "Die Wohnung ist groß, außerdem hat sie einen Balkon.",
        "exampleEN": "The flat is big, and it also has a balcony."
      },
      {
        "id": "prep0041",
        "german": "weil",
        "rule": "verb at the end",
        "english": "because",
        "level": "A2",
        "type": "preposition",
        "exampleDE": "Ich bleibe zu Hause, weil ich krank bin.",
        "exampleEN": "I'm staying at home because I'm ill."
      },
      {
        "id": "prep0042",
        "german": "dass",
        "rule": "verb at the end",
        "english": "that",
        "level": "A2",
        "type": "preposition",
        "exampleDE": "Ich glaube, dass er heute kommt.",
        "exampleEN": "I think that he's coming today."
      },
      {
        "id": "prep0043",
        "german": "wenn",
        "rule": "verb at the end",
        "english": "if; when(ever)",
        "level": "A2",
        "type": "preposition",
        "exampleDE": "Wenn das Wetter gut ist, grillen wir.",
        "exampleEN": "If the weather is good, we'll have a barbecue."
      },
      {
        "id": "prep0044",
        "german": "ob",
        "rule": "verb at the end",
        "english": "whether, if",
        "level": "A2",
        "type": "preposition",
        "exampleDE": "Weißt du, ob der Laden heute offen ist?",
        "exampleEN": "Do you know if the shop is open today?"
      },
      {
        "id": "prep0045",
        "german": "als",
        "rule": "verb at the end",
        "english": "when (once in the past)",
        "level": "A2",
        "type": "preposition",
        "exampleDE": "Als ich nach Deutschland kam, war ich 24.",
        "exampleEN": "When I came to Germany, I was 24."
      },
      {
        "id": "prep0046",
        "german": "W-Wort (indirekte Frage) Wort",
        "rule": "verb at the end Regel · rule",
        "english": "question word + verb at the end English",
        "level": "A2",
        "type": "preposition",
        "exampleDE": "Können Sie mir sagen, wann der Zug fährt?",
        "exampleEN": "Can you tell me when the train leaves? 2 Wörter Beispielsatz · example"
      },
      {
        "id": "prep0047",
        "german": "als",
        "rule": "comparison",
        "english": "than (after a comparative)",
        "level": "A2",
        "type": "preposition",
        "exampleDE": "Berlin ist größer als Paderborn.",
        "exampleEN": "Berlin is bigger than Paderborn."
      },
      {
        "id": "prep0048",
        "german": "so … wie Frage",
        "rule": "comparison Regel · rule",
        "english": "as … as English",
        "level": "A2",
        "type": "preposition",
        "exampleDE": "Mein Bruder ist so groß wie ich.",
        "exampleEN": "My brother is as tall as me. 20 Fragen Beispielsatz · example"
      },
      {
        "id": "prep0049",
        "german": "wer?",
        "rule": "verb comes next",
        "english": "who?",
        "level": "A1",
        "type": "preposition",
        "exampleDE": "Wer ist das? Das ist meine Mutter.",
        "exampleEN": "Who is that? That's my mother."
      },
      {
        "id": "prep0050",
        "german": "was?",
        "rule": "verb comes next",
        "english": "what?",
        "level": "A1",
        "type": "preposition",
        "exampleDE": "Was machst du am Wochenende?",
        "exampleEN": "What are you doing at the weekend?"
      },
      {
        "id": "prep0051",
        "german": "wo?",
        "rule": "place",
        "english": "where?",
        "level": "A1",
        "type": "preposition",
        "exampleDE": "Wo wohnen Sie? In Köln.",
        "exampleEN": "Where do you live? In Cologne."
      },
      {
        "id": "prep0052",
        "german": "woher?",
        "rule": "origin",
        "english": "where from?",
        "level": "A1",
        "type": "preposition",
        "exampleDE": "Woher kommst du? Aus Spanien.",
        "exampleEN": "Where are you from? From Spain."
      },
      {
        "id": "prep0053",
        "german": "wohin?",
        "rule": "direction",
        "english": "where to?",
        "level": "A1",
        "type": "preposition",
        "exampleDE": "Wohin fährst du im Urlaub?",
        "exampleEN": "Where are you going on holiday?"
      },
      {
        "id": "prep0054",
        "german": "wann?",
        "rule": "time",
        "english": "when?",
        "level": "A1",
        "type": "preposition",
        "exampleDE": "Wann beginnt der Kurs?",
        "exampleEN": "When does the course start?"
      },
      {
        "id": "prep0055",
        "german": "um wie viel Uhr?",
        "rule": "exact time",
        "english": "at what time?",
        "level": "A1",
        "type": "preposition",
        "exampleDE": "Um wie viel Uhr kommst du?",
        "exampleEN": "What time are you coming?"
      },
      {
        "id": "prep0056",
        "german": "wie?",
        "rule": "manner",
        "english": "how?",
        "level": "A1",
        "type": "preposition",
        "exampleDE": "Wie geht es Ihnen?",
        "exampleEN": "How are you?"
      },
      {
        "id": "prep0057",
        "german": "wie alt?",
        "rule": "age",
        "english": "how old?",
        "level": "A1",
        "type": "preposition",
        "exampleDE": "Wie alt bist du? Ich bin 28.",
        "exampleEN": "How old are you? I'm 28."
      },
      {
        "id": "prep0058",
        "german": "wie lange?",
        "rule": "duration",
        "english": "how long?",
        "level": "A1",
        "type": "preposition",
        "exampleDE": "Wie lange dauert der Film?",
        "exampleEN": "How long does the film last?"
      },
      {
        "id": "prep0059",
        "german": "wie viel?",
        "rule": "uncountable / price",
        "english": "how much?",
        "level": "A1",
        "type": "preposition",
        "exampleDE": "Wie viel kostet das?",
        "exampleEN": "How much does that cost?"
      },
      {
        "id": "prep0060",
        "german": "wie viele?",
        "rule": "countable (plural)",
        "english": "how many?",
        "level": "A1",
        "type": "preposition",
        "exampleDE": "Wie viele Kinder haben Sie?",
        "exampleEN": "How many children do you have?"
      },
      {
        "id": "prep0061",
        "german": "warum?",
        "rule": "reason",
        "english": "why?",
        "level": "A1",
        "type": "preposition",
        "exampleDE": "Warum lernst du Deutsch?",
        "exampleEN": "Why are you learning German?"
      },
      {
        "id": "prep0062",
        "german": "welcher / welche / welches?",
        "rule": "der / die / das",
        "english": "which?",
        "level": "A1",
        "type": "preposition",
        "exampleDE": "Welche Sprache sprichst du? 4 Einträge",
        "exampleEN": "Which language do you speak?"
      },
      {
        "id": "prep0063",
        "german": "Wie oft …?",
        "rule": "",
        "english": "How often …?",
        "level": "A2",
        "type": "preposition",
        "exampleDE": "Wie oft machst du Sport?",
        "exampleEN": "How often do you do sport?"
      },
      {
        "id": "prep0064",
        "german": "Wie weit …?",
        "rule": "",
        "english": "How far …?",
        "level": "A2",
        "type": "preposition",
        "exampleDE": "Wie weit ist es bis zum Bahnhof?",
        "exampleEN": "How far is it to the station?"
      },
      {
        "id": "prep0065",
        "german": "Was für ein …?",
        "rule": "",
        "english": "What kind of …?",
        "level": "A2",
        "type": "preposition",
        "exampleDE": "Was für ein Auto hast du?",
        "exampleEN": "What kind of car do you have?"
      },
      {
        "id": "prep0066",
        "german": "Mit wem …?",
        "rule": "",
        "english": "With whom …?",
        "level": "A2",
        "type": "preposition",
        "exampleDE": "Mit wem fährst du in den Urlaub?",
        "exampleEN": "Who are you going on holiday with?"
      },
      {
        "id": "prep0067",
        "german": "Worauf …? / Auf wen …?",
        "rule": "",
        "english": "What … for? / Who … for?",
        "level": "A2",
        "type": "preposition",
        "exampleDE": "Worauf wartest du? Auf den Bus.",
        "exampleEN": "What are you waiting for? For the bus."
      },
      {
        "id": "prep0068",
        "german": "Wofür …?",
        "rule": "",
        "english": "What … for?",
        "level": "A2",
        "type": "preposition",
        "exampleDE": "Wofür interessierst du dich?",
        "exampleEN": "What are you interested in?"
      }
    ]
  },
  {
    "id": "redemittel",
    "title": "Redemittel für die Prüfung",
    "emoji": "🗣️",
    "entries": [
      {
        "id": "rm0001",
        "german": "Wann hast du Geburtstag?",
        "english": "When is your birthday?",
        "level": "A2",
        "type": "phrase",
        "exampleDE": "A: Wann hast du Geburtstag? B: Im März, am 12.",
        "exampleEN": "A: When's your birthday? B: On 12 March."
      },
      {
        "id": "rm0002",
        "german": "Was machst du beruflich?",
        "english": "What do you do for a living?",
        "level": "A2",
        "type": "phrase",
        "exampleDE": "Ich arbeite als Softwareentwickler.",
        "exampleEN": "I work as a software developer."
      },
      {
        "id": "rm0003",
        "german": "Wo hast du Deutsch gelernt?",
        "english": "Where did you learn German?",
        "level": "A2",
        "type": "phrase",
        "exampleDE": "Ich habe an der Volkshochschule Deutsch gelernt .",
        "exampleEN": "I learned German at the adult education centre."
      },
      {
        "id": "rm0004",
        "german": "Was machst du in deiner Freizeit?",
        "english": "What do you do in your free time?",
        "level": "A2",
        "type": "phrase",
        "exampleDE": "In meiner Freizeit gehe ich gern spazieren.",
        "exampleEN": "In my free time I like going for walks."
      },
      {
        "id": "rm0005",
        "german": "Welche Sprachen sprichst du?",
        "english": "Which languages do you speak?",
        "level": "A2",
        "type": "phrase",
        "exampleDE": "Ich spreche Urdu, Englisch und ein bisschen Deutsch.",
        "exampleEN": "I speak Urdu, English and a little German."
      },
      {
        "id": "rm0006",
        "german": "Kannst du das bitte wiederholen? Redemittel",
        "english": "Can you repeat that, please? English",
        "level": "A2",
        "type": "phrase",
        "exampleDE": "Entschuldigung, kannst du das bitte wiederholen?",
        "exampleEN": "Sorry, can you repeat that, please? 6 Redemittel Beispiel · example"
      },
      {
        "id": "rm0007",
        "german": "Ich möchte über … sprechen.",
        "english": "I'd like to talk about …",
        "level": "A2",
        "type": "phrase",
        "exampleDE": "Ich möchte über meine Wohnung sprechen .",
        "exampleEN": "I'd like to talk about my flat."
      },
      {
        "id": "rm0008",
        "german": "Bei mir ist das so: …",
        "english": "For me it's like this: …",
        "level": "A2",
        "type": "phrase",
        "exampleDE": "Bei mir ist das so: Ich koche fast jeden Tag.",
        "exampleEN": "For me it's like this: I cook almost every day."
      },
      {
        "id": "rm0009",
        "german": "Normalerweise … / Meistens …",
        "english": "Usually … / Mostly …",
        "level": "A2",
        "type": "phrase",
        "exampleDE": "Normalerweise frühstücke ich um sieben.",
        "exampleEN": "I usually have breakfast at seven."
      },
      {
        "id": "rm0010",
        "german": "Früher …, aber heute …",
        "english": "In the past …, but today …",
        "level": "A2",
        "type": "phrase",
        "exampleDE": "Früher habe ich viel Fleisch gegessen, aber heute esse ich mehr Gemüse.",
        "exampleEN": "I used to eat a lot of meat, but today I eat more vegetables."
      },
      {
        "id": "rm0011",
        "german": "In meinem Heimatland …",
        "english": "In my home country …",
        "level": "A2",
        "type": "phrase",
        "exampleDE": "In meinem Heimatland isst man abends warm.",
        "exampleEN": "In my home country people have a hot meal in the evening."
      },
      {
        "id": "rm0012",
        "german": "… ist mir wichtig, weil … Redemittel",
        "english": "… is important to me because … English",
        "level": "A2",
        "type": "phrase",
        "exampleDE": "Sport ist mir wichtig, weil ich viel am Computer sitze.",
        "exampleEN": "Sport is important to me because I sit at the computer a lot. 8 Redemittel Beispiel · example"
      },
      {
        "id": "rm0013",
        "german": "Wann hast du Zeit?",
        "english": "When are you free?",
        "level": "A2",
        "type": "phrase",
        "exampleDE": "Wann hast du am Samstag Zeit?",
        "exampleEN": "When are you free on Saturday?"
      },
      {
        "id": "rm0014",
        "german": "Wie wäre es mit …?",
        "english": "How about …?",
        "level": "A2",
        "type": "phrase",
        "exampleDE": "Wie wäre es mit Freitag um 15 Uhr?",
        "exampleEN": "How about Friday at 3 p.m.?"
      },
      {
        "id": "rm0015",
        "german": "Da kann ich leider nicht, da muss ich …",
        "english": "I can't then, I have to …",
        "level": "A2",
        "type": "phrase",
        "exampleDE": "Um 10 Uhr kann ich leider nicht, da muss ich zum Arzt.",
        "exampleEN": "I can't at 10, I have to go to the doctor."
      },
      {
        "id": "rm0016",
        "german": "Passt es dir um …?",
        "english": "Does … suit you?",
        "level": "A2",
        "type": "phrase",
        "exampleDE": "Passt es dir um 18 Uhr?",
        "exampleEN": "Does 6 p.m. suit you?"
      },
      {
        "id": "rm0017",
        "german": "Das ist eine gute Idee.",
        "english": "That's a good idea.",
        "level": "A2",
        "type": "phrase",
        "exampleDE": "Zusammen kochen? Das ist eine gute Idee!",
        "exampleEN": "Cooking together? That's a good idea!"
      },
      {
        "id": "rm0018",
        "german": "Ich würde lieber …",
        "english": "I'd rather …",
        "level": "A2",
        "type": "phrase",
        "exampleDE": "Ich würde lieber am Nachmittag gehen.",
        "exampleEN": "I'd rather go in the afternoon."
      },
      {
        "id": "rm0019",
        "german": "Gut, dann machen wir das so.",
        "english": "OK, let's do it that way.",
        "level": "A2",
        "type": "phrase",
        "exampleDE": "Samstag um zwei? Gut, dann machen wir das so.",
        "exampleEN": "Saturday at two? OK, let's do that."
      },
      {
        "id": "rm0020",
        "german": "Wer bringt … mit? Redemittel",
        "english": "Who's bringing …? English",
        "level": "A2",
        "type": "phrase",
        "exampleDE": "Wer bringt die Getränke mit?",
        "exampleEN": "Who's bringing the drinks? 6 Redemittel Beispiel · example"
      },
      {
        "id": "rm0021",
        "german": "Ich finde …, weil …",
        "english": "I think … because …",
        "level": "A2",
        "type": "phrase",
        "exampleDE": "Ich finde Paderborn schön, weil es ruhig ist.",
        "exampleEN": "I think Paderborn is nice because it's quiet."
      },
      {
        "id": "rm0022",
        "german": "Meiner Meinung nach …",
        "english": "In my opinion …",
        "level": "A2",
        "type": "phrase",
        "exampleDE": "Meiner Meinung nach ist das zu teuer.",
        "exampleEN": "In my opinion that's too expensive."
      },
      {
        "id": "rm0023",
        "german": "Ich glaube, dass …",
        "english": "I think that …",
        "level": "A2",
        "type": "phrase",
        "exampleDE": "Ich glaube, dass das eine gute Idee ist.",
        "exampleEN": "I think that's a good idea."
      },
      {
        "id": "rm0024",
        "german": "… gefällt mir (nicht).",
        "english": "I (don't) like …",
        "level": "A2",
        "type": "phrase",
        "exampleDE": "Die Wohnung gefällt mir sehr gut.",
        "exampleEN": "I like the flat very much."
      },
      {
        "id": "rm0025",
        "german": "Da hast du recht. / Das finde ich auch.",
        "english": "You're right. / I think so too.",
        "level": "A2",
        "type": "phrase",
        "exampleDE": "A: Das ist zu teuer. B: Da hast du recht.",
        "exampleEN": "A: That's too expensive. B: You're right."
      },
      {
        "id": "rm0026",
        "german": "Ich bin nicht sicher. Redemittel",
        "english": "I'm not sure. English",
        "level": "A2",
        "type": "phrase",
        "exampleDE": "Ich bin nicht sicher, ob ich Zeit habe.",
        "exampleEN": "I'm not sure if I have time. 10 Redemittel Beispiel · example"
      },
      {
        "id": "rm0027",
        "german": "Vielen Dank für deine Einladung / E-Mail.",
        "english": "Thank you for your invitation / email.",
        "level": "A2",
        "type": "phrase",
        "exampleDE": "Vielen Dank für deine Einladung zur Party!",
        "exampleEN": "Thank you for your invitation to the party!"
      },
      {
        "id": "rm0028",
        "german": "Ich freue mich sehr auf …",
        "english": "I'm really looking forward to …",
        "level": "A2",
        "type": "phrase",
        "exampleDE": "Ich freue mich sehr auf Samstag.",
        "exampleEN": "I'm really looking forward to Saturday."
      },
      {
        "id": "rm0029",
        "german": "Leider kann ich nicht kommen, weil …",
        "english": "Unfortunately I can't come because …",
        "level": "A2",
        "type": "phrase",
        "exampleDE": "Leider kann ich am Freitag nicht kommen, weil ich arbeiten muss.",
        "exampleEN": "Unfortunately I can't come on Friday because I have to work."
      },
      {
        "id": "rm0030",
        "german": "Soll ich etwas mitbringen?",
        "english": "Shall I bring something?",
        "level": "A2",
        "type": "phrase",
        "exampleDE": "Soll ich einen Salat mitbringen?",
        "exampleEN": "Shall I bring a salad?"
      },
      {
        "id": "rm0031",
        "german": "Entschuldige, dass ich so spät antworte.",
        "english": "Sorry for replying so late.",
        "level": "A2",
        "type": "phrase",
        "exampleDE": "Entschuldige, dass ich so spät antworte. Ich war krank.",
        "exampleEN": "Sorry for replying so late. I was ill."
      },
      {
        "id": "rm0032",
        "german": "Ich möchte mich für … anmelden.",
        "english": "I'd like to register for …",
        "level": "A2",
        "type": "phrase",
        "exampleDE": "Ich möchte mich für den Deutschkurs B1 anmelden.",
        "exampleEN": "I'd like to register for the B1 German course."
      },
      {
        "id": "rm0033",
        "german": "Ich habe eine Frage zu …",
        "english": "I have a question about …",
        "level": "A2",
        "type": "phrase",
        "exampleDE": "Ich habe eine Frage zu Ihrem Angebot.",
        "exampleEN": "I have a question about your offer."
      },
      {
        "id": "rm0034",
        "german": "Können Sie mir bitte sagen, ob / wann …?",
        "english": "Can you please tell me whether / when …?",
        "level": "A2",
        "type": "phrase",
        "exampleDE": "Können Sie mir bitte sagen, wann der Kurs beginnt?",
        "exampleEN": "Can you please tell me when the course starts?"
      },
      {
        "id": "rm0035",
        "german": "Ich muss meinen Termin leider absagen / verschieben.",
        "english": "Unfortunately I have to cancel / postpone my appointment.",
        "level": "A2",
        "type": "phrase",
        "exampleDE": "Ich muss meinen Termin am Montag leider verschieben.",
        "exampleEN": "Unfortunately I have to postpone my appointment on Monday."
      },
      {
        "id": "rm0036",
        "german": "Ich freue mich auf Ihre Antwort. Redemittel",
        "english": "I look forward to your reply. English",
        "level": "A2",
        "type": "phrase",
        "exampleDE": "Ich freue mich auf Ihre Antwort. Mit freundlichen Grüßen",
        "exampleEN": "I look forward to your reply. Kind regards 6 Redemittel Beispiel · example"
      },
      {
        "id": "rm0037",
        "german": "Hier spricht … / Mein Name ist …",
        "english": "This is … speaking.",
        "level": "A2",
        "type": "phrase",
        "exampleDE": "Guten Tag, hier spricht Shoukat Ali.",
        "exampleEN": "Hello, this is Shoukat Ali speaking."
      },
      {
        "id": "rm0038",
        "german": "Ich rufe an, weil …",
        "english": "I'm calling because …",
        "level": "A2",
        "type": "phrase",
        "exampleDE": "Ich rufe an, weil ich einen Termin brauche.",
        "exampleEN": "I'm calling because I need an appointment."
      },
      {
        "id": "rm0039",
        "german": "Kann ich bitte mit … sprechen?",
        "english": "Can I speak to …, please?",
        "level": "A2",
        "type": "phrase",
        "exampleDE": "Kann ich bitte mit Frau Klein sprechen?",
        "exampleEN": "Can I speak to Ms Klein, please?"
      },
      {
        "id": "rm0040",
        "german": "Können Sie mich bitte zurückrufen?",
        "english": "Can you call me back, please?",
        "level": "A2",
        "type": "phrase",
        "exampleDE": "Können Sie mich bitte heute noch zurückrufen?",
        "exampleEN": "Can you call me back today, please?"
      },
      {
        "id": "rm0041",
        "german": "Ich habe seit … Schmerzen.",
        "english": "I've had pain for …",
        "level": "A2",
        "type": "phrase",
        "exampleDE": "Ich habe seit zwei Tagen Hals schmerzen .",
        "exampleEN": "I've had a sore throat for two days."
      },
      {
        "id": "rm0042",
        "german": "Was soll ich machen? Redemittel",
        "english": "What should I do? English",
        "level": "A2",
        "type": "phrase",
        "exampleDE": "Mein Kind hat Fieber. Was soll ich machen?",
        "exampleEN": "My child has a fever. What should I do? 8 Redemittel Beispiel · example"
      },
      {
        "id": "rm0043",
        "german": "Das tut mir leid.",
        "english": "I'm sorry.",
        "level": "A2",
        "type": "phrase",
        "exampleDE": "A: Ich bin krank. B: Oh, das tut mir leid!",
        "exampleEN": "A: I'm ill. B: Oh, I'm sorry!"
      },
      {
        "id": "rm0044",
        "german": "Das ist mir egal.",
        "english": "I don't mind.",
        "level": "A2",
        "type": "phrase",
        "exampleDE": "Kino oder Restaurant? Das ist mir egal.",
        "exampleEN": "Cinema or restaurant? I don't mind."
      },
      {
        "id": "rm0045",
        "german": "Keine Ahnung.",
        "english": "No idea.",
        "level": "A2",
        "type": "phrase",
        "exampleDE": "Wann kommt der Bus? Keine Ahnung.",
        "exampleEN": "When is the bus coming? No idea."
      },
      {
        "id": "rm0046",
        "german": "Ich bin einverstanden.",
        "english": "I agree. / That's fine with me.",
        "level": "A2",
        "type": "phrase",
        "exampleDE": "Um acht im Café? Ich bin einverstanden.",
        "exampleEN": "At eight in the café? That's fine with me."
      },
      {
        "id": "rm0047",
        "german": "Viel Spaß! / Viel Glück! / Gute Besserung!",
        "english": "Have fun! / Good luck! / Get well soon!",
        "level": "A2",
        "type": "phrase",
        "exampleDE": "Du hast morgen Prüfung? Viel Glück!",
        "exampleEN": "You've got your exam tomorrow? Good luck!"
      },
      {
        "id": "rm0048",
        "german": "Herzlich willkommen!",
        "english": "Welcome!",
        "level": "A2",
        "type": "phrase",
        "exampleDE": "Herzlich willkommen in Paderborn!",
        "exampleEN": "Welcome to Paderborn!"
      },
      {
        "id": "rm0049",
        "german": "Ich hätte gern … / Zusammen oder getrennt?",
        "english": "I'd like … / Together or separately?",
        "level": "A2",
        "type": "phrase",
        "exampleDE": "Ich hätte gern einen Tee. Die Rechnung, bitte.",
        "exampleEN": "I'd like a tea. The bill, please."
      },
      {
        "id": "rm0050",
        "german": "Was heißt … auf Deutsch?",
        "english": "What's … in German?",
        "level": "A2",
        "type": "phrase",
        "exampleDE": "Was heißt 'appointment' auf Deutsch?",
        "exampleEN": "What's 'appointment' in German?"
      }
    ]
  }
]
};
